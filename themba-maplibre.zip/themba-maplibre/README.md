# THEMBA — Routing, Fare & Live Tracking (MapLibre + MapTiler + Django)

This is the routing/fare/live-tracking implementation for THEMBA, built with
**MapLibre GL JS + MapTiler + a Django REST backend** — no Google Maps, no
billing account required. It targets the South African minibus taxi model
(mostly Toyota Quantums): fixed **predetermined routes** with a fixed/per-km
fare, rather than dynamic point-to-point pricing.

```
themba-maplibre/
├── backend/     Django + DRF API: routes, fares, vehicles, live GPS, trips
└── frontend/    React app (your existing THEMBA UI) + the routing screens
```

## Architecture

```
React Frontend (MapLibre GL JS + MapTiler tiles)
        │  REST (fetch)
        ▼
Django REST Framework API
  ├── Routes        (predetermined routes, geometry, fare formula)
  ├── Vehicles       (Toyota Quantums, live GPS pings)
  ├── Trips/Boarding  (accountability trail)
  └── Routing service client (OSRM-compatible; falls back to straight-line)
        │
        ▼
   SQLite (swap for PostgreSQL in production — just change DATABASES)
```

No Google Maps JavaScript API, Directions API or billing account is used
anywhere. Map tiles + geocoding come from MapTiler; turn-by-turn directions
come from any OSRM-compatible routing service (self-hosted or the public
demo server), with an automatic straight-line fallback if none is
configured, so the whole system still works offline for development/testing.

## 1. Backend setup

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # or your preferred venv tool
pip install -r requirements.txt

cp .env.example .env
# Edit .env:
#   MAPTILER_API_KEY=...      (free key: https://cloud.maptiler.com/account/keys/)
#   ROUTING_SERVICE_URL=      (leave blank to use the built-in fallback, or
#                              point at your own OSRM instance)

python manage.py migrate
python manage.py seed_demo_data     # routes, Quantum vehicles AND demo login accounts
python manage.py createsuperuser    # optional, for /admin/

# Use runserver for plain REST, or daphne for REST + WebSocket live tracking:
python manage.py runserver          # http://127.0.0.1:8000  (Channels works here too)
```

### Demo accounts

`seed_demo_data` creates one account per THEMBA role, all with password
**`themba123`**:

| Username | Role | Can do |
|---|---|---|
| `passenger_demo` | passenger | search routes, see fares |
| `driver_demo` | driver | submit GPS for vehicle `ND 123-456` |
| `operator_demo` | operator | view the whole fleet + live tracking |
| `admin_demo` | administrator | same as operator |

Sign in via `POST /api/auth/login/`, which returns a token plus the role. The
frontend stores it in `sessionStorage` and attaches
`Authorization: Token <token>` to protected calls.

### Test the routing/fare/time/speed engine (no frontend needed)

```bash
# Automated tests (models, fare math, geo math, every API endpoint)
python manage.py test core

# CLI harness: search routes, check fare/time/speed for a destination,
# and step a vehicle along its route to sanity-check live tracking
python manage.py test_routing --destination-lat -28.7690 --destination-lng 32.0480
python manage.py test_routing --simulate "ND 123-456"
```

Or hit the API directly:

```bash
curl "http://127.0.0.1:8000/api/routes/search/?destination_lat=-28.769&destination_lng=32.048&origin_lat=-28.755&origin_lng=32.045"
curl "http://127.0.0.1:8000/api/routes/1/estimate/"
curl -X POST "http://127.0.0.1:8000/api/vehicles/1/simulate/" -H "Content-Type: application/json" -d '{"fraction": 0.5}'
curl "http://127.0.0.1:8000/api/vehicles/"
```

### Key endpoints

| Method | Path                                   | Purpose |
|---|---|---|
| GET/POST | `/api/routes/search/`                | Find predetermined routes serving a destination, with fare/time/speed |
| GET    | `/api/routes/{id}/estimate/`           | Fare/time/distance/speed for one route |
| GET    | `/api/routes/{id}/directions/`         | Route-line geometry (cached, or fetched from the routing service) |
| GET/POST | `/api/geocode/`                      | Server-side proxy to MapTiler Geocoding (keeps the key off the client) |
| GET    | `/api/vehicles/` , `/api/vehicles/{id}/` | Fleet + latest known location (for live tracking) |
| GET/POST | `/api/vehicles/{id}/location/`       | Poll the latest GPS ping / push a new one (driver app) |
| POST   | `/api/vehicles/{id}/simulate/`         | **TEST DATA.** Move a vehicle along its route by a 0–1 fraction. Records `source="simulated"`. Disabled unless `DEBUG=True` |
| POST   | `/api/auth/login/`                     | Returns a DRF token + THEMBA role |
| WS     | `ws/tracking/?token=<token>`           | Fleet-wide live position feed (operator/administrator only) |
| WS     | `ws/tracking/vehicle/{id}/`            | Single-vehicle live position feed |
| CRUD   | `/api/trips/`, `/api/boardings/`       | Trip instances and passenger boarding records |

## 2. Frontend setup

```bash
cd frontend
npm install

cp .env.example .env
# Edit .env:
#   VITE_API_BASE_URL=http://127.0.0.1:8000/api
#   VITE_MAPTILER_KEY=...   (same MapTiler account, a publishable key)

npm run dev      # http://localhost:5173
```

### What's new in the frontend

- `src/api/themba.js` — fetch wrapper for every backend endpoint above.
- `src/hooks/useGeolocation.js` — wraps `navigator.geolocation` for the
  "use my current location" start point.
- `src/routing/MapView.jsx` — MapLibre GL JS map (MapTiler style): route
  line, origin/destination pins, live vehicle markers with heading.
- `src/routing/RouteSearchScreen.jsx` — "Where are you going?" destination
  search (geocoded through the backend), plus "Choose on map".
- `src/routing/RouteSelectionScreen.jsx` — "Pick a Route" screen with the
  fare popup (fare, distance, speed, vehicle type).
- `src/routing/RoutingFlow.jsx` — wires search → select → confirmed together;
  this is what opens from the passenger dashboard's **"Open map & find
  route"** button.
- `src/routing/DevRoutingTester.jsx` — a raw dev panel (toggle "Dev test
  tools" inside the routing flow) to call search/simulate/vehicle-list
  directly and see the fare/time/distance/speed JSON — this is your
  quickest way to verify the routing engine end-to-end.
- `src/tracking/LiveTrackingPanel.jsx` — clickable vehicle list + map for
  operators/administrators, polling every 4s; opened via each dashboard's
  **"Open fleet map"** button. Drivers can also open a read-only version of
  this to see how they currently appear on the fleet map.

## 3. Trying it end-to-end

1. Start the backend (`runserver`) and seed data (`seed_demo_data`).
2. Start the frontend (`npm run dev`) and open it as a **passenger** (or
   guest) → **"Open map & find route"**.
3. Allow location access (or use "Choose on map") and search a destination
   near Richards Bay (e.g. type "Downtown" or "Cedar Park") — you'll see
   **Route 45 – Express** and **Route 78 – Rapid** matching the mockups,
   each with fare + time from the Django backend.
4. Pick a route → the fare popup shows fare/distance/speed/vehicle type →
   confirm to see the booked-trip summary.
5. Switch role to **operator** or **administrator** → **"Open fleet map"**
   to see all seeded vehicles. Use the backend's
   `python manage.py test_routing --simulate "ND 123-456"` (or
   `POST /api/vehicles/1/simulate/`) to move a vehicle and watch it update
   on the live map within ~4 seconds.

## 4. What's implemented against the routing spec

- **Live tracking over WebSockets** (Django Channels). The frontend's
  `useLiveTracking` hook prefers the socket and silently falls back to REST
  polling if Channels isn't reachable, so tracking never just dies.
- **Route deviation** — `core/services/deviation.py` measures the true
  perpendicular distance from the vehicle to the route polyline and reports
  `on_route` / `off_route` / `unknown` against a configurable threshold
  (`DEFAULT_ROUTE_DEVIATION_THRESHOLD_M`, overridable per-route via
  `Route.deviation_threshold_m`). Small GPS wobble does not trip it.
- **No fabricated GPS values** — `speed_kmh` is nullable end-to-end. When the
  browser reports no speed, the UI shows "Speed unavailable" rather than 0.
  Accuracy renders as `±X m` with a visual warning when it's poor.
- **Real vs test data is always labelled** — every `VehicleLocation` carries
  `source` (`gps` or `simulated`), and simulated values render with a
  `TEST DATA` badge. `/simulate/` is refused outside `DEBUG`.
- **Authorisation on tracking** — fleet views and the fleet WebSocket require
  an operator/administrator token; GPS pings are accepted only from the
  vehicle's assigned `driver_user`.
- **PWA** — `public/manifest.webmanifest` + a service worker that caches the
  app shell but deliberately never caches API, tile or WebSocket traffic.

### Still open

- Manual latitude/longitude entry fields for the start point (live GPS and
  map-click are implemented; raw coordinate entry is not yet wired into the
  search screen).
- Trip lifecycle UI for drivers (start/end trip); the `Trip` model and
  endpoints exist but the driver screen doesn't drive them yet.
- Redis channel layer is configured but untested against a real Redis; the
  in-memory layer is what's been exercised.

## 5. Going to production

- Point `ROUTING_SERVICE_URL` at a real OSRM (or GraphHopper) instance with
  South African road data loaded, instead of the demo server, for accurate
  turn-by-turn geometry, distance and duration.
- Swap SQLite for PostgreSQL (ideally with PostGIS if you want proper
  geospatial queries instead of the haversine-based proximity search here).
- Set `REDIS_URL` so the Channels layer is shared across processes — the
  default in-memory layer only works with a single backend process.
- Serve over HTTPS. Browsers block the Geolocation API on insecure origins,
  so live GPS will not work at all without it.
- Run under Daphne/Uvicorn (ASGI) rather than WSGI, or WebSockets won't be
  served.
