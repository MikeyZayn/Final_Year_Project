from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from django.core.management.base import BaseCommand

from core.models import Profile, Route, RouteStop, Vehicle

DEMO_PASSWORD = "themba123"


class Command(BaseCommand):
    help = "Seed predetermined routes, stops and demo Toyota Quantum vehicles."

    def handle(self, *args, **options):
        self.stdout.write("Seeding THEMBA demo data...")

        # --- Demo routes matching the passenger-app mockups (Cedar Park /
        # Old Quarter / Downtown Station), placed around Richards Bay so the
        # map has real streets to render against. ------------------------
        express, _ = Route.objects.update_or_create(
            code="TH-R045",
            defaults=dict(
                name="Route 45 - Express",
                origin_name="Cedar Park",
                origin_lat=-28.7550,
                origin_lng=32.0450,
                destination_name="Downtown Station (Old Quarter)",
                destination_lat=-28.7690,
                destination_lng=32.0480,
                geometry=[
                    [-28.7550, 32.0450],
                    [-28.7590, 32.0460],
                    [-28.7630, 32.0470],
                    [-28.7690, 32.0480],
                ],
                distance_km=5.8,
                average_duration_min=25,
                average_speed_kmh=14,
                vehicle_class=Route.VehicleClass.QUANTUM_15,
                base_fare=1.00,
                fare_per_km=0.26,
                operator_association="Richards Bay Taxi Association",
                is_active=True,
            ),
        )

        rapid, _ = Route.objects.update_or_create(
            code="TH-R078",
            defaults=dict(
                name="Route 78 - Rapid",
                origin_name="Cedar Park",
                origin_lat=-28.7550,
                origin_lng=32.0450,
                destination_name="Downtown Station (Old Quarter)",
                destination_lat=-28.7690,
                destination_lng=32.0480,
                geometry=[
                    [-28.7550, 32.0450],
                    [-28.7600, 32.0440],
                    [-28.7650, 32.0460],
                    [-28.7690, 32.0480],
                ],
                distance_km=6.4,
                average_duration_min=18,
                average_speed_kmh=21,
                vehicle_class=Route.VehicleClass.QUANTUM_15,
                base_fare=1.00,
                fare_per_km=0.31,
                operator_association="Richards Bay Taxi Association",
                is_active=True,
            ),
        )

        # --- Real long-distance THEMBA routes (matching the existing React
        # demo data: Empangeni <-> Durban / Richards Bay). -----------------
        emp_durban, _ = Route.objects.update_or_create(
            code="TH-EMP-001",
            defaults=dict(
                name="Empangeni to Durban",
                origin_name="Empangeni",
                origin_lat=-28.7808,
                origin_lng=31.8925,
                destination_name="Durban",
                destination_lat=-29.8587,
                destination_lng=31.0218,
                geometry=[
                    [-28.7808, 31.8925],
                    [-29.1500, 31.4200],
                    [-29.6000, 31.1500],
                    [-29.8587, 31.0218],
                ],
                distance_km=168,
                average_duration_min=200,
                average_speed_kmh=68,
                vehicle_class=Route.VehicleClass.QUANTUM_22,
                base_fare=15.00,
                fare_per_km=0.42,
                operator_association="Empangeni Long Distance Taxi Association",
                is_active=True,
            ),
        )

        emp_rbay, _ = Route.objects.update_or_create(
            code="TH-EMP-002",
            defaults=dict(
                name="Empangeni to Richards Bay",
                origin_name="Empangeni",
                origin_lat=-28.7808,
                origin_lng=31.8925,
                destination_name="Richards Bay",
                destination_lat=-28.7810,
                destination_lng=32.0377,
                geometry=[
                    [-28.7808, 31.8925],
                    [-28.7809, 31.9600],
                    [-28.7810, 32.0377],
                ],
                distance_km=24,
                average_duration_min=35,
                average_speed_kmh=45,
                vehicle_class=Route.VehicleClass.QUANTUM_15,
                base_fare=8.00,
                fare_per_km=1.10,
                operator_association="Empangeni Taxi Association",
                is_active=True,
            ),
        )

        RouteStop.objects.filter(route__in=[express, rapid, emp_durban, emp_rbay]).delete()
        RouteStop.objects.bulk_create(
            [
                RouteStop(route=express, name="Cedar Park Rank", lat=-28.7550, lng=32.0450, order=0, fare_from_origin=0),
                RouteStop(route=express, name="Riverside Reading Room", lat=-28.7620, lng=32.0465, order=1, fare_from_origin=1.50),
                RouteStop(route=express, name="Downtown Station", lat=-28.7690, lng=32.0480, order=2, fare_from_origin=2.50),

                RouteStop(route=emp_durban, name="Empangeni Rank", lat=-28.7808, lng=31.8925, order=0, fare_from_origin=0),
                RouteStop(route=emp_durban, name="Gingindlovu", lat=-29.0167, lng=31.6167, order=1, fare_from_origin=45),
                RouteStop(route=emp_durban, name="Durban Rank", lat=-29.8587, lng=31.0218, order=2, fare_from_origin=85),

                RouteStop(route=emp_rbay, name="Empangeni Rank", lat=-28.7808, lng=31.8925, order=0, fare_from_origin=0),
                RouteStop(route=emp_rbay, name="Richards Bay Rank", lat=-28.7810, lng=32.0377, order=1, fare_from_origin=35),
            ]
        )

        # --- Vehicles: mostly Toyota Quantums. ----------------------------
        vehicles = [
            dict(registration="ND 123-456", route=express, driver_name="Bongani Mthembu", seating_capacity=15),
            dict(registration="ND 654-321", route=rapid, driver_name="Thabo Nkosi", seating_capacity=15),
            dict(registration="ND 789-012", route=emp_durban, driver_name="Sipho Zulu", seating_capacity=22),
            dict(registration="ND 345-678", route=emp_rbay, driver_name="Nomvula Khumalo", seating_capacity=15),
        ]
        created_vehicles = []
        for data in vehicles:
            vehicle, _ = Vehicle.objects.update_or_create(
                registration=data["registration"],
                defaults=dict(
                    make="Toyota",
                    model="Quantum",
                    seating_capacity=data["seating_capacity"],
                    driver_name=data["driver_name"],
                    route=data["route"],
                    status=Vehicle.Status.QUEUED,
                ),
            )
            created_vehicles.append(vehicle)

        # --- Demo login accounts, one per THEMBA role. ---------------------
        # Password for all of them: DEMO_PASSWORD ("themba123"). The driver
        # account is linked to the first seeded vehicle so it can POST GPS
        # updates to /api/vehicles/{id}/location/.
        User = get_user_model()
        demo_users = [
            ("passenger_demo", Profile.Role.PASSENGER),
            ("driver_demo", Profile.Role.DRIVER),
            ("operator_demo", Profile.Role.OPERATOR),
            ("admin_demo", Profile.Role.ADMINISTRATOR),
        ]
        for username, role in demo_users:
            user, _ = User.objects.update_or_create(
                username=username,
                defaults=dict(password=make_password(DEMO_PASSWORD)),
            )
            Profile.objects.update_or_create(user=user, defaults={"role": role})
            if role == Profile.Role.DRIVER and created_vehicles:
                created_vehicles[0].driver_user = user
                created_vehicles[0].save(update_fields=["driver_user"])

        self.stdout.write(self.style.SUCCESS(
            f"Seeded {Route.objects.count()} routes, {Vehicle.objects.count()} vehicles, "
            f"and demo users (passenger_demo / driver_demo / operator_demo / admin_demo, "
            f"password '{DEMO_PASSWORD}')."
        ))
