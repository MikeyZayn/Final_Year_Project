"""
Developer harness for exercising the routing / fare / time / speed logic
end-to-end from the command line, without needing the React frontend or a
real GPS device running.

Usage:
    python manage.py test_routing
    python manage.py test_routing --destination-lat -28.7690 --destination-lng 32.0480
    python manage.py test_routing --simulate ND\ 123-456
"""
from django.core.management.base import BaseCommand

from core.models import Route, Vehicle
from core.services import fare_service, geo
from core.services.routing_service import get_driving_route


class Command(BaseCommand):
    help = "Exercise route search, fare/time/speed estimation and vehicle simulation."

    def add_arguments(self, parser):
        parser.add_argument("--origin-lat", type=float, default=-28.7550)
        parser.add_argument("--origin-lng", type=float, default=32.0450)
        parser.add_argument("--destination-lat", type=float, default=-28.7690)
        parser.add_argument("--destination-lng", type=float, default=32.0480)
        parser.add_argument(
            "--simulate", type=str, default=None,
            help="Vehicle registration to step through a simulated trip, e.g. 'ND 123-456'",
        )

    def handle(self, *args, **options):
        origin = (options["origin_lat"], options["origin_lng"])
        destination = (options["destination_lat"], options["destination_lng"])

        self.stdout.write(self.style.MIGRATE_HEADING("1. Route search by destination"))
        matches = fare_service.find_matching_routes(destination, origin=origin)
        if not matches:
            self.stdout.write(self.style.WARNING("  No predetermined routes match this destination."))
        for route in matches:
            estimate = fare_service.estimate_for_route(route, origin=origin, destination=destination)
            d = estimate.as_dict()
            self.stdout.write(
                f"  [{d['route_code']}] {d['route_name']}: "
                f"R{d['fare']} | {d['distance_km']} km | {d['duration_min']} min | "
                f"{d['average_speed_kmh']} km/h | {d['from_stop']} -> {d['to_stop']}"
            )

        self.stdout.write(self.style.MIGRATE_HEADING("\n2. Raw distance/speed sanity check (haversine)"))
        straight_km = geo.haversine_km(*origin, *destination)
        self.stdout.write(f"  Straight-line distance: {straight_km:.2f} km")

        self.stdout.write(self.style.MIGRATE_HEADING("\n3. Directions service (OSRM or fallback)"))
        directions = get_driving_route(origin, destination)
        self.stdout.write(
            f"  source={directions['source']} distance={directions['distance_km']} km "
            f"duration={directions['duration_min']} min "
            f"points={len(directions['geometry'])}"
        )

        if options["simulate"]:
            self._simulate(options["simulate"])

    def _simulate(self, registration):
        self.stdout.write(self.style.MIGRATE_HEADING(f"\n4. Simulating vehicle '{registration}' along its route"))
        try:
            vehicle = Vehicle.objects.select_related("route").get(registration=registration)
        except Vehicle.DoesNotExist:
            self.stdout.write(self.style.ERROR(f"  No vehicle with registration '{registration}'."))
            return

        route = vehicle.route
        if not route or not route.geometry:
            self.stdout.write(self.style.ERROR("  Vehicle has no route/geometry assigned."))
            return

        points = [tuple(p) for p in route.geometry]
        prev_point = None
        for step in range(0, 11):
            fraction = step / 10
            point = geo.point_at_fraction(points, fraction)
            heading = geo.bearing_deg(*prev_point, *point) if prev_point else 0
            prev_point = point
            self.stdout.write(
                f"  t={fraction:.1f}  lat={point[0]:.5f} lng={point[1]:.5f} "
                f"heading={heading:.0f} deg  speed={route.average_speed_kmh} km/h"
            )
