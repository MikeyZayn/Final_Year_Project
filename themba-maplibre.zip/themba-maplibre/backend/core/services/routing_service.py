"""
Thin client for an OSRM-compatible turn-by-turn routing service.

THEMBA does not use Google Maps' Directions API. Instead it talks to any
service that implements the OSRM HTTP API (self-hosted OSRM/GraphHopper, or
the public OSRM demo server for development). If the service is unreachable
(offline dev, no internet in CI, etc.) we fall back to a straight-line
haversine estimate so routing/fare/time calculations still work end-to-end.

Geocoding (turning a typed address into lat/lng) is done via the MapTiler
Geocoding API, proxied through `geocode()` below so the API key never has to
sit in frontend JS.
"""
import logging

import requests
from django.conf import settings

from .geo import haversine_km

logger = logging.getLogger(__name__)


class RoutingServiceError(Exception):
    pass


def get_driving_route(origin, destination, timeout=5):
    """
    origin / destination: (lat, lng) tuples.

    Returns a dict:
        {
            "geometry": [[lat, lng], ...],
            "distance_km": float,
            "duration_min": float,
            "source": "osrm" | "fallback",
        }
    """
    base_url = getattr(settings, "ROUTING_SERVICE_URL", None)
    if base_url:
        try:
            # OSRM expects lng,lat order.
            coords = f"{origin[1]},{origin[0]};{destination[1]},{destination[0]}"
            url = f"{base_url.rstrip('/')}/route/v1/driving/{coords}"
            response = requests.get(
                url,
                params={"overview": "full", "geometries": "geojson"},
                timeout=timeout,
            )
            response.raise_for_status()
            payload = response.json()
            route = payload["routes"][0]
            coordinates = route["geometry"]["coordinates"]  # [[lng, lat], ...]
            geometry = [[lat, lng] for lng, lat in coordinates]
            return {
                "geometry": geometry,
                "distance_km": round(route["distance"] / 1000, 3),
                "duration_min": round(route["duration"] / 60, 1),
                "source": "osrm",
            }
        except Exception as exc:  # noqa: BLE001 - degrade gracefully in all cases
            logger.warning("Routing service unavailable, using fallback: %s", exc)

    return _fallback_route(origin, destination)


def _fallback_route(origin, destination, average_speed_kmh=35.0):
    distance_km = haversine_km(origin[0], origin[1], destination[0], destination[1])
    duration_min = (distance_km / average_speed_kmh) * 60
    return {
        "geometry": [list(origin), list(destination)],
        "distance_km": round(distance_km, 3),
        "duration_min": round(duration_min, 1),
        "source": "fallback",
    }


def geocode(query, proximity=None, limit=5, timeout=5):
    """
    Forward-geocode a free-text query using the MapTiler Geocoding API.
    Returns a list of {"name", "lat", "lng"} candidates, most relevant first.
    """
    api_key = getattr(settings, "MAPTILER_API_KEY", "")
    if not api_key:
        raise RoutingServiceError(
            "MAPTILER_API_KEY is not configured on the backend (.env)."
        )

    url = f"https://api.maptiler.com/geocoding/{requests.utils.quote(query)}.json"
    params = {"key": api_key, "limit": limit}
    if proximity:
        params["proximity"] = f"{proximity[1]},{proximity[0]}"  # lng,lat

    response = requests.get(url, params=params, timeout=timeout)
    response.raise_for_status()
    data = response.json()

    results = []
    for feature in data.get("features", []):
        lng, lat = feature["geometry"]["coordinates"]
        results.append(
            {
                "name": feature.get("place_name", feature.get("text", query)),
                "lat": lat,
                "lng": lng,
            }
        )
    return results
