from rest_framework.permissions import BasePermission, SAFE_METHODS


def _role(user):
    profile = getattr(user, 'profile', None)
    return profile.role if profile else None


class IsOperatorOrAdmin(BasePermission):
    """Fleet-wide tracking views: only operator/administrator accounts."""

    message = "Only operators and administrators can view the full fleet."

    def has_permission(self, request, view):
        return bool(
            request.user
            and request.user.is_authenticated
            and _role(request.user) in ('operator', 'administrator')
        )


class IsAssignedDriverForLocationPost(BasePermission):
    """
    GPS pings (POST /api/vehicles/{id}/location/) may only be submitted by
    the driver account assigned to that vehicle. GET (reading the latest
    ping) stays open, matching the single-vehicle WebSocket feed's model:
    knowing the vehicle id is the same level of access as a booked trip.
    """

    message = "Only the assigned driver can submit GPS updates for this vehicle."

    def has_object_permission(self, request, view, vehicle):
        if request.method in SAFE_METHODS:
            return True
        return bool(
            request.user
            and request.user.is_authenticated
            and vehicle.driver_user_id == request.user.id
        )
