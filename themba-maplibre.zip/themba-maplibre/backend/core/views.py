from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.conf import settings
from django.contrib.auth import authenticate
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import status, viewsets
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from .consumers import FLEET_GROUP, vehicle_group_name
from .models import Boarding, Route, Trip, Vehicle, VehicleLocation
from .permissions import IsAssignedDriverForLocationPost, IsOperatorOrAdmin
from .serializers import (
    BoardingSerializer,
    ProfileSerializer,
    RouteSerializer,
    TripSerializer,
    VehicleLocationSerializer,
    VehicleSerializer,
)
from .services import deviation, fare_service, geo
from .services.routing_service import RoutingServiceError, geocode, get_driving_route


def _point_from_request(data, prefix):
    lat = data.get(f"{prefix}_lat")
    lng = data.get(f"{prefix}_lng")
    if lat is None or lng is None:
        return None
    return (float(lat), float(lng))


def _broadcast_vehicle_location(vehicle, location, deviation_result):
    """Push a location update to both the fleet feed and this vehicle's own feed."""
    channel_layer = get_channel_layer()
    if channel_layer is None:
        return

    payload = {
        "type": "vehicle.location",
        "vehicle_id": vehicle.id,
        "registration": vehicle.registration,
        "route_id": vehicle.route_id,
        **VehicleLocationSerializer(location).data,
        **deviation_result.as_dict(),
    }
    # VehicleLocationSerializer's `recorded_at` isn't JSON-serialisable as-is
    # inside a dict headed for the channel layer; stringify it explicitly.
    payload["recorded_at"] = location.recorded_at.isoformat()

    for group in (FLEET_GROUP, vehicle_group_name(vehicle.id)):
        async_to_sync(channel_layer.group_send)(group, {"type": "vehicle.location", "payload": payload})


@api_view(["POST"])
@permission_classes([AllowAny])
def login_view(request):
    """
    POST /api/auth/login/  { "username": "...", "password": "..." }

    Returns a DRF token plus the account's THEMBA role, so the frontend can
    attach `Authorization: Token <token>` to protected requests (fleet
    tracking, GPS pings) and route the user to the right dashboard.
    """
    username = request.data.get("username", "")
    password = request.data.get("password", "")
    user = authenticate(request, username=username, password=password)
    if user is None:
        return Response({"error": "Invalid username or password."}, status=status.HTTP_401_UNAUTHORIZED)

    token, _ = Token.objects.get_or_create(user=user)
    return Response(
        {
            "token": token.key,
            "username": user.username,
            "role": ProfileSerializer(user.profile).data["role"],
        }
    )


class RouteViewSet(viewsets.ReadOnlyModelViewSet):
    """
    GET /api/routes/            -> list all predetermined routes
    GET /api/routes/{id}/       -> route detail incl. geometry + stops
    """

    queryset = Route.objects.filter(is_active=True).prefetch_related("stops")
    serializer_class = RouteSerializer


@api_view(["GET", "POST"])
def search_routes(request):
    """
    Search predetermined routes by destination, with an optional origin
    (manual point or the passenger's live GPS location).

    Body / query params:
        destination_lat, destination_lng   (required)
        origin_lat, origin_lng              (optional - manual start point)
        use_live_location                   (bool, informational only -
                                              the actual coordinates still
                                              come from origin_lat/lng,
                                              which the frontend fills in
                                              from navigator.geolocation)

    Returns each matching route with distance/duration/fare/speed for the
    requested segment, ready to render as the "Pick a Route" list.
    """
    data = request.data if request.method == "POST" else request.query_params

    destination = _point_from_request(data, "destination")
    if destination is None:
        return Response(
            {"error": "destination_lat and destination_lng are required."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    origin = _point_from_request(data, "origin")
    max_distance_km = float(data.get("max_distance_km", 5.0))

    matching_routes = fare_service.find_matching_routes(
        destination, origin=origin, max_distance_km=max_distance_km
    )

    results = [
        fare_service.estimate_for_route(route, origin=origin, destination=destination).as_dict()
        for route in matching_routes
    ]

    return Response(
        {
            "origin": {"lat": origin[0], "lng": origin[1]} if origin else None,
            "destination": {"lat": destination[0], "lng": destination[1]},
            "route_options": results,
            "count": len(results),
        }
    )


@api_view(["GET"])
def route_estimate(request, route_id):
    """
    GET /api/routes/{id}/estimate/?origin_lat=...&origin_lng=...&destination_lat=...&destination_lng=...

    Fare/time/distance/speed for one specific predetermined route - this
    backs the fare popup shown after a route is picked.
    """
    route = get_object_or_404(Route, pk=route_id, is_active=True)
    origin = _point_from_request(request.query_params, "origin")
    destination = _point_from_request(request.query_params, "destination")

    estimate = fare_service.estimate_for_route(route, origin=origin, destination=destination)
    payload = estimate.as_dict()
    payload["geometry"] = route.geometry or None
    return Response(payload)


@api_view(["GET"])
def route_directions(request, route_id):
    """
    GET /api/routes/{id}/directions/

    Returns the routing-line geometry for a route. If the route has no
    stored geometry, it is fetched once from the external routing service
    (OSRM-compatible) and cached back onto the Route.
    """
    route = get_object_or_404(Route, pk=route_id, is_active=True)

    if route.geometry:
        return Response(
            {
                "geometry": route.geometry,
                "distance_km": route.distance_km,
                "duration_min": route.average_duration_min,
                "source": "cached",
            }
        )

    origin = (route.origin_lat, route.origin_lng)
    destination = (route.destination_lat, route.destination_lng)
    directions = get_driving_route(origin, destination)

    route.geometry = directions["geometry"]
    route.distance_km = directions["distance_km"]
    route.average_duration_min = directions["duration_min"]
    route.save(update_fields=["geometry", "distance_km", "average_duration_min"])

    return Response(directions)


@api_view(["GET", "POST"])
def geocode_view(request):
    """
    GET/POST /api/geocode/?query=...&proximity_lat=...&proximity_lng=...

    Server-side proxy to the MapTiler Geocoding API so the API key stays out
    of frontend bundles. Used by the "Where are you going?" search box.
    """
    data = request.data if request.method == "POST" else request.query_params
    query = data.get("query", "").strip()
    if not query:
        return Response({"error": "query is required."}, status=status.HTTP_400_BAD_REQUEST)

    proximity = _point_from_request(data, "proximity")

    try:
        results = geocode(query, proximity=proximity)
    except RoutingServiceError as exc:
        return Response({"error": str(exc)}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
    except Exception as exc:  # noqa: BLE001
        return Response({"error": f"Geocoding failed: {exc}"}, status=status.HTTP_502_BAD_GATEWAY)

    return Response({"query": query, "results": results})


class VehicleViewSet(viewsets.ReadOnlyModelViewSet):
    """
    GET /api/vehicles/           -> all vehicles + latest known location
    GET /api/vehicles/?route=ID  -> vehicles currently on a given route
    GET /api/vehicles/{id}/      -> single vehicle detail

    This is what the operator/administrator "live tracking" screen reads
    (over REST for the initial load; the WebSocket feed keeps it updated
    after that). Restricted to operator/administrator accounts - a
    passenger only ever gets one vehicle's position, via the trip they
    booked, not the whole fleet.
    """

    serializer_class = VehicleSerializer
    permission_classes = [IsOperatorOrAdmin]

    def get_queryset(self):
        queryset = Vehicle.objects.select_related("route").prefetch_related("locations").order_by("id")
        route_id = self.request.query_params.get("route")
        if route_id:
            queryset = queryset.filter(route_id=route_id)
        status_filter = self.request.query_params.get("status")
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        return queryset


@api_view(["GET", "POST"])
def vehicle_location(request, vehicle_id):
    """
    GET  /api/vehicles/{id}/location/  -> latest ping (for map polling/WS bootstrap)
    POST /api/vehicles/{id}/location/  -> driver app pushes a new GPS ping.
        Requires the requesting user to be that vehicle's assigned driver.
        body: { lat, lng, speed_kmh (omit/null if unavailable), heading_deg, accuracy_m }
    """
    vehicle = get_object_or_404(Vehicle, pk=vehicle_id)

    if request.method == "GET":
        location = vehicle.locations.first()
        if not location:
            return Response({"error": "No location recorded yet."}, status=404)
        payload = VehicleLocationSerializer(location).data
        payload.update(deviation.check_deviation(location.lat, location.lng, vehicle.route).as_dict())
        return Response(payload)

    if not request.user.is_authenticated:
        return Response({"error": "Authentication required to submit GPS updates."}, status=401)
    if vehicle.driver_user_id != request.user.id:
        return Response({"error": "You are not the assigned driver for this vehicle."}, status=403)

    serializer = VehicleLocationSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    location = VehicleLocation.objects.create(
        vehicle=vehicle, source=VehicleLocation.Source.GPS, **serializer.validated_data
    )
    vehicle.status = Vehicle.Status.ACTIVE
    vehicle.save(update_fields=["status"])

    deviation_result = deviation.check_deviation(location.lat, location.lng, vehicle.route)
    _broadcast_vehicle_location(vehicle, location, deviation_result)

    payload = VehicleLocationSerializer(location).data
    payload.update(deviation_result.as_dict())
    return Response(payload, status=status.HTTP_201_CREATED)


@api_view(["POST"])
@permission_classes([AllowAny])
def simulate_vehicle_movement(request, vehicle_id):
    """
    POST /api/vehicles/{id}/simulate/
        body: { "fraction": 0.0-1.0 }

    TEST-DATA-ONLY endpoint: moves a vehicle to a point `fraction` of the way
    along its assigned route's geometry and records a location ping with a
    derived speed/heading, without needing a real device with GPS. Every
    location it creates is tagged source="simulated" so it's clearly
    distinguishable from real driver GPS everywhere it's displayed. Only
    available while the backend runs with DEBUG=True.
    """
    if not settings.DEBUG:
        return Response(
            {"error": "Simulation is a development/test tool and is disabled outside DEBUG mode."},
            status=status.HTTP_403_FORBIDDEN,
        )

    vehicle = get_object_or_404(Vehicle, pk=vehicle_id)
    if not vehicle.route or not vehicle.route.geometry:
        return Response(
            {"error": "Vehicle has no assigned route or the route has no geometry yet. "
                      "Call /api/routes/{id}/directions/ first."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    fraction = float(request.data.get("fraction", 0.0))
    fraction = max(0.0, min(1.0, fraction))

    points = [tuple(p) for p in vehicle.route.geometry]
    point = geo.point_at_fraction(points, fraction)

    # Derive heading from the previous simulated position, if any.
    previous = vehicle.locations.first()
    heading = previous.heading_deg if previous else 0
    if previous and (previous.lat, previous.lng) != point:
        heading = geo.bearing_deg(previous.lat, previous.lng, point[0], point[1])

    speed = vehicle.route.average_speed_kmh

    location = VehicleLocation.objects.create(
        vehicle=vehicle,
        lat=point[0],
        lng=point[1],
        speed_kmh=speed,
        heading_deg=heading,
        accuracy_m=8,
        source=VehicleLocation.Source.SIMULATED,
        recorded_at=timezone.now(),
    )
    vehicle.status = Vehicle.Status.ACTIVE
    vehicle.save(update_fields=["status"])

    deviation_result = deviation.check_deviation(location.lat, location.lng, vehicle.route)
    _broadcast_vehicle_location(vehicle, location, deviation_result)

    return Response(
        {
            "vehicle": vehicle.registration,
            "route": vehicle.route.code,
            "fraction": fraction,
            "location": VehicleLocationSerializer(location).data,
            **deviation_result.as_dict(),
        }
    )


class TripViewSet(viewsets.ModelViewSet):
    """Trips (route + vehicle instance). Passengers verify by trip code."""

    queryset = Trip.objects.select_related("route", "vehicle")
    serializer_class = TripSerializer


class BoardingViewSet(viewsets.ModelViewSet):
    """Passenger boarding records against a trip."""

    queryset = Boarding.objects.select_related("trip", "boarding_stop")
    serializer_class = BoardingSerializer
