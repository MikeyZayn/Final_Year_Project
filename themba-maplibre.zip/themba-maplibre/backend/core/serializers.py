from rest_framework import serializers

from .models import Boarding, Profile, Route, RouteStop, Trip, Vehicle, VehicleLocation


class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = ["role"]


class RouteStopSerializer(serializers.ModelSerializer):
    class Meta:
        model = RouteStop
        fields = ["id", "name", "lat", "lng", "order", "fare_from_origin"]


class RouteSerializer(serializers.ModelSerializer):
    stops = RouteStopSerializer(many=True, read_only=True)
    vehicle_class_display = serializers.CharField(
        source="get_vehicle_class_display", read_only=True
    )

    class Meta:
        model = Route
        fields = [
            "id",
            "name",
            "code",
            "origin_name",
            "origin_lat",
            "origin_lng",
            "destination_name",
            "destination_lat",
            "destination_lng",
            "geometry",
            "distance_km",
            "average_duration_min",
            "average_speed_kmh",
            "vehicle_class",
            "vehicle_class_display",
            "base_fare",
            "fare_per_km",
            "operator_association",
            "is_active",
            "deviation_threshold_m",
            "stops",
        ]


class RouteSummarySerializer(serializers.ModelSerializer):
    """Lightweight representation used inside search/estimate responses."""

    class Meta:
        model = Route
        fields = ["id", "name", "code", "origin_name", "destination_name", "vehicle_class"]


class VehicleLocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehicleLocation
        fields = ["lat", "lng", "speed_kmh", "heading_deg", "accuracy_m", "source", "recorded_at"]
        extra_kwargs = {"speed_kmh": {"required": False, "allow_null": True}}


class VehicleSerializer(serializers.ModelSerializer):
    route = RouteSummarySerializer(read_only=True)
    latest_location = serializers.SerializerMethodField()

    class Meta:
        model = Vehicle
        fields = [
            "id",
            "registration",
            "make",
            "model",
            "seating_capacity",
            "operator_code",
            "driver_name",
            "status",
            "route",
            "latest_location",
        ]

    def get_latest_location(self, obj):
        location = obj.locations.first()
        return VehicleLocationSerializer(location).data if location else None


class TripSerializer(serializers.ModelSerializer):
    route = RouteSummarySerializer(read_only=True)
    vehicle = VehicleSerializer(read_only=True)

    class Meta:
        model = Trip
        fields = [
            "id",
            "route",
            "vehicle",
            "status",
            "departure_time",
            "estimated_arrival",
            "fare_charged",
            "verification_code",
        ]


class BoardingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Boarding
        fields = [
            "id",
            "trip",
            "passenger_name",
            "passenger_phone",
            "boarding_stop",
            "fare_paid",
            "boarded_at",
        ]
        read_only_fields = ["boarded_at"]
