"""
Live vehicle tracking over WebSocket.

Two kinds of connections:

  ws/tracking/                 - "fleet" feed: every vehicle's position as it
                                  updates. Used by the operator/administrator
                                  Live Tracking screen. Requires an
                                  authenticated operator/administrator token
                                  (see TrackingConsumer.connect).

  ws/tracking/vehicle/<id>/    - single-vehicle feed. Used by a passenger who
                                  has booked a trip on that vehicle, and by
                                  the driver's own "am I on route" display.
                                  Open to anyone who knows the vehicle id,
                                  same as the REST vehicle-location GET.

Messages sent to clients look like:
    {
        "type": "vehicle.location",
        "vehicle_id": 1,
        "registration": "ND 123-456",
        "lat": -28.76, "lng": 32.046,
        "speed_kmh": 24.5, "heading_deg": 90, "accuracy_m": 8,
        "recorded_at": "...",
        "source": "gps" | "simulated",
        "route_status": "on_route" | "off_route" | "unknown",
        "distance_from_route_m": 12.4
    }
"""
import json

from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncJsonWebsocketConsumer
from rest_framework.authtoken.models import Token

FLEET_GROUP = 'tracking_fleet'


def vehicle_group_name(vehicle_id):
    return f'tracking_vehicle_{vehicle_id}'


class BaseTrackingConsumer(AsyncJsonWebsocketConsumer):
    group_name = None

    async def connect(self):
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.accept()

    async def disconnect(self, code):
        if self.group_name:
            await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def vehicle_location(self, event):
        """Handler for channel-layer messages of type 'vehicle.location'."""
        await self.send_json(event['payload'])

    # Clients don't need to send anything for the read-only feeds below, but
    # accept pings without erroring so browsers can keep the socket alive.
    async def receive(self, text_data=None, bytes_data=None):
        return


class FleetTrackingConsumer(BaseTrackingConsumer):
    """
    ws/tracking/ - all vehicles. Requires a token belonging to an
    operator/administrator, passed as ?token=... on the connection URL
    (browsers can't set custom headers on WebSocket handshakes).
    """

    group_name = FLEET_GROUP

    async def connect(self):
        token_key = self._token_from_query_string()
        user = await self._user_for_token(token_key)

        if user is None or not await self._is_operator_or_admin(user):
            await self.close(code=4401)
            return

        await super().connect()

    def _token_from_query_string(self):
        query_string = self.scope.get('query_string', b'').decode()
        params = dict(pair.split('=', 1) for pair in query_string.split('&') if '=' in pair)
        return params.get('token')

    @database_sync_to_async
    def _user_for_token(self, token_key):
        if not token_key:
            return None
        try:
            return Token.objects.select_related('user', 'user__profile').get(key=token_key).user
        except Token.DoesNotExist:
            return None

    @database_sync_to_async
    def _is_operator_or_admin(self, user):
        profile = getattr(user, 'profile', None)
        return bool(profile and profile.role in ('operator', 'administrator'))


class VehicleTrackingConsumer(BaseTrackingConsumer):
    """ws/tracking/vehicle/<vehicle_id>/ - single-vehicle feed, open access."""

    async def connect(self):
        self.vehicle_id = self.scope['url_route']['kwargs']['vehicle_id']
        self.group_name = vehicle_group_name(self.vehicle_id)
        await super().connect()
