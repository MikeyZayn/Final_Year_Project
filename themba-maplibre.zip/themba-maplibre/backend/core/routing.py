from django.urls import re_path

from . import consumers

websocket_urlpatterns = [
    re_path(r'^ws/tracking/vehicle/(?P<vehicle_id>\d+)/$', consumers.VehicleTrackingConsumer.as_asgi()),
    re_path(r'^ws/tracking/$', consumers.FleetTrackingConsumer.as_asgi()),
]
