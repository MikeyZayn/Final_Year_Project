from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse
from rest_framework.authtoken.models import Token
from rest_framework.test import APIClient

from .models import Profile, Route, RouteStop, Vehicle
from .services import deviation, fare_service, geo

User = get_user_model()


class GeoServiceTests(TestCase):
    def test_haversine_known_distance(self):
        # Empangeni -> Richards Bay is roughly 24km by road, so straight
        # line should be a bit shorter but in the same ballpark.
        distance = geo.haversine_km(-28.7808, 31.8925, -28.7810, 32.0377)
        self.assertGreater(distance, 10)
        self.assertLess(distance, 20)

    def test_point_at_fraction_endpoints(self):
        points = [(-28.75, 32.04), (-28.76, 32.045), (-28.77, 32.048)]
        self.assertEqual(geo.point_at_fraction(points, 0), points[0])
        self.assertEqual(geo.point_at_fraction(points, 1), points[-1])

    def test_bearing_is_within_range(self):
        bearing = geo.bearing_deg(-28.75, 32.04, -28.77, 32.048)
        self.assertGreaterEqual(bearing, 0)
        self.assertLess(bearing, 360)


class FareServiceTests(TestCase):
    def setUp(self):
        self.route = Route.objects.create(
            name="Test Express",
            code="TH-TEST",
            origin_name="A",
            origin_lat=-28.7550,
            origin_lng=32.0450,
            destination_name="B",
            destination_lat=-28.7690,
            destination_lng=32.0480,
            geometry=[[-28.7550, 32.0450], [-28.7690, 32.0480]],
            distance_km=5.8,
            average_duration_min=25,
            average_speed_kmh=14,
            base_fare=1.00,
            fare_per_km=0.26,
        )

    def test_estimated_fare_matches_formula(self):
        fare = self.route.estimated_fare()
        expected = 1.00 + 0.26 * 5.8
        self.assertAlmostEqual(fare, round(expected, 2), places=2)

    def test_full_route_estimate_rounds_to_taxi_fare(self):
        estimate = fare_service.estimate_for_route(self.route)
        # Fare should be rounded to the nearest 50c increment.
        self.assertEqual(round(estimate.fare * 2) / 2, estimate.fare)

    def test_find_matching_routes_by_destination(self):
        matches = fare_service.find_matching_routes((-28.7690, 32.0480))
        self.assertIn(self.route, matches)

    def test_find_matching_routes_excludes_far_destinations(self):
        matches = fare_service.find_matching_routes((-29.8587, 31.0218), max_distance_km=5)
        self.assertNotIn(self.route, matches)


class RoutingApiTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.route = Route.objects.create(
            name="Route 45 - Express",
            code="TH-R045",
            origin_name="Cedar Park",
            origin_lat=-28.7550,
            origin_lng=32.0450,
            destination_name="Downtown Station",
            destination_lat=-28.7690,
            destination_lng=32.0480,
            geometry=[[-28.7550, 32.0450], [-28.7690, 32.0480]],
            distance_km=5.8,
            average_duration_min=25,
            average_speed_kmh=14,
            base_fare=1.00,
            fare_per_km=0.26,
        )
        self.driver_user = User.objects.create_user(username="driver1", password="pw12345")
        self.driver_user.profile.role = Profile.Role.DRIVER
        self.driver_user.profile.save()

        self.other_user = User.objects.create_user(username="driver2", password="pw12345")
        self.other_user.profile.role = Profile.Role.DRIVER
        self.other_user.profile.save()

        self.operator_user = User.objects.create_user(username="operator1", password="pw12345")
        self.operator_user.profile.role = Profile.Role.OPERATOR
        self.operator_user.profile.save()

        self.vehicle = Vehicle.objects.create(
            registration="ND 123-456",
            route=self.route,
            driver_name="Bongani Mthembu",
            driver_user=self.driver_user,
        )

    def _auth(self, user):
        token, _ = Token.objects.get_or_create(user=user)
        self.client.credentials(HTTP_AUTHORIZATION=f"Token {token.key}")

    def test_search_routes_endpoint(self):
        response = self.client.get(
            "/api/routes/search/",
            {
                "destination_lat": -28.7690,
                "destination_lng": 32.0480,
                "origin_lat": -28.7550,
                "origin_lng": 32.0450,
            },
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 1)
        self.assertEqual(response.data["route_options"][0]["route_code"], "TH-R045")

    def test_route_estimate_endpoint(self):
        response = self.client.get(f"/api/routes/{self.route.id}/estimate/")
        self.assertEqual(response.status_code, 200)
        self.assertIn("fare", response.data)
        self.assertIn("average_speed_kmh", response.data)

    def test_route_directions_endpoint_uses_cached_geometry(self):
        response = self.client.get(f"/api/routes/{self.route.id}/directions/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["source"], "cached")

    def test_login_returns_token_and_role(self):
        response = self.client.post(
            "/api/auth/login/", {"username": "driver1", "password": "pw12345"}, format="json"
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["role"], "driver")
        self.assertTrue(response.data["token"])

    def test_login_rejects_bad_password(self):
        response = self.client.post(
            "/api/auth/login/", {"username": "driver1", "password": "wrong"}, format="json"
        )
        self.assertEqual(response.status_code, 401)

    def test_vehicle_location_post_requires_auth(self):
        response = self.client.post(
            f"/api/vehicles/{self.vehicle.id}/location/",
            {"lat": -28.76, "lng": 32.046, "accuracy_m": 5},
            format="json",
        )
        self.assertEqual(response.status_code, 401)

    def test_vehicle_location_post_rejects_wrong_driver(self):
        self._auth(self.other_user)
        response = self.client.post(
            f"/api/vehicles/{self.vehicle.id}/location/",
            {"lat": -28.76, "lng": 32.046, "accuracy_m": 5},
            format="json",
        )
        self.assertEqual(response.status_code, 403)

    def test_vehicle_location_post_then_get_with_deviation_status(self):
        self._auth(self.driver_user)
        # On the route line itself -> on_route.
        post_response = self.client.post(
            f"/api/vehicles/{self.vehicle.id}/location/",
            {"lat": -28.762, "lng": 32.0465, "accuracy_m": 5},
            format="json",
        )
        self.assertEqual(post_response.status_code, 201)
        self.assertEqual(post_response.data["route_status"], "on_route")

        get_response = self.client.get(f"/api/vehicles/{self.vehicle.id}/location/")
        self.assertEqual(get_response.status_code, 200)
        self.assertAlmostEqual(get_response.data["lat"], -28.762)
        self.assertEqual(get_response.data["source"], "gps")

    def test_vehicle_location_post_far_from_route_is_off_route(self):
        self._auth(self.driver_user)
        response = self.client.post(
            f"/api/vehicles/{self.vehicle.id}/location/",
            {"lat": -29.0, "lng": 32.5, "accuracy_m": 5},
            format="json",
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.data["route_status"], "off_route")

    def test_vehicle_location_post_null_speed_is_accepted(self):
        self._auth(self.driver_user)
        response = self.client.post(
            f"/api/vehicles/{self.vehicle.id}/location/",
            {"lat": -28.762, "lng": 32.0465, "accuracy_m": 5, "speed_kmh": None},
            format="json",
        )
        self.assertEqual(response.status_code, 201)
        self.assertIsNone(response.data["speed_kmh"])

    def test_simulate_vehicle_movement_in_debug_mode(self):
        with override_settings(DEBUG=True):
            response = self.client.post(
                f"/api/vehicles/{self.vehicle.id}/simulate/", {"fraction": 0.5}, format="json"
            )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["fraction"], 0.5)
        self.assertEqual(response.data["location"]["source"], "simulated")

    def test_simulate_disabled_outside_debug(self):
        with override_settings(DEBUG=False):
            response = self.client.post(
                f"/api/vehicles/{self.vehicle.id}/simulate/", {"fraction": 0.5}, format="json"
            )
        self.assertEqual(response.status_code, 403)

    def test_vehicle_list_requires_operator_or_admin(self):
        with override_settings(DEBUG=True):
            self.client.post(
                f"/api/vehicles/{self.vehicle.id}/simulate/", {"fraction": 1.0}, format="json"
            )
        # No auth -> rejected.
        response = self.client.get("/api/vehicles/")
        self.assertEqual(response.status_code, 401)

        # Driver isn't allowed to see the whole fleet either.
        self._auth(self.driver_user)
        response = self.client.get("/api/vehicles/")
        self.assertEqual(response.status_code, 403)

        # Operator can.
        self._auth(self.operator_user)
        response = self.client.get("/api/vehicles/")
        self.assertEqual(response.status_code, 200)
        vehicle_data = response.data["results"][0]
        self.assertIsNotNone(vehicle_data["latest_location"])


class DeviationServiceTests(TestCase):
    def setUp(self):
        self.route = Route.objects.create(
            name="Straight Line Route",
            code="TH-LINE",
            origin_name="A",
            origin_lat=-28.7550,
            origin_lng=32.0450,
            destination_name="B",
            destination_lat=-28.7690,
            destination_lng=32.0480,
            geometry=[[-28.7550, 32.0450], [-28.7690, 32.0480]],
            distance_km=5.8,
            average_duration_min=25,
            average_speed_kmh=14,
            base_fare=1.00,
            fare_per_km=0.26,
        )

    def test_point_on_route_is_on_route(self):
        result = deviation.check_deviation(-28.762, 32.0465, self.route)
        self.assertEqual(result.status, "on_route")

    def test_point_far_from_route_is_off_route(self):
        result = deviation.check_deviation(-29.0, 32.5, self.route)
        self.assertEqual(result.status, "off_route")

    def test_route_specific_threshold_override(self):
        self.route.deviation_threshold_m = 100_000  # absurdly generous, everything counts as on-route
        self.route.save()
        result = deviation.check_deviation(-29.0, 32.5, self.route)
        self.assertEqual(result.status, "on_route")

    def test_no_route_gives_unknown_status(self):
        result = deviation.check_deviation(-28.76, 32.046, None)
        self.assertEqual(result.status, "unknown")
