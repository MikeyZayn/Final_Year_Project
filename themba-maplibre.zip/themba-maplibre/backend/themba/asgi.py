"""
ASGI config for themba project.

Serves plain HTTP through Django as usual, and WebSocket connections
(live vehicle tracking) through Django Channels.
"""

import os

import django
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.security.websocket import AllowedHostsOriginValidator
from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'themba.settings')
django.setup()

django_asgi_app = get_asgi_application()

# Imported after django.setup() so app models/consumers can load safely.
import core.routing  # noqa: E402

application = ProtocolTypeRouter(
    {
        'http': django_asgi_app,
        'websocket': AllowedHostsOriginValidator(
            URLRouter(core.routing.websocket_urlpatterns)
        ),
    }
)
