import { useEffect, useState } from 'react';
import MapView from './MapView';
import thembaApi from '../api/themba';

/**
 * "Pick a Route" screen: shows the predetermined taxi routes that serve the
 * chosen destination, each with fare/time (the fare popup from the mockup),
 * and draws the selected route's line on the map.
 */
function RouteSelectionScreen({ origin, destination, onBack, onConfirm, notify }) {
  const [routeOptions, setRouteOptions] = useState([]);
  const [selectedRouteId, setSelectedRouteId] = useState(null);
  const [geometry, setGeometry] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    thembaApi
      .searchRoutes({ origin, destination })
      .then((data) => {
        if (cancelled) return;
        setRouteOptions(data.route_options || []);
        if (data.route_options?.length) {
          setSelectedRouteId(data.route_options[0].route_id);
        }
        setLoadError('');
      })
      .catch((err) => setLoadError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [origin, destination]);

  useEffect(() => {
    if (!selectedRouteId) return;
    thembaApi
      .getRouteDirections(selectedRouteId)
      .then((data) => setGeometry(data.geometry || []))
      .catch(() => setGeometry([]));
  }, [selectedRouteId]);

  const selectedRoute = routeOptions.find((r) => r.route_id === selectedRouteId);

  return (
    <div className="route-selection-screen">
      <div className="route-selection-map">
        <MapView
          origin={origin ? { ...origin, label: 'Your location' } : null}
          destination={{ ...destination, label: destination.name || 'Destination' }}
          routeGeometry={geometry}
          height="260px"
        />
        <button className="back-pill" type="button" onClick={onBack}>
          ← Back
        </button>
      </div>

      <div className="route-points-card">
        <div className="route-points-header">
          <span>Route Points</span>
          <span className="badge">Transit</span>
        </div>
        <div className="route-points-row">
          <div className="route-point">
            <span className="dot dot-origin" />
            <strong>Your Location</strong>
          </div>
          <span className="route-points-divider" />
          <div className="route-point">
            <span className="dot dot-destination" />
            <strong>{destination.name || 'Destination'}</strong>
          </div>
        </div>
      </div>

      <div className="pick-route-header">
        <span>Pick a Route</span>
        <span className="muted small">{routeOptions.length} options</span>
      </div>

      {loading && <p className="muted small">Finding predetermined routes…</p>}
      {loadError && <p className="muted small">{loadError}</p>}
      {!loading && !loadError && routeOptions.length === 0 && (
        <p className="muted small">
          No predetermined THEMBA route currently serves this destination directly.
        </p>
      )}

      <div className="route-option-list">
        {routeOptions.map((option) => (
          <button
            key={option.route_id}
            type="button"
            className={
              option.route_id === selectedRouteId ? 'route-option selected' : 'route-option'
            }
            onClick={() => setSelectedRouteId(option.route_id)}
          >
            <span className="route-option-icon" aria-hidden>
              🚐
            </span>
            <span className="route-option-body">
              <strong>{option.route_name}</strong>
              <small>
                R{option.fare.toFixed(2)} · {Math.round(option.duration_min)} min
              </small>
            </span>
            {option.route_id === selectedRouteId ? (
              <span className="check-badge">✓</span>
            ) : (
              <span className="radio-dot" />
            )}
          </button>
        ))}
      </div>

      {selectedRoute && (
        <div className="selected-route-summary">
          <div>
            <span className="eyebrow">Selected route</span>
            <strong>{selectedRoute.route_name}</strong>
          </div>
          <span className="eta-chip large">{Math.round(selectedRoute.duration_min)} min</span>
        </div>
      )}

      {selectedRoute && (
        <div className="fare-popup">
          <div className="fare-popup-row">
            <span>Vehicle</span>
            <strong>{selectedRoute.vehicle_class}</strong>
          </div>
          <div className="fare-popup-row">
            <span>Distance</span>
            <strong>{selectedRoute.distance_km} km</strong>
          </div>
          <div className="fare-popup-row">
            <span>Average speed</span>
            <strong>{selectedRoute.average_speed_kmh} km/h</strong>
          </div>
          <div className="fare-popup-row fare-popup-total">
            <span>Estimated fare</span>
            <strong>R{selectedRoute.fare.toFixed(2)}</strong>
          </div>

          <button
            className="primary-button full"
            type="button"
            onClick={() => {
              notify?.(`${selectedRoute.route_name} confirmed - R${selectedRoute.fare.toFixed(2)}`);
              onConfirm?.({ route: selectedRoute, geometry });
            }}
          >
            Confirm route <span>→</span>
          </button>
        </div>
      )}
    </div>
  );
}

export default RouteSelectionScreen;
