import { useEffect, useRef, useState } from 'react';
import MapView from './MapView';
import thembaApi from '../api/themba';
import useGeolocation from '../hooks/useGeolocation';

const RECENT_PLACEHOLDERS = [
  { name: 'Harbor Science Museum', hint: 'Recently viewed · 18 Harbor Walk', minutesAway: 12 },
  { name: 'Juniper Market Hall', hint: "Saved place · 44 Juniper Street", minutesAway: 8 },
  { name: 'Riverside Reading Room', hint: 'Open until 9 PM · River Lane', minutesAway: 16 },
];

/**
 * "Where are you going?" screen - free-text destination search (geocoded
 * via the Django /api/geocode/ proxy, which in turn calls MapTiler), plus
 * a "Choose on map" fallback and automatic live-location start point.
 */
function RouteSearchScreen({ onDestinationChosen }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [pickOnMap, setPickOnMap] = useState(false);
  const [mapCenterHint, setMapCenterHint] = useState(null);
  const debounceRef = useRef(null);

  const { position, error, loading, requestOnce } = useGeolocation();

  useEffect(() => {
    requestOnce();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (query.trim().length < 3) {
      setResults([]);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const data = await thembaApi.geocode(query, position);
        setResults(data.results || []);
      } catch (err) {
        setResults([]);
      } finally {
        setSearching(false);
      }
    }, 400);
    return () => clearTimeout(debounceRef.current);
  }, [query, position]);

  function chooseDestination(destination) {
    onDestinationChosen({ origin: position, destination });
  }

  return (
    <div className="route-search-screen">
      <div className="route-search-map">
        <MapView
          origin={position ? { ...position, label: 'Your location' } : null}
          destination={mapCenterHint}
          onMapClick={pickOnMap ? (point) => setMapCenterHint(point) : undefined}
          height="260px"
        />
        {pickOnMap && (
          <div className="map-pick-banner">
            <span>Tap the map to drop a pin at your destination</span>
            <button
              type="button"
              className="primary-button"
              disabled={!mapCenterHint}
              onClick={() =>
                chooseDestination({ ...mapCenterHint, name: 'Chosen location' })
              }
            >
              Use this location
            </button>
          </div>
        )}
      </div>

      <div className="search-panel">
        <label className="search-box">
          <span aria-hidden>🧭</span>
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Where are you going?"
          />
          <span aria-hidden>🎙️</span>
        </label>

        {loading && <p className="muted small">Finding your location…</p>}
        {error && <p className="muted small">{error} You can still search or choose on the map.</p>}

        <div className="pick-destination-header">
          <span>Pick a destination</span>
          <button className="text-button" type="button" onClick={() => setPickOnMap((v) => !v)}>
            {pickOnMap ? 'Cancel' : 'Choose on map'}
          </button>
        </div>

        <div className="destination-list">
          {searching && <p className="muted small">Searching…</p>}

          {!searching && query.trim().length >= 3 && results.length === 0 && (
            <p className="muted small">No matches yet. Try a different search term.</p>
          )}

          {!searching &&
            results.map((result) => (
              <button
                key={`${result.lat}-${result.lng}`}
                className="destination-row"
                type="button"
                onClick={() => chooseDestination({ ...result })}
              >
                <span aria-hidden>📍</span>
                <span>
                  <strong>{result.name}</strong>
                </span>
              </button>
            ))}

          {query.trim().length < 3 &&
            RECENT_PLACEHOLDERS.map((place) => (
              <button
                key={place.name}
                className="destination-row"
                type="button"
                onClick={() =>
                  chooseDestination({
                    name: place.name,
                    lat: position ? position.lat + (Math.random() - 0.5) * 0.01 : -28.77,
                    lng: position ? position.lng + (Math.random() - 0.5) * 0.01 : 32.048,
                  })
                }
              >
                <span aria-hidden>🕐</span>
                <span>
                  <strong>{place.name}</strong>
                  <small>{place.hint}</small>
                </span>
                <b className="eta-chip">{place.minutesAway} min</b>
              </button>
            ))}
        </div>
      </div>
    </div>
  );
}

export default RouteSearchScreen;
