import { useState } from 'react';
import RouteSearchScreen from './RouteSearchScreen';
import RouteSelectionScreen from './RouteSelectionScreen';
import DevRoutingTester from './DevRoutingTester';
import MapView from './MapView';

/**
 * Passenger-facing routing flow:
 *   1. search  - "Where are you going?" (RouteSearchScreen)
 *   2. select  - "Pick a Route" with fare popup (RouteSelectionScreen)
 *   3. confirmed - booked-route summary with live-updating vehicle position
 */
function RoutingFlow({ notify, onClose }) {
  const [step, setStep] = useState('search');
  const [origin, setOrigin] = useState(null);
  const [destination, setDestination] = useState(null);
  const [confirmed, setConfirmed] = useState(null);
  const [showDevTools, setShowDevTools] = useState(false);

  return (
    <div className="routing-flow">
      <div className="routing-flow-header">
        <strong>Find your taxi route</strong>
        <div className="routing-flow-header-actions">
          <button className="text-button" type="button" onClick={() => setShowDevTools((v) => !v)}>
            {showDevTools ? 'Hide dev tools' : 'Dev test tools'}
          </button>
          <button className="text-button" type="button" onClick={onClose}>
            Close
          </button>
        </div>
      </div>

      {showDevTools && <DevRoutingTester notify={notify} />}

      {step === 'search' && (
        <RouteSearchScreen
          onDestinationChosen={({ origin: chosenOrigin, destination: chosenDestination }) => {
            setOrigin(chosenOrigin);
            setDestination(chosenDestination);
            setStep('select');
          }}
        />
      )}

      {step === 'select' && destination && (
        <RouteSelectionScreen
          origin={origin}
          destination={destination}
          notify={notify}
          onBack={() => setStep('search')}
          onConfirm={(payload) => {
            setConfirmed(payload);
            setStep('confirmed');
          }}
        />
      )}

      {step === 'confirmed' && confirmed && (
        <div className="route-confirmed-screen">
          <MapView
            origin={origin ? { ...origin, label: 'Your location' } : null}
            destination={{ ...destination, label: destination.name }}
            routeGeometry={confirmed.geometry}
            height="260px"
          />
          <div className="confirmed-card">
            <span className="eyebrow">Trip booked</span>
            <h3>{confirmed.route.route_name}</h3>
            <p className="muted">
              {confirmed.route.from_stop} → {confirmed.route.to_stop}
            </p>
            <div className="confirmed-stats">
              <div>
                <span className="route-label">Fare</span>
                <strong>R{confirmed.route.fare.toFixed(2)}</strong>
              </div>
              <div>
                <span className="route-label">ETA</span>
                <strong>{Math.round(confirmed.route.duration_min)} min</strong>
              </div>
              <div>
                <span className="route-label">Speed</span>
                <strong>{confirmed.route.average_speed_kmh} km/h</strong>
              </div>
              <div>
                <span className="route-label">Distance</span>
                <strong>{confirmed.route.distance_km} km</strong>
              </div>
            </div>
            <button className="secondary-button full" type="button" onClick={() => setStep('search')}>
              Search another route
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default RoutingFlow;
