import { useState } from 'react';

/**
 * Inline login form. Shown wherever a backend-gated action needs a real
 * THEMBA account (fleet tracking for operators/admins, GPS submission for
 * drivers) - distinct from the existing role-switcher demo login.
 */
function LoginGate({ title, hint, onLogin, loading, error }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  function handleSubmit(event) {
    event.preventDefault();
    onLogin(username, password);
  }

  return (
    <form className="login-gate" onSubmit={handleSubmit}>
      <strong>{title}</strong>
      {hint && <p className="muted small">{hint}</p>}
      <label>
        Username
        <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" />
      </label>
      <label>
        Password
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="current-password"
        />
      </label>
      {error && <p className="muted small login-gate-error">{error}</p>}
      <button className="primary-button full" type="submit" disabled={loading}>
        {loading ? 'Signing in…' : 'Sign in'}
      </button>
    </form>
  );
}

export default LoginGate;
