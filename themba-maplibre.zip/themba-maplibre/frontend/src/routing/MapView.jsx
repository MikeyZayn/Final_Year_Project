import { useEffect, useRef } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';

const MAPTILER_KEY = import.meta.env.VITE_MAPTILER_KEY || '';
const MAP_STYLE = MAPTILER_KEY
  ? `https://api.maptiler.com/maps/streets-v2/style.json?key=${MAPTILER_KEY}`
  : // Free, no-key fallback style so the map still renders during setup.
    'https://demotiles.maplibre.org/style.json';

const ROUTE_SOURCE_ID = 'themba-route-line';
const ROUTE_LAYER_ID = 'themba-route-line-layer';

/**
 * MapLibre GL JS map, styled with MapTiler vector tiles.
 *
 * Props:
 *  - origin / destination: { lat, lng, label? } -> pin markers
 *  - routeGeometry: [[lat, lng], ...] -> drawn as the routing line
 *  - vehicles: [{ id, lat, lng, heading, label, color }] -> live tracking dots
 *  - onMapClick({ lat, lng }) -> used by "Choose on map"
 *  - height (css value)
 */
function MapView({
  origin,
  destination,
  routeGeometry,
  vehicles = [],
  onMapClick,
  height = '320px',
  initialCenter = [31.8925, -28.7808], // [lng, lat] - Empangeni, KZN
  initialZoom = 12,
}) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const originMarkerRef = useRef(null);
  const destinationMarkerRef = useRef(null);
  const vehicleMarkersRef = useRef({});

  // Initialise the map once.
  useEffect(() => {
    if (mapRef.current || !containerRef.current) return;

    const map = new maplibregl.Map({
      container: containerRef.current,
      style: MAP_STYLE,
      center: initialCenter,
      zoom: initialZoom,
      attributionControl: true,
    });

    map.addControl(new maplibregl.NavigationControl(), 'top-right');
    map.addControl(new maplibregl.GeolocateControl({ trackUserLocation: true }), 'top-right');

    map.on('load', () => {
      map.addSource(ROUTE_SOURCE_ID, {
        type: 'geojson',
        data: { type: 'Feature', geometry: { type: 'LineString', coordinates: [] } },
      });
      map.addLayer({
        id: ROUTE_LAYER_ID,
        type: 'line',
        source: ROUTE_SOURCE_ID,
        layout: { 'line-join': 'round', 'line-cap': 'round' },
        paint: { 'line-color': '#3169e6', 'line-width': 5, 'line-opacity': 0.9 },
      });
    });

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Click-to-choose-destination support.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !onMapClick) return;

    const handleClick = (event) => {
      onMapClick({ lat: event.lngLat.lat, lng: event.lngLat.lng });
    };
    map.on('click', handleClick);
    return () => map.off('click', handleClick);
  }, [onMapClick]);

  // Origin marker.
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (originMarkerRef.current) {
      originMarkerRef.current.remove();
      originMarkerRef.current = null;
    }
    if (origin) {
      const el = document.createElement('div');
      el.className = 'themba-marker themba-marker-origin';
      originMarkerRef.current = new maplibregl.Marker({ element: el })
        .setLngLat([origin.lng, origin.lat])
        .setPopup(new maplibregl.Popup({ offset: 14 }).setText(origin.label || 'Your location'))
        .addTo(map);
    }
  }, [origin]);

  // Destination marker.
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (destinationMarkerRef.current) {
      destinationMarkerRef.current.remove();
      destinationMarkerRef.current = null;
    }
    if (destination) {
      const el = document.createElement('div');
      el.className = 'themba-marker themba-marker-destination';
      destinationMarkerRef.current = new maplibregl.Marker({ element: el })
        .setLngLat([destination.lng, destination.lat])
        .setPopup(new maplibregl.Popup({ offset: 14 }).setText(destination.label || 'Destination'))
        .addTo(map);
    }
  }, [destination]);

  // Route line + fit bounds.
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const applyRoute = () => {
      const source = map.getSource(ROUTE_SOURCE_ID);
      if (!source) return;

      const coordinates = (routeGeometry || []).map(([lat, lng]) => [lng, lat]);
      source.setData({
        type: 'Feature',
        geometry: { type: 'LineString', coordinates },
      });

      const points = [
        ...coordinates,
        origin ? [origin.lng, origin.lat] : null,
        destination ? [destination.lng, destination.lat] : null,
      ].filter(Boolean);

      if (points.length > 1) {
        const bounds = points.reduce(
          (acc, point) => acc.extend(point),
          new maplibregl.LngLatBounds(points[0], points[0])
        );
        map.fitBounds(bounds, { padding: 60, maxZoom: 15, duration: 600 });
      } else if (points.length === 1) {
        map.flyTo({ center: points[0], zoom: 14 });
      }
    };

    if (map.isStyleLoaded()) applyRoute();
    else map.once('load', applyRoute);
  }, [routeGeometry, origin, destination]);

  // Live vehicle markers (taxi dots).
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    const seenIds = new Set();

    vehicles.forEach((vehicle) => {
      seenIds.add(vehicle.id);
      const lngLat = [vehicle.lng, vehicle.lat];

      if (vehicleMarkersRef.current[vehicle.id]) {
        vehicleMarkersRef.current[vehicle.id].setLngLat(lngLat);
        const el = vehicleMarkersRef.current[vehicle.id].getElement();
        el.style.transform = `${el.style.transform.split(' rotate')[0]} rotate(${vehicle.heading || 0}deg)`;
      } else {
        const el = document.createElement('div');
        el.className = 'themba-marker themba-marker-vehicle';
        el.style.setProperty('--vehicle-color', vehicle.color || '#e6a841');
        el.title = vehicle.label || 'Taxi';

        const marker = new maplibregl.Marker({ element: el, rotationAlignment: 'map' })
          .setLngLat(lngLat)
          .setPopup(new maplibregl.Popup({ offset: 14 }).setText(vehicle.label || 'Taxi'))
          .addTo(map);
        vehicleMarkersRef.current[vehicle.id] = marker;
      }
    });

    Object.keys(vehicleMarkersRef.current).forEach((id) => {
      if (!seenIds.has(Number(id)) && !seenIds.has(id)) {
        vehicleMarkersRef.current[id].remove();
        delete vehicleMarkersRef.current[id];
      }
    });
  }, [vehicles]);

  return <div ref={containerRef} className="themba-map" style={{ height }} />;
}

export default MapView;
