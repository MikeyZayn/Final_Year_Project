// Thin fetch wrapper around the THEMBA Django REST API.
// Base URL comes from VITE_API_BASE_URL (see .env.example); defaults to the
// local dev server started by `python manage.py runserver`.

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000/api';

// --- Auth token storage -------------------------------------------------
// The token is issued by POST /api/auth/login/ and must be attached to
// protected calls (fleet tracking, driver GPS pings).
const TOKEN_KEY = 'themba_auth';

export function getAuth() {
  try {
    const raw = sessionStorage.getItem(TOKEN_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setAuth(auth) {
  if (auth) sessionStorage.setItem(TOKEN_KEY, JSON.stringify(auth));
  else sessionStorage.removeItem(TOKEN_KEY);
}

export function clearAuth() {
  setAuth(null);
}

// Aliases used by src/hooks/useAuth.js.
export const getStoredAuth = getAuth;
export const setStoredAuth = setAuth;

async function request(path, { method = 'GET', params, body, auth = false } = {}) {
  let url = `${API_BASE_URL}${path}`;

  if (params) {
    const query = new URLSearchParams(
      Object.entries(params).filter(([, value]) => value !== undefined && value !== null)
    ).toString();
    if (query) url += `?${query}`;
  }

  const headers = {};
  if (body) headers['Content-Type'] = 'application/json';
  if (auth) {
    const stored = getAuth();
    if (stored?.token) headers.Authorization = `Token ${stored.token}`;
  }

  let response;
  try {
    response = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    // Network-level failure: backend not running, DNS, CORS preflight, etc.
    throw new Error(
      'Cannot reach the THEMBA backend. Check that Django is running and VITE_API_BASE_URL is correct.'
    );
  }

  const isJson = response.headers.get('content-type')?.includes('application/json');
  const data = isJson ? await response.json() : null;

  if (!response.ok) {
    if (response.status === 401) throw new Error('Your session has expired. Please sign in again.');
    if (response.status === 403) throw new Error((data && data.error) || 'You are not authorised to do that.');
    const message = (data && (data.error || data.detail)) || `Request failed (${response.status})`;
    throw new Error(message);
  }

  return data;
}

export const thembaApi = {
  // --- Auth -----------------------------------------------------------
  login: async (username, password) => {
    const data = await request('/auth/login/', { method: 'POST', body: { username, password } });
    setAuth(data);
    return data;
  },
  logout: () => clearAuth(),

  // --- Routing --------------------------------------------------------
  searchRoutes: ({ origin, destination, maxDistanceKm }) =>
    request('/routes/search/', {
      params: {
        origin_lat: origin?.lat,
        origin_lng: origin?.lng,
        destination_lat: destination.lat,
        destination_lng: destination.lng,
        max_distance_km: maxDistanceKm,
      },
    }),

  getRouteEstimate: (routeId, { origin, destination } = {}) =>
    request(`/routes/${routeId}/estimate/`, {
      params: {
        origin_lat: origin?.lat,
        origin_lng: origin?.lng,
        destination_lat: destination?.lat,
        destination_lng: destination?.lng,
      },
    }),

  getRouteDirections: (routeId) => request(`/routes/${routeId}/directions/`),

  listRoutes: () => request('/routes/'),

  geocode: (query, proximity) =>
    request('/geocode/', {
      params: {
        query,
        proximity_lat: proximity?.lat,
        proximity_lng: proximity?.lng,
      },
    }),

  // --- Vehicles / live tracking (operator + administrator only) --------
  listVehicles: ({ routeId, status } = {}) =>
    request('/vehicles/', { params: { route: routeId, status }, auth: true }),

  getVehicleLocation: (vehicleId) => request(`/vehicles/${vehicleId}/location/`),

  // Driver device pushes its own GPS. speedKmh may be null when the browser
  // reports no speed - the backend stores null rather than a fabricated 0.
  pushVehicleLocation: (vehicleId, location) =>
    request(`/vehicles/${vehicleId}/location/`, { method: 'POST', body: location, auth: true }),

  // TEST DATA ONLY - backend rejects this outside DEBUG mode.
  simulateVehicleMovement: (vehicleId, fraction) =>
    request(`/vehicles/${vehicleId}/simulate/`, { method: 'POST', body: { fraction } }),

  // --- Trips / boarding -------------------------------------------------
  listTrips: () => request('/trips/'),
  createTrip: (trip) => request('/trips/', { method: 'POST', body: trip }),
  createBoarding: (boarding) => request('/boardings/', { method: 'POST', body: boarding }),
};

// --- WebSocket live tracking ---------------------------------------------
// Derives the ws:// URL from the REST base URL so one env var configures both.
export function trackingSocketUrl(path) {
  const base = API_BASE_URL.replace(/\/api\/?$/, '');
  const wsBase = base.replace(/^http/, 'ws');
  return `${wsBase}${path}`;
}

export default thembaApi;
