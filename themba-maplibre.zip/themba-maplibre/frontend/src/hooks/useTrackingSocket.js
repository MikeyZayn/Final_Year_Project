import { useEffect, useRef, useState } from 'react';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000/api';
const WS_BASE_URL =
  import.meta.env.VITE_WS_BASE_URL || API_BASE_URL.replace(/^http/, 'ws').replace(/\/api\/?$/, '');

/**
 * ws/tracking/ - the fleet feed (operator/administrator). Requires a token
 * belonging to an operator/administrator account; connects only once one is
 * supplied. Falls back to `onFallback()` (REST polling) if the socket
 * cannot be opened at all, e.g. the backend isn't running Channels.
 */
export function useFleetSocket(token, { onMessage, onFallback } = {}) {
  const [connected, setConnected] = useState(false);
  const socketRef = useRef(null);

  useEffect(() => {
    if (!token) return undefined;

    const socket = new WebSocket(`${WS_BASE_URL}/ws/tracking/?token=${encodeURIComponent(token)}`);
    socketRef.current = socket;

    socket.onopen = () => setConnected(true);
    socket.onclose = () => {
      setConnected(false);
      if (socketRef.current === socket) onFallback?.();
    };
    socket.onerror = () => onFallback?.();
    socket.onmessage = (event) => {
      try {
        onMessage?.(JSON.parse(event.data));
      } catch {
        // ignore malformed frames
      }
    };

    return () => {
      socketRef.current = null;
      socket.close();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  return { connected };
}

/** ws/tracking/vehicle/<id>/ - a single vehicle's feed, open access. */
export function useVehicleSocket(vehicleId, { onMessage, onFallback } = {}) {
  const [connected, setConnected] = useState(false);
  const socketRef = useRef(null);

  useEffect(() => {
    if (!vehicleId) return undefined;

    const socket = new WebSocket(`${WS_BASE_URL}/ws/tracking/vehicle/${vehicleId}/`);
    socketRef.current = socket;

    socket.onopen = () => setConnected(true);
    socket.onclose = () => {
      setConnected(false);
      if (socketRef.current === socket) onFallback?.();
    };
    socket.onerror = () => onFallback?.();
    socket.onmessage = (event) => {
      try {
        onMessage?.(JSON.parse(event.data));
      } catch {
        // ignore malformed frames
      }
    };

    return () => {
      socketRef.current = null;
      socket.close();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [vehicleId]);

  return { connected };
}
