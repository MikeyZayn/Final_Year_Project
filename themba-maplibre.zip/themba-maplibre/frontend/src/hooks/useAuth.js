import { useCallback, useState } from 'react';
import thembaApi, { getStoredAuth, setStoredAuth } from '../api/themba';

/**
 * Backend authentication (separate from the existing role-switcher demo
 * login). Used specifically for the two backend-gated actions: operators/
 * administrators viewing the full fleet, and drivers submitting GPS pings -
 * both require a real token per THEMBA_SPEC §20/§29.
 */
export function useAuth() {
  const [auth, setAuth] = useState(() => getStoredAuth());
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const login = useCallback(async (username, password) => {
    setLoading(true);
    setError('');
    try {
      const data = await thembaApi.login(username, password);
      const nextAuth = { token: data.token, username: data.username, role: data.role };
      setStoredAuth(nextAuth);
      setAuth(nextAuth);
      return nextAuth;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(() => {
    setStoredAuth(null);
    setAuth(null);
  }, []);

  return { auth, login, logout, error, loading };
}

export default useAuth;
