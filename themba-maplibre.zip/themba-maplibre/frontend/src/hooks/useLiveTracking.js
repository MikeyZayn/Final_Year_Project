import { useEffect, useRef, useState } from 'react';
import thembaApi, { getAuth, trackingSocketUrl } from '../api/themba';

/**
 * Subscribes to live vehicle positions.
 *
 * Prefers the Django Channels WebSocket feed so the map updates the instant a
 * driver's GPS ping arrives. If the socket can't connect (Channels not
 * running, proxy in the way, network blip) it transparently falls back to
 * REST polling so tracking still works.
 *
 * scope:
 *   'fleet'            -> every vehicle (operator/administrator; needs a token)
 *   { vehicleId: N }   -> one vehicle's feed
 *
 * Returns { vehicles, connection, error } where `vehicles` is a map of
 * vehicleId -> latest position payload, and `connection` is
 * 'websocket' | 'polling' | 'connecting'.
 */
export function useLiveTracking(scope = 'fleet', { enabled = true, pollMs = 5000 } = {}) {
  const [vehicles, setVehicles] = useState({});
  const [connection, setConnection] = useState('connecting');
  const [error, setError] = useState('');
  const socketRef = useRef(null);
  const pollRef = useRef(null);

  useEffect(() => {
    if (!enabled) return undefined;

    let cancelled = false;

    function applyUpdate(payload) {
      if (!payload?.vehicle_id) return;
      setVehicles((current) => ({ ...current, [payload.vehicle_id]: payload }));
    }

    function startPolling() {
      if (pollRef.current) return;
      setConnection('polling');

      const tick = async () => {
        try {
          if (scope === 'fleet') {
            const data = await thembaApi.listVehicles();
            if (cancelled) return;
            const next = {};
            (data.results || data || []).forEach((vehicle) => {
              if (vehicle.latest_location) {
                next[vehicle.id] = {
                  vehicle_id: vehicle.id,
                  registration: vehicle.registration,
                  route_id: vehicle.route?.id,
                  ...vehicle.latest_location,
                };
              }
            });
            setVehicles(next);
          } else if (scope?.vehicleId) {
            const location = await thembaApi.getVehicleLocation(scope.vehicleId);
            if (cancelled) return;
            applyUpdate({ vehicle_id: scope.vehicleId, ...location });
          }
          setError('');
        } catch (err) {
          if (!cancelled) setError(err.message);
        }
      };

      tick();
      pollRef.current = setInterval(tick, pollMs);
    }

    // --- Try the WebSocket first ---------------------------------------
    let url;
    if (scope === 'fleet') {
      const auth = getAuth();
      if (!auth?.token) {
        setError('Sign in as an operator or administrator to view live tracking.');
        setConnection('polling');
        return () => {};
      }
      url = trackingSocketUrl(`/ws/tracking/?token=${encodeURIComponent(auth.token)}`);
    } else if (scope?.vehicleId) {
      url = trackingSocketUrl(`/ws/tracking/vehicle/${scope.vehicleId}/`);
    } else {
      return () => {};
    }

    let socket;
    try {
      socket = new WebSocket(url);
      socketRef.current = socket;

      socket.onopen = () => {
        if (cancelled) return;
        setConnection('websocket');
        setError('');
        // Bootstrap with current positions; the socket only sends changes.
        if (scope === 'fleet') {
          thembaApi
            .listVehicles()
            .then((data) => {
              if (cancelled) return;
              (data.results || data || []).forEach((vehicle) => {
                if (vehicle.latest_location) {
                  applyUpdate({
                    vehicle_id: vehicle.id,
                    registration: vehicle.registration,
                    route_id: vehicle.route?.id,
                    ...vehicle.latest_location,
                  });
                }
              });
            })
            .catch(() => {});
        }
      };

      socket.onmessage = (event) => {
        if (cancelled) return;
        try {
          applyUpdate(JSON.parse(event.data));
        } catch {
          /* ignore malformed frames */
        }
      };

      socket.onerror = () => {
        if (!cancelled) startPolling();
      };

      socket.onclose = (event) => {
        if (cancelled) return;
        if (event.code === 4401) {
          setError('You are not authorised to view live vehicle tracking.');
          setConnection('polling');
          return;
        }
        startPolling();
      };
    } catch {
      startPolling();
    }

    return () => {
      cancelled = true;
      if (socket) {
        socket.onclose = null;
        socket.close();
      }
      socketRef.current = null;
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, [enabled, pollMs, scope === 'fleet' ? 'fleet' : scope?.vehicleId]);

  return { vehicles, connection, error };
}

export default useLiveTracking;
