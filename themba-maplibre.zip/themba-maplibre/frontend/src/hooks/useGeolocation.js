import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * Wraps navigator.geolocation.
 *
 * Reports real values only. When the browser gives no speed reading (very
 * common on desktops and stationary devices), `speedKmh` is null rather than
 * 0, so the UI can honestly show "Speed unavailable" instead of inventing a
 * number.
 *
 * Returns:
 *   position  - { lat, lng, accuracyM, speedKmh, headingDeg, timestamp } | null
 *   error     - human-readable message, '' when fine
 *   status    - 'idle' | 'locating' | 'watching' | 'error' | 'unsupported'
 */
export function useGeolocation({ watch = false } = {}) {
  const [position, setPosition] = useState(null);
  const [error, setError] = useState('');
  const [status, setStatus] = useState('idle');
  const watchIdRef = useRef(null);

  const handleSuccess = useCallback((result) => {
    const { latitude, longitude, accuracy, speed, heading } = result.coords;
    setPosition({
      lat: latitude,
      lng: longitude,
      accuracyM: accuracy ?? null,
      // navigator gives speed in m/s, or null when unavailable.
      speedKmh: speed === null || speed === undefined || Number.isNaN(speed)
        ? null
        : speed * 3.6,
      headingDeg: heading ?? null,
      timestamp: result.timestamp,
    });
    setError('');
  }, []);

  const handleError = useCallback((geoError) => {
    const messages = {
      1: 'Location permission denied. Enable location access, or enter start coordinates manually.',
      2: 'Your location is currently unavailable. Check that location services are switched on.',
      3: 'Timed out while finding your location. Try again, or enter coordinates manually.',
    };
    setError(messages[geoError.code] || 'Unable to determine your location.');
    setStatus('error');
  }, []);

  const requestOnce = useCallback(() => {
    if (!('geolocation' in navigator)) {
      setError('This browser does not support location services.');
      setStatus('unsupported');
      return;
    }
    setStatus('locating');
    navigator.geolocation.getCurrentPosition(
      (result) => {
        handleSuccess(result);
        setStatus('idle');
      },
      handleError,
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 5000 }
    );
  }, [handleSuccess, handleError]);

  const startWatching = useCallback(() => {
    if (!('geolocation' in navigator)) {
      setError('This browser does not support location services.');
      setStatus('unsupported');
      return;
    }
    if (watchIdRef.current !== null) return;
    setStatus('watching');
    watchIdRef.current = navigator.geolocation.watchPosition(handleSuccess, handleError, {
      enableHighAccuracy: true,
      maximumAge: 2000,
      timeout: 15000,
    });
  }, [handleSuccess, handleError]);

  const stopWatching = useCallback(() => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
      setStatus('idle');
    }
  }, []);

  useEffect(() => {
    if (watch) startWatching();
    return () => stopWatching();
  }, [watch, startWatching, stopWatching]);

  return { position, error, status, requestOnce, startWatching, stopWatching };
}

export default useGeolocation;
