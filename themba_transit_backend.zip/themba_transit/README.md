# THEMBA Transit — Registration & Auth Backend (Django)

Backend for the registration and login screens: passenger, driver, operator,
and administrator sign-up, plus the role-picker login screen.

Accounts are active immediately after registration.

Two ways to use it:
- **`/api/...`** — JSON REST endpoints for a separate frontend.
- **Plain pages** — server-rendered HTML forms at `/`, `/register/...`,
  `/login/`, and `/dashboard/<role>/`. Open `http://127.0.0.1:8000/` in a
  browser — no separate frontend build step needed.

## Setup

```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt

python3 manage.py migrate
python3 manage.py seed_reference_data   # sample rank / licence / operator / admin codes
python3 manage.py createsuperuser       # optional, for /admin/
python3 manage.py runserver
```

Django admin (`/admin/`) is where staff load real `RankCode`, `LicenceRecord`,
`OperatorCode` and `ManagerCode` rows before drivers/operators/admins can register.

## Data model

| Table | Purpose |
|---|---|
| `User` | Shared account table for all four roles (`passenger`, `driver`, `operator`, `admin`). `email_or_phone` is the login identifier. |
| `EmergencyContact` | One row per passenger, created only if the "Show optional fields" panel was filled in. |
| `RankCode` | Unique 5-digit code per rank/station. **No personal data**. |
| `LicenceRecord` | Pre-loaded driver records: 7-digit licence number → name, national ID. |
| `OperatorCode` | Pre-loaded operator records: 7-digit operator code → name, national ID. |
| `ManagerCode` | Pre-loaded administrator records: 7-digit code → name, national ID. |

## Password policy

- 8+ characters
- 1+ uppercase letter
- 1+ lowercase letter
- 1+ digit

## Registration checks

| Field | Format | Checked against |
|---|---|---|
| Rank code | exactly 5 digits | `RankCode` (active, exists) |
| Licence number (driver) | exactly 7 digits | `LicenceRecord` (active, exists, not already linked) |
| Operator code (operator) | exactly 7 digits | `OperatorCode` (active, exists, not already linked) |
| Administrator code (admin) | exactly 7 digits | `ManagerCode` (active, exists, not already linked) |

Sample seeded values: rank `10234`, licence `8830112`, operator `5510234`,
administrator `1290045`.

## HTML pages

| Page | URL |
|---|---|
| Landing / choose role | `/` |
| Passenger sign-up | `/register/passenger/` |
| Driver sign-up | `/register/driver/` |
| Operator sign-up | `/register/operator/` |
| Admin sign-up | `/register/admin/` |
| Login (role tiles) | `/login/` |
| Dashboards | `/dashboard/passenger/`, `/dashboard/driver/`, `/dashboard/operator/`, `/dashboard/admin/` |

Successful registration **and** login both route straight to the matching dashboard.

## API endpoints

All under `/api/`.

### Registration

`POST /register/passenger/`, `/register/driver/`, `/register/operator/`, `/register/admin/`

On success (HTTP 201):
```json
{
  "detail": "Account created.",
  "token": "...",
  "role": "operator",
  "dashboard_route": "/dashboard/operator"
}
```

### Login

`POST /login/`
```json
{ "role": "operator", "email_or_phone": "ops@agency.gov", "password": "Operat0r1" }
```
Returns the same `{ token, role, dashboard_route }` shape.

## Performance notes

- Unique + `db_index` on login identifier and all code fields for fast lookups.
- Registration uses targeted `get()` / `filter().exists()`.
- `update_fields` used on every single-field save.
