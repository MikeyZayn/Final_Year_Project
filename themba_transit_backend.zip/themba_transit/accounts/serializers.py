import re

from django.contrib.auth import authenticate
from rest_framework import serializers

from .models import (
    EmergencyContact,
    LicenceRecord,
    ManagerCode,
    OperatorCode,
    RankCode,
    Role,
    User,
)
from .validators import validate_password_complexity

RANK_CODE_RE = re.compile(r"^\d{5}$")
LICENCE_NUMBER_RE = re.compile(r"^\d{7}$")
OPERATOR_CODE_RE = re.compile(r"^\d{7}$")
MANAGER_CODE_RE = re.compile(r"^\d{7}$")


# ---------------------------------------------------------------------------
# Shared building blocks
# ---------------------------------------------------------------------------

class EmergencyContactSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=150)
    phone_number = serializers.CharField(max_length=30, required=False, allow_blank=True)
    relationship = serializers.CharField(max_length=50, required=False, allow_blank=True)


class BaseRegistrationSerializer(serializers.Serializer):
    """Fields common to every 'Create Account' screen."""

    email_or_phone = serializers.CharField(max_length=150)
    password = serializers.CharField(write_only=True)
    confirm_password = serializers.CharField(write_only=True)

    def validate_email_or_phone(self, value):
        if User.objects.filter(email_or_phone=value).exists():
            raise serializers.ValidationError("An account with this email or number already exists.")
        return value

    def validate(self, attrs):
        password = attrs.get("password")
        confirm_password = attrs.get("confirm_password")

        errors = {}
        rule_errors = validate_password_complexity(password)
        if rule_errors:
            errors["password"] = rule_errors
        if password != confirm_password:
            errors["confirm_password"] = ["Passwords do not match."]
        if errors:
            raise serializers.ValidationError(errors)
        return attrs


# ---------------------------------------------------------------------------
# Passenger
# ---------------------------------------------------------------------------

class PassengerRegistrationSerializer(BaseRegistrationSerializer):
    emergency_contact = EmergencyContactSerializer(required=False, allow_null=True)

    def create(self, validated_data):
        emergency_contact_data = validated_data.pop("emergency_contact", None)
        validated_data.pop("confirm_password")

        user = User.objects.create_user(
            email_or_phone=validated_data["email_or_phone"],
            password=validated_data["password"],
            role=Role.PASSENGER,
        )

        if emergency_contact_data:
            EmergencyContact.objects.create(user=user, **emergency_contact_data)

        return user


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------

class DriverRegistrationSerializer(BaseRegistrationSerializer):
    rank_code = serializers.CharField(max_length=5)
    licence_number = serializers.CharField(max_length=7)

    def validate_rank_code(self, value):
        if not RANK_CODE_RE.match(value):
            raise serializers.ValidationError("Rank code must be exactly 5 digits.")
        if not RankCode.objects.filter(code=value, is_active=True).exists():
            raise serializers.ValidationError("Rank code not recognised. Contact your station manager.")
        return value

    def validate_licence_number(self, value):
        if not LICENCE_NUMBER_RE.match(value):
            raise serializers.ValidationError("Licence number must be exactly 7 digits.")
        try:
            record = LicenceRecord.objects.get(licence_number=value, is_active=True)
        except LicenceRecord.DoesNotExist:
            raise serializers.ValidationError("Licence number not found in the driver registry.")
        if record.linked_user_id is not None:
            raise serializers.ValidationError("This licence number is already linked to an account.")
        return value

    def validate(self, attrs):
        attrs = super().validate(attrs)
        attrs["_licence_record"] = LicenceRecord.objects.get(licence_number=attrs["licence_number"])
        return attrs

    def create(self, validated_data):
        validated_data.pop("confirm_password")
        licence: LicenceRecord = validated_data.pop("_licence_record")
        validated_data.pop("rank_code")

        user = User.objects.create_user(
            email_or_phone=validated_data["email_or_phone"],
            password=validated_data["password"],
            role=Role.DRIVER,
        )

        licence.linked_user = user
        licence.save(update_fields=["linked_user"])

        return user


# ---------------------------------------------------------------------------
# Operator
# ---------------------------------------------------------------------------

class OperatorRegistrationSerializer(BaseRegistrationSerializer):
    rank_code = serializers.CharField(max_length=5)
    operator_code = serializers.CharField(max_length=7)

    def validate_rank_code(self, value):
        if not RANK_CODE_RE.match(value):
            raise serializers.ValidationError("Rank code must be exactly 5 digits.")
        if not RankCode.objects.filter(code=value, is_active=True).exists():
            raise serializers.ValidationError("Rank code not recognised. Contact your station manager.")
        return value

    def validate_operator_code(self, value):
        if not OPERATOR_CODE_RE.match(value):
            raise serializers.ValidationError("Operator code must be exactly 7 digits.")
        try:
            record = OperatorCode.objects.get(code=value, is_active=True)
        except OperatorCode.DoesNotExist:
            raise serializers.ValidationError("Operator code not found in the operator registry.")
        if record.linked_user_id is not None:
            raise serializers.ValidationError("This operator code is already linked to an account.")
        return value

    def validate(self, attrs):
        attrs = super().validate(attrs)
        attrs["_operator_record"] = OperatorCode.objects.get(code=attrs["operator_code"])
        return attrs

    def create(self, validated_data):
        validated_data.pop("confirm_password")
        operator_record: OperatorCode = validated_data.pop("_operator_record")
        validated_data.pop("rank_code")

        user = User.objects.create_user(
            email_or_phone=validated_data["email_or_phone"],
            password=validated_data["password"],
            role=Role.OPERATOR,
        )

        operator_record.linked_user = user
        operator_record.save(update_fields=["linked_user"])

        return user


# ---------------------------------------------------------------------------
# Administrator
# ---------------------------------------------------------------------------

class AdminRegistrationSerializer(BaseRegistrationSerializer):
    rank_code = serializers.CharField(max_length=5)
    manager_code = serializers.CharField(max_length=7)

    def validate_rank_code(self, value):
        if not RANK_CODE_RE.match(value):
            raise serializers.ValidationError("Rank code must be exactly 5 digits.")
        if not RankCode.objects.filter(code=value, is_active=True).exists():
            raise serializers.ValidationError("Rank code not recognised. Contact your station manager.")
        return value

    def validate_manager_code(self, value):
        if not MANAGER_CODE_RE.match(value):
            raise serializers.ValidationError("Administrator code must be exactly 7 digits.")
        try:
            record = ManagerCode.objects.get(code=value, is_active=True)
        except ManagerCode.DoesNotExist:
            raise serializers.ValidationError("Administrator code not found in the administrator registry.")
        if record.linked_user_id is not None:
            raise serializers.ValidationError("This administrator code is already linked to an account.")
        return value

    def validate(self, attrs):
        attrs = super().validate(attrs)
        attrs["_manager_record"] = ManagerCode.objects.get(code=attrs["manager_code"])
        return attrs

    def create(self, validated_data):
        validated_data.pop("confirm_password")
        manager_record: ManagerCode = validated_data.pop("_manager_record")
        validated_data.pop("rank_code")

        user = User.objects.create_user(
            email_or_phone=validated_data["email_or_phone"],
            password=validated_data["password"],
            role=Role.ADMIN,
        )

        manager_record.linked_user = user
        manager_record.save(update_fields=["linked_user"])

        return user


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------

class LoginSerializer(serializers.Serializer):
    role = serializers.ChoiceField(choices=Role.choices)
    email_or_phone = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        user = authenticate(
            username=attrs["email_or_phone"],
            password=attrs["password"],
        )
        if user is None:
            raise serializers.ValidationError({"non_field_errors": ["Invalid credentials."]})
        if user.role != attrs["role"]:
            raise serializers.ValidationError(
                {"role": [f"This account is not registered as a {attrs['role']}."]}
            )
        if not user.is_active:
            raise serializers.ValidationError(
                {"non_field_errors": ["This account has been deactivated."]}
            )
        attrs["user"] = user
        return attrs
