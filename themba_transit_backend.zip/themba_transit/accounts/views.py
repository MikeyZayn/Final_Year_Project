from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Role
from .serializers import (
    AdminRegistrationSerializer,
    DriverRegistrationSerializer,
    LoginSerializer,
    OperatorRegistrationSerializer,
    PassengerRegistrationSerializer,
)

DASHBOARD_ROUTES = {
    Role.PASSENGER: "/dashboard/passenger",
    Role.DRIVER: "/dashboard/driver",
    Role.OPERATOR: "/dashboard/operator",
    Role.ADMIN: "/dashboard/admin",
}


def _complete_registration(serializer_class, request):
    serializer = serializer_class(data=request.data)
    serializer.is_valid(raise_exception=True)
    user = serializer.save()
    token, _ = Token.objects.get_or_create(user=user)
    return Response(
        {
            "detail": "Account created.",
            "token": token.key,
            "role": user.role,
            "dashboard_route": DASHBOARD_ROUTES[user.role],
        },
        status=status.HTTP_201_CREATED,
    )


class RegisterPassengerView(APIView):
    """POST /api/register/passenger/"""

    permission_classes = [AllowAny]

    def post(self, request):
        return _complete_registration(PassengerRegistrationSerializer, request)


class RegisterDriverView(APIView):
    """POST /api/register/driver/"""

    permission_classes = [AllowAny]

    def post(self, request):
        return _complete_registration(DriverRegistrationSerializer, request)


class RegisterOperatorView(APIView):
    """POST /api/register/operator/"""

    permission_classes = [AllowAny]

    def post(self, request):
        return _complete_registration(OperatorRegistrationSerializer, request)


class RegisterAdminView(APIView):
    """POST /api/register/admin/"""

    permission_classes = [AllowAny]

    def post(self, request):
        return _complete_registration(AdminRegistrationSerializer, request)


class LoginView(APIView):
    """POST /api/login/   body: { role, email_or_phone, password }"""

    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data["user"]
        token, _ = Token.objects.get_or_create(user=user)
        return Response(
            {
                "token": token.key,
                "role": user.role,
                "dashboard_route": DASHBOARD_ROUTES[user.role],
            },
            status=status.HTTP_200_OK,
        )
