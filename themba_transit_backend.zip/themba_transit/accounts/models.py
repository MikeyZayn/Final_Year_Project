import uuid

from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models


# ---------------------------------------------------------------------------
# User
# ---------------------------------------------------------------------------

class Role(models.TextChoices):
    PASSENGER = "passenger", "Passenger"
    DRIVER = "driver", "Driver"
    OPERATOR = "operator", "Operator"
    ADMIN = "admin", "Administrator"


class UserManager(BaseUserManager):
    def create_user(self, email_or_phone, password=None, role=Role.PASSENGER, **extra_fields):
        if not email_or_phone:
            raise ValueError("Email or phone number is required.")
        user = self.model(email_or_phone=email_or_phone, role=role, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email_or_phone, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("role", Role.ADMIN)
        return self.create_user(email_or_phone, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    """
    Shared account table for passengers, drivers, operators and admins.
    `email_or_phone` mirrors the "Email or Number" field on every screen.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email_or_phone = models.CharField(max_length=150, unique=True, db_index=True)
    role = models.CharField(max_length=12, choices=Role.choices, default=Role.PASSENGER, db_index=True)

    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)

    objects = UserManager()

    USERNAME_FIELD = "email_or_phone"
    REQUIRED_FIELDS = []

    def __str__(self):
        return f"{self.email_or_phone} ({self.role})"


class EmergencyContact(models.Model):
    """Optional field revealed by the 'Show optional fields' toggle (passenger only)."""

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="emergency_contact")
    name = models.CharField(max_length=150)
    phone_number = models.CharField(max_length=30, blank=True)
    relationship = models.CharField(max_length=50, blank=True)

    def __str__(self):
        return f"Emergency contact for {self.user}"


# ---------------------------------------------------------------------------
# Reference tables the registration flow cross-checks against
# ---------------------------------------------------------------------------

class RankCode(models.Model):
    """
    Unique per rank/station. A plain 5-digit code — deliberately holds NO
    personal information, it only proves the applicant belongs to a
    legitimate rank/station.
    """

    code = models.CharField(max_length=5, unique=True, db_index=True)
    station_name = models.CharField(max_length=150)
    is_active = models.BooleanField(default=True, db_index=True)

    def __str__(self):
        return f"{self.code} — {self.station_name}"


class LicenceRecord(models.Model):
    """Pre-loaded driver licence records (7-digit licence number)."""

    licence_number = models.CharField(max_length=7, unique=True, db_index=True)
    full_name = models.CharField(max_length=150)
    national_id = models.CharField(max_length=40)
    is_active = models.BooleanField(default=True, db_index=True)
    linked_user = models.OneToOneField(
        User, null=True, blank=True, on_delete=models.SET_NULL, related_name="licence_record"
    )

    def __str__(self):
        return f"{self.licence_number} — {self.full_name}"


class OperatorCode(models.Model):
    """Pre-loaded operator records (7-digit operator code)."""

    code = models.CharField(max_length=7, unique=True, db_index=True)
    full_name = models.CharField(max_length=150)
    national_id = models.CharField(max_length=40)
    is_active = models.BooleanField(default=True, db_index=True)
    linked_user = models.OneToOneField(
        User, null=True, blank=True, on_delete=models.SET_NULL, related_name="operator_record"
    )

    def __str__(self):
        return f"{self.code} — {self.full_name}"


class ManagerCode(models.Model):
    """Pre-loaded manager/administrator records (7-digit administrator code)."""

    code = models.CharField(max_length=7, unique=True, db_index=True)
    full_name = models.CharField(max_length=150)
    national_id = models.CharField(max_length=40)
    is_active = models.BooleanField(default=True, db_index=True)
    linked_user = models.OneToOneField(
        User, null=True, blank=True, on_delete=models.SET_NULL, related_name="manager_record"
    )

    def __str__(self):
        return f"{self.code} — {self.full_name}"
