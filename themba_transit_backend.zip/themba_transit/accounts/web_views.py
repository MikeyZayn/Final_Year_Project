from django.contrib.auth import logout as django_logout
from django.shortcuts import redirect, render
from rest_framework.authtoken.models import Token

from .models import Role
from .serializers import (
    AdminRegistrationSerializer,
    DriverRegistrationSerializer,
    LoginSerializer,
    OperatorRegistrationSerializer,
    PassengerRegistrationSerializer,
)

DASHBOARD_ROUTES = {
    Role.PASSENGER: "web-dashboard-passenger",
    Role.DRIVER: "web-dashboard-driver",
    Role.OPERATOR: "web-dashboard-operator",
    Role.ADMIN: "web-dashboard-admin",
}


def home(request):
    return render(request, "accounts/home.html")


def _login_user(request, user):
    token, _ = Token.objects.get_or_create(user=user)
    request.session["auth_token"] = token.key
    request.session["role"] = user.role
    request.session["email_or_phone"] = user.email_or_phone
    return redirect(DASHBOARD_ROUTES[user.role])


def _flatten_errors(drf_errors):
    flat = {}
    banner_bits = []
    for key, value in drf_errors.items():
        if isinstance(value, list) and all(isinstance(v, str) for v in value):
            flat[key] = value
        else:
            banner_bits.append(f"{key}: {value}")
    if banner_bits:
        flat.setdefault("_banner", []).extend(banner_bits)
    return flat


# ---------------------------------------------------------------------------
# Registration — creates account and routes straight to dashboard
# ---------------------------------------------------------------------------

def register_passenger(request):
    if request.method != "POST":
        return render(request, "accounts/register_passenger.html", {"form_data": {}})

    emergency_contact = None
    if request.POST.get("contact_name_text"):
        emergency_contact = {
            "name": request.POST.get("contact_name_text", ""),
            "phone_number": request.POST.get("contact_phone", ""),
            "relationship": request.POST.get("contact_relationship", ""),
        }

    data = {
        "email_or_phone": request.POST.get("email_or_phone", ""),
        "password": request.POST.get("password", ""),
        "confirm_password": request.POST.get("confirm_password", ""),
    }
    if emergency_contact:
        data["emergency_contact"] = emergency_contact

    serializer = PassengerRegistrationSerializer(data=data)
    if serializer.is_valid():
        user = serializer.save()
        return _login_user(request, user)

    form_data = dict(request.POST)
    form_data["email_or_phone"] = request.POST.get("email_or_phone", "")
    form_data["show_optional"] = bool(emergency_contact)
    form_data["contact_name"] = "__new__" if emergency_contact else ""
    form_data["contact_name_text"] = request.POST.get("contact_name_text", "")
    form_data["contact_phone"] = request.POST.get("contact_phone", "")
    form_data["contact_relationship"] = request.POST.get("contact_relationship", "")

    return render(
        request,
        "accounts/register_passenger.html",
        {"errors": _flatten_errors(serializer.errors), "form_data": form_data},
    )


def register_driver(request):
    if request.method != "POST":
        return render(request, "accounts/register_driver.html", {"form_data": {}})

    data = {
        "email_or_phone": request.POST.get("email_or_phone", ""),
        "password": request.POST.get("password", ""),
        "confirm_password": request.POST.get("confirm_password", ""),
        "rank_code": request.POST.get("rank_code", ""),
        "licence_number": request.POST.get("licence_number", ""),
    }

    serializer = DriverRegistrationSerializer(data=data)
    if serializer.is_valid():
        user = serializer.save()
        return _login_user(request, user)

    return render(
        request,
        "accounts/register_driver.html",
        {"errors": _flatten_errors(serializer.errors), "form_data": data},
    )


def register_operator(request):
    if request.method != "POST":
        return render(request, "accounts/register_operator.html", {"form_data": {}})

    data = {
        "email_or_phone": request.POST.get("email_or_phone", ""),
        "password": request.POST.get("password", ""),
        "confirm_password": request.POST.get("confirm_password", ""),
        "rank_code": request.POST.get("rank_code", ""),
        "operator_code": request.POST.get("operator_code", ""),
    }

    serializer = OperatorRegistrationSerializer(data=data)
    if serializer.is_valid():
        user = serializer.save()
        return _login_user(request, user)

    return render(
        request,
        "accounts/register_operator.html",
        {"errors": _flatten_errors(serializer.errors), "form_data": data},
    )


def register_admin(request):
    if request.method != "POST":
        return render(request, "accounts/register_admin.html", {"form_data": {}})

    data = {
        "email_or_phone": request.POST.get("email_or_phone", ""),
        "password": request.POST.get("password", ""),
        "confirm_password": request.POST.get("confirm_password", ""),
        "rank_code": request.POST.get("rank_code", ""),
        "manager_code": request.POST.get("manager_code", ""),
    }

    serializer = AdminRegistrationSerializer(data=data)
    if serializer.is_valid():
        user = serializer.save()
        return _login_user(request, user)

    return render(
        request,
        "accounts/register_admin.html",
        {"errors": _flatten_errors(serializer.errors), "form_data": data},
    )


# ---------------------------------------------------------------------------
# Login / logout
# ---------------------------------------------------------------------------

def login_view(request):
    if request.method != "POST":
        return render(request, "accounts/login.html", {"form_data": {"role": "passenger"}})

    data = {
        "role": request.POST.get("role", "passenger"),
        "email_or_phone": request.POST.get("email_or_phone", ""),
        "password": request.POST.get("password", ""),
    }
    serializer = LoginSerializer(data=data)
    if serializer.is_valid():
        return _login_user(request, serializer.validated_data["user"])

    errors = _flatten_errors(serializer.errors)
    banner_bits = errors.get("_banner", []) + errors.get("non_field_errors", []) + errors.get("role", [])
    return render(
        request,
        "accounts/login.html",
        {"errors": errors, "form_data": data, "error": "; ".join(banner_bits)},
    )


def logout_view(request):
    request.session.flush()
    django_logout(request)
    return redirect("web-login")


# ---------------------------------------------------------------------------
# Dashboards
# ---------------------------------------------------------------------------

def _dashboard(request, expected_role):
    if request.session.get("role") != expected_role or not request.session.get("auth_token"):
        return redirect("web-login")
    return render(
        request,
        "accounts/dashboard.html",
        {"role": expected_role, "email_or_phone": request.session.get("email_or_phone")},
    )


def dashboard_passenger(request):
    return _dashboard(request, Role.PASSENGER)


def dashboard_driver(request):
    return _dashboard(request, Role.DRIVER)


def dashboard_operator(request):
    return _dashboard(request, Role.OPERATOR)


def dashboard_admin(request):
    return _dashboard(request, Role.ADMIN)
