from django.core.management.base import BaseCommand

from accounts.models import LicenceRecord, ManagerCode, OperatorCode, RankCode


class Command(BaseCommand):
    help = "Seed RankCode / LicenceRecord / OperatorCode / ManagerCode tables with sample data for testing."

    def handle(self, *args, **options):
        rank_codes = [
            ("10234", "Central Rank Station"),
            ("10567", "Northgate Rank Station"),
            ("20011", "Head Office"),
        ]
        for code, station in rank_codes:
            RankCode.objects.get_or_create(code=code, defaults={"station_name": station})

        licences = [
            ("8830112", "Thabo Nkosi", "ID-9001-XZ"),
            ("4471056", "Sarah Connor", "ID-4482-QP"),
        ]
        for licence_number, full_name, national_id in licences:
            LicenceRecord.objects.get_or_create(
                licence_number=licence_number,
                defaults={"full_name": full_name, "national_id": national_id},
            )

        operators = [
            ("5510234", "Lerato Mokoena", "ID-5510-LM"),
            ("6621345", "Pieter van Wyk", "ID-6621-PV"),
        ]
        for code, full_name, national_id in operators:
            OperatorCode.objects.get_or_create(
                code=code,
                defaults={"full_name": full_name, "national_id": national_id},
            )

        managers = [
            ("1290045", "Naledi Dube", "ID-1123-RT"),
        ]
        for code, full_name, national_id in managers:
            ManagerCode.objects.get_or_create(
                code=code,
                defaults={"full_name": full_name, "national_id": national_id},
            )

        self.stdout.write(self.style.SUCCESS("Reference data seeded."))
        self.stdout.write(
            "Sample rank: 10234 | licence: 8830112 | operator: 5510234 | admin: 1290045"
        )
