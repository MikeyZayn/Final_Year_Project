import re
from django.core.exceptions import ValidationError


class ComplexPasswordValidator:
    """
    Enforces the password policy shown on every "Create Account" screen:
      - at least 8 characters
      - at least one uppercase letter
      - at least one lowercase letter
      - at least one digit
    """

    MIN_LENGTH = 8

    def validate(self, password, user=None):
        errors = []

        if len(password) < self.MIN_LENGTH:
            errors.append(f"Password must be at least {self.MIN_LENGTH} characters long.")
        if not re.search(r"[A-Z]", password):
            errors.append("Password must contain at least one uppercase letter.")
        if not re.search(r"[a-z]", password):
            errors.append("Password must contain at least one lowercase letter.")
        if not re.search(r"\d", password):
            errors.append("Password must contain at least one digit.")

        if errors:
            raise ValidationError(errors)

    def get_help_text(self):
        return (
            "Your password must be at least 8 characters long and include "
            "at least one uppercase letter, one lowercase letter, and one digit."
        )


def validate_password_complexity(password: str) -> list[str]:
    """Non-exception helper used by serializers to collect all failing rules at once."""
    errors = []
    if len(password) < ComplexPasswordValidator.MIN_LENGTH:
        errors.append("At least 8 characters.")
    if not re.search(r"[A-Z]", password):
        errors.append("At least one uppercase letter.")
    if not re.search(r"[a-z]", password):
        errors.append("At least one lowercase letter.")
    if not re.search(r"\d", password):
        errors.append("At least one digit.")
    return errors
