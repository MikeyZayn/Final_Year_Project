from django.urls import path

from . import web_views

urlpatterns = [
    path("", web_views.home, name="web-home"),
    path("register/passenger/", web_views.register_passenger, name="web-register-passenger"),
    path("register/driver/", web_views.register_driver, name="web-register-driver"),
    path("register/operator/", web_views.register_operator, name="web-register-operator"),
    path("register/admin/", web_views.register_admin, name="web-register-admin"),
    path("login/", web_views.login_view, name="web-login"),
    path("logout/", web_views.logout_view, name="web-logout"),
    path("dashboard/passenger/", web_views.dashboard_passenger, name="web-dashboard-passenger"),
    path("dashboard/driver/", web_views.dashboard_driver, name="web-dashboard-driver"),
    path("dashboard/operator/", web_views.dashboard_operator, name="web-dashboard-operator"),
    path("dashboard/admin/", web_views.dashboard_admin, name="web-dashboard-admin"),
]
