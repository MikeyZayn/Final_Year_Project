from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .models import (
    EmergencyContact,
    LicenceRecord,
    ManagerCode,
    OperatorCode,
    RankCode,
    User,
)


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    model = User
    list_display = ("email_or_phone", "role", "is_active", "created_at")
    list_filter = ("role", "is_active")
    search_fields = ("email_or_phone",)
    ordering = ("-created_at",)
    fieldsets = (
        (None, {"fields": ("email_or_phone", "password")}),
        ("Status", {"fields": ("role", "is_active", "is_staff", "is_superuser")}),
        ("Permissions", {"fields": ("groups", "user_permissions")}),
    )
    add_fieldsets = (
        (None, {"classes": ("wide",), "fields": ("email_or_phone", "role", "password1", "password2")}),
    )
    filter_horizontal = ("groups", "user_permissions")


@admin.register(EmergencyContact)
class EmergencyContactAdmin(admin.ModelAdmin):
    list_display = ("user", "name", "phone_number", "relationship")


@admin.register(RankCode)
class RankCodeAdmin(admin.ModelAdmin):
    list_display = ("code", "station_name", "is_active")
    search_fields = ("code", "station_name")


@admin.register(LicenceRecord)
class LicenceRecordAdmin(admin.ModelAdmin):
    list_display = ("licence_number", "full_name", "national_id", "is_active", "linked_user")
    search_fields = ("licence_number", "full_name", "national_id")


@admin.register(OperatorCode)
class OperatorCodeAdmin(admin.ModelAdmin):
    list_display = ("code", "full_name", "national_id", "is_active", "linked_user")
    search_fields = ("code", "full_name", "national_id")


@admin.register(ManagerCode)
class ManagerCodeAdmin(admin.ModelAdmin):
    list_display = ("code", "full_name", "national_id", "is_active", "linked_user")
    search_fields = ("code", "full_name", "national_id")
