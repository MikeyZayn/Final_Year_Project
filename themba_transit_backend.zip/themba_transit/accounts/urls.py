from django.urls import path

from . import views

urlpatterns = [
    path("register/passenger/", views.RegisterPassengerView.as_view(), name="register-passenger"),
    path("register/driver/", views.RegisterDriverView.as_view(), name="register-driver"),
    path("register/operator/", views.RegisterOperatorView.as_view(), name="register-operator"),
    path("register/admin/", views.RegisterAdminView.as_view(), name="register-admin"),
    path("login/", views.LoginView.as_view(), name="login"),
]
