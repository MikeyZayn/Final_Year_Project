import { useState } from 'react';
import thembaApi from '../api/themba';

const DEFAULTS = {
  originLat: -28.755,
  originLng: 32.045,
  destinationLat: -28.769,
  destinationLng: 32.048,
  vehicleId: 1,
  fraction: 0.5,
  testDistanceKm: 14.2,
  testDurationMin: 28,
};

/**
 * A raw testing panel for developers: lets you type in coordinates and a
 * vehicle id and directly exercise the search/estimate/directions/simulate
 * endpoints, showing the JSON responses (fare, time, distance, speed).
 * Useful for verifying the routing engine before wiring up real UI flows
 * or a real GPS-equipped driver device.
 */
function DevRoutingTester({ notify }) {
  const [form, setForm] = useState(DEFAULTS);
  const [output, setOutput] = useState(null);
  const [busy, setBusy] = useState(false);

  function update(field, value) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  async function run(action) {
    setBusy(true);
    setOutput(null);
    try {
      let result;
      const origin = { lat: Number(form.originLat), lng: Number(form.originLng) };
      const destination = { lat: Number(form.destinationLat), lng: Number(form.destinationLng) };

      if (action === 'search') {
        result = await thembaApi.searchRoutes({ origin, destination });
      } else if (action === 'calculate') {
        // Mirrors what routingApi.js + RouteSelectionScreen do in real use,
        // but with a fake distance/duration typed in here instead of a real
        // Google Route.computeRoutes() call - useful for testing the fare
        // formula (TaxiFareRule) without touching Google Maps at all.
        result = await thembaApi.calculateRoute({
          start: origin,
          destination,
          distanceKm: Number(form.testDistanceKm),
          durationMin: Number(form.testDurationMin),
        });
      } else if (action === 'simulate') {
        result = await thembaApi.simulateVehicleMovement(Number(form.vehicleId), Number(form.fraction));
      } else if (action === 'vehicles') {
        result = await thembaApi.listVehicles();
      }
      setOutput(result);
      notify?.(`Dev test: ${action} succeeded`);
    } catch (err) {
      setOutput({ error: err.message });
      notify?.(`Dev test: ${action} failed - ${err.message}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="dev-routing-tester">
      <div className="dev-tester-grid">
        <label>
          Origin lat
          <input value={form.originLat} onChange={(e) => update('originLat', e.target.value)} />
        </label>
        <label>
          Origin lng
          <input value={form.originLng} onChange={(e) => update('originLng', e.target.value)} />
        </label>
        <label>
          Destination lat
          <input value={form.destinationLat} onChange={(e) => update('destinationLat', e.target.value)} />
        </label>
        <label>
          Destination lng
          <input value={form.destinationLng} onChange={(e) => update('destinationLng', e.target.value)} />
        </label>
        <label>
          Vehicle ID
          <input value={form.vehicleId} onChange={(e) => update('vehicleId', e.target.value)} />
        </label>
        <label>
          Test distance (km)
          <input value={form.testDistanceKm} onChange={(e) => update('testDistanceKm', e.target.value)} />
        </label>
        <label>
          Test duration (min)
          <input value={form.testDurationMin} onChange={(e) => update('testDurationMin', e.target.value)} />
        </label>
        <label>
          Simulate fraction (0-1)
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={form.fraction}
            onChange={(e) => update('fraction', e.target.value)}
          />
        </label>
      </div>

      <div className="dev-tester-actions">
        <button className="secondary-button" type="button" disabled={busy} onClick={() => run('search')}>
          Test route search (fare/time/distance)
        </button>
        <button className="secondary-button" type="button" disabled={busy} onClick={() => run('calculate')}>
          Test ad-hoc fare calculation
        </button>
        <button className="secondary-button" type="button" disabled={busy} onClick={() => run('simulate')}>
          Advance simulated vehicle (speed/position)
        </button>
        <button className="secondary-button" type="button" disabled={busy} onClick={() => run('vehicles')}>
          List live vehicles
        </button>
      </div>

      {output && <pre className="dev-tester-output">{JSON.stringify(output, null, 2)}</pre>}

      <p className="muted small">
        Backed by <code>GET /api/routes/search/</code>, <code>POST /api/routing/calculate/</code>,{' '}
        <code>POST /api/vehicles/&#123;id&#125;/simulate/</code> and <code>GET /api/vehicles/</code>. Run{' '}
        <code>python manage.py seed_demo_data</code> on the backend first so vehicle id 1 exists.
      </p>
    </div>
  );
}

export default DevRoutingTester;
