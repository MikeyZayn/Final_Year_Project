import { useEffect, useMemo, useState } from 'react';
import GoogleTransportMap from './GoogleTransportMap';
import thembaApi from '../api/themba';
import { computeRoute } from '../services/routingApi';
import { useGeolocation } from '../hooks/useGeolocation';
import {
  PREDETERMINED_PLACES,
  lookupLocalFare,
  nearestRank,
} from '../data/localFares';
import './passengerMapDashboard.css';

const PLACES = PREDETERMINED_PLACES;

const DEMO_TRIPS = [
  {
    id: 'TH-ONG-001',
    origin: 'Ongoye',
    destination: 'Empangeni',
    departure: '08:30',
    status: 'Boarding',
    operator: 'Ongoye Taxi Association',
    driver: 'Bongani Mthembu',
    vehicle: 'Toyota Quantum',
    registration: 'ND 123-456',
  },
  {
    id: 'TH-ONG-002',
    origin: 'Ongoye',
    destination: 'Esikhawini',
    departure: '09:00',
    status: 'Scheduled',
    operator: 'Ongoye Taxi Association',
    driver: 'Nomvula Khumalo',
    vehicle: 'Toyota Quantum',
    registration: 'ND 345-678',
  },
  {
    id: 'TH-ONG-003',
    origin: 'Ongoye',
    destination: 'Richards Bay',
    departure: '07:45',
    status: 'Scheduled',
    operator: 'Richards Bay Taxi Association',
    driver: 'Thabo Nkosi',
    vehicle: 'Toyota Quantum',
    registration: 'ND 654-321',
  },
  {
    id: 'TH-ESI-001',
    origin: 'Esikhawini',
    destination: 'Empangeni',
    departure: '10:00',
    status: 'Scheduled',
    operator: 'Esikhawini Taxi Association',
    driver: 'Sipho Zulu',
    vehicle: 'Toyota Quantum',
    registration: 'ND 789-012',
  },
  {
    id: 'TH-ESI-002',
    origin: 'Esikhawini',
    destination: 'Richards Bay',
    departure: '11:15',
    status: 'Scheduled',
    operator: 'Esikhawini Taxi Association',
    driver: 'Lindiwe Dlamini',
    vehicle: 'Toyota Quantum',
    registration: 'ND 456-789',
  },
  {
    id: 'TH-RB-001',
    origin: 'Richards Bay',
    destination: 'Empangeni',
    departure: '12:00',
    status: 'Scheduled',
    operator: 'Empangeni Taxi Association',
    driver: 'Sizwe Mkhize',
    vehicle: 'Toyota Quantum',
    registration: 'ND 567-890',
  },
];

const FARE_ROWS = [
  ['Ongoye', 'Empangeni', 24],
  ['Ongoye', 'Esikhawini', 20],
  ['Ongoye', 'Richards Bay', 34],
  ['Esikhawini', 'Empangeni', 23],
  ['Esikhawini', 'Richards Bay', 18],
  ['Richards Bay', 'Empangeni', 21],
];

function placeByName(name) {
  return PLACES.find((p) => p.name === name) || null;
}

/**
 * Full-screen passenger UI matching the map mockup:
 * left rail (search + fares) · map · matching trips card
 */
function PassengerMapDashboard({
  notify,
  passengerName = 'Sibusiso Dlamini',
  onExit,
}) {
  const geo = useGeolocation({ watch: false });
  const [departure, setDeparture] = useState('Ongoye');
  const [destination, setDestination] = useState('Empangeni');
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState(null);
  const [taxiGeometry, setTaxiGeometry] = useState([]); // rank → dest (ORS)
  const [toRankGeometry, setToRankGeometry] = useState([]); // GPS → rank (ORS)
  const [loading, setLoading] = useState(false);
  const [mapMode, setMapMode] = useState(false); // after Search route on map
  const [nearestHint, setNearestHint] = useState(null);
  const [panicOpen, setPanicOpen] = useState(false);
  const [booked, setBooked] = useState(false);

  const initials = useMemo(
    () =>
      passengerName
        .split(/\s+/)
        .map((p) => p[0])
        .join('')
        .slice(0, 2)
        .toUpperCase(),
    [passengerName]
  );

  const depPlace = placeByName(departure);
  const destPlace = placeByName(destination);

  function searchTrip() {
    if (departure === destination) {
      notify?.('Departure and destination must be different.');
      setResults([]);
      return;
    }
    const fare = lookupLocalFare(departure, destination);
    if (fare == null) {
      notify?.('No predetermined local taxi route for that pair.');
      setResults([]);
      return;
    }
    let matched = DEMO_TRIPS.filter(
      (t) =>
        (t.origin === departure && t.destination === destination) ||
        (t.origin === destination && t.destination === departure)
    ).map((t) => ({ ...t, origin: departure, destination, fare: `R${fare}` }));

    if (!matched.length) {
      matched = [
        {
          id: `TH-${departure.slice(0, 3).toUpperCase()}-X`,
          origin: departure,
          destination,
          departure: '08:30',
          status: 'Scheduled',
          operator: `${departure} Taxi Association`,
          driver: 'To be assigned',
          vehicle: 'Toyota Quantum',
          registration: '—',
          fare: `R${fare}`,
        },
      ];
    }
    setResults(matched);
    setSelected(matched[0]);
    setBooked(false);
    notify?.(`${matched.length} trip(s) · fare R${fare}`);
  }

  async function searchRouteOnMap() {
    if (!depPlace || !destPlace) {
      notify?.('Select valid departure and destination.');
      return;
    }
    if (departure === destination) {
      notify?.('Departure and destination must be different.');
      return;
    }

    setLoading(true);
    setMapMode(true);
    setTaxiGeometry([]);
    setToRankGeometry([]);

    try {
      // Prefer GPS → nearest/selected rank → destination (ORS only)
      const gps = geo.position
        ? { lat: geo.position.lat, lng: geo.position.lng }
        : null;

      let rank = { lat: depPlace.lat, lng: depPlace.lng, name: depPlace.name };

      if (gps) {
        const nearest = nearestRank(gps.lat, gps.lng);
        // If user left default or GPS is closer to another rank, still honour selected departure for taxi leg
        // but always draw GPS → selected departure rank first
        const dist =
          Math.hypot(gps.lat - rank.lat, gps.lng - rank.lng);
        if (dist > 0.0015) {
          const leg1 = await computeRoute(gps, rank);
          setToRankGeometry(leg1.geometry || []);
          if (nearest && nearest.name !== rank.name) {
            notify?.(
              `Routing via ${rank.name}. Nearest rank to you is ${nearest.name} (${nearest.distanceKm} km).`
            );
          }
        }
      } else {
        geo.requestOnce?.();
      }

      const leg2 = await computeRoute(rank, destPlace);
      setTaxiGeometry(leg2.geometry || []);

      // Ensure matching trips for the card
      if (!results.length) searchTrip();
      notify?.(`Route: your location → ${rank.name} → ${destPlace.name} (ORS)`);
    } catch (err) {
      notify?.(err.message || 'Routing failed. Check ORS_API_KEY and backend.');
    } finally {
      setLoading(false);
    }
  }

  function confirmBooking() {
    if (!selected) {
      notify?.('Select a trip first.');
      return;
    }
    setBooked(true);
    notify?.(
      `Booked ${selected.origin} → ${selected.destination} · ${selected.fare}`
    );
  }

  function confirmPanic() {
    setPanicOpen(false);
    notify?.(
      selected
        ? `Emergency alert sent for ${selected.origin} → ${selected.destination}.`
        : 'Emergency alert sent.'
    );
    const API = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000/api';
    const body = {
      type: 'PANIC_ALERT',
      tripId: selected?.id,
      departurePoint: selected?.origin || departure,
      destination: selected?.destination || destination,
      timestamp: new Date().toISOString(),
    };
    navigator.geolocation?.getCurrentPosition(
      (pos) => {
        fetch(`${API}/panic-alerts/`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...body,
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
          }),
        }).catch(() => {});
      },
      () => {
        fetch(`${API}/panic-alerts/`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        }).catch(() => {});
      },
      { timeout: 8000 }
    );
  }

  // GPS on mount: suggest nearest predetermined rank (user still sees Search Trip first)
  useEffect(() => {
    geo.requestOnce?.();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!geo.position) return;
    const nearest = nearestRank(geo.position.lat, geo.position.lng);
    if (!nearest) return;
    setNearestHint(nearest);
    // Pre-select nearest rank as departure so Search Trip matches image flow
    setDeparture(nearest.name);
  }, [geo.position]);

  return (
    <div className="pmd">
      <aside className="pmd-sidebar">
        <div className="pmd-brand">
          <span className="pmd-mark">T</span>
          <div>
            <strong>THEMBA</strong>
            <small>TRANSPORT HUB</small>
          </div>
        </div>

        <div className="pmd-profile">
          <div className="pmd-avatar">{initials}</div>
          <div className="pmd-profile-text">
            <span className="pmd-role">PASSENGER DASHBOARD</span>
            <strong>{passengerName}</strong>
          </div>
          <span className="pmd-verified">Verified</span>
        </div>

        <section className="pmd-section">
          <div className="pmd-section-head">
            <span>01. SEARCH TRIP</span>
          </div>
          <p className="pmd-hint">
            Choose a predetermined departure and destination. Fares are local taxi
            rates for supported routes only.
          </p>
          {nearestHint && (
            <div className="pmd-nearest">
              <span>Nearest rank from your GPS</span>
              <strong>
                {nearestHint.name} · {nearestHint.distanceKm} km
              </strong>
              <button
                type="button"
                className="pmd-link"
                onClick={() => setDeparture(nearestHint.name)}
              >
                Use as departure
              </button>
            </div>
          )}
          <label className="pmd-label">
            Departure point
            <select value={departure} onChange={(e) => setDeparture(e.target.value)}>
              {PLACES.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name}
                </option>
              ))}
            </select>
          </label>
          <label className="pmd-label">
            Destination
            <select
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
            >
              {PLACES.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name}
                </option>
              ))}
            </select>
          </label>
          <button type="button" className="pmd-btn-primary" onClick={searchTrip}>
            Search trip →
          </button>
          <button
            type="button"
            className="pmd-btn-secondary"
            onClick={searchRouteOnMap}
            disabled={loading}
          >
            {loading ? 'Routing…' : 'Search route on map →'}
          </button>
        </section>

        <section className="pmd-section pmd-fares">
          <div className="pmd-section-head">
            <span>02. LOCAL FARES</span>
          </div>
          <ul>
            {FARE_ROWS.map(([a, b, fare]) => (
              <li key={`${a}-${b}`}>
                <span>
                  {a} ↔ {b}
                </span>
                <strong>R{fare}</strong>
              </li>
            ))}
          </ul>
        </section>

        <div className="pmd-foot">
          <small>THEMBA Transport © 2026</small>
          <a className="pmd-link" href="#support" onClick={(e) => { e.preventDefault(); notify?.('Support: contact your operator or THEMBA admin.'); }}>
            Support
          </a>
        </div>
      </aside>

      <main className="pmd-map">
        <GoogleTransportMap
          origin={
            depPlace
              ? { lat: depPlace.lat, lng: depPlace.lng, label: departure }
              : null
          }
          destination={
            destPlace
              ? { lat: destPlace.lat, lng: destPlace.lng, label: destination }
              : null
          }
          routeGeometry={taxiGeometry.length > 2 ? taxiGeometry : []}
          secondaryRouteGeometry={toRankGeometry.length > 2 ? toRankGeometry : []}
          height="100%"
          initialCenter={[32.0, -28.8]}
          initialZoom={11}
        />

        {(results.length > 0 || selected) && (
          <div className="pmd-match-card">
            <div className="pmd-match-head">
              <span className="pmd-dot" />
              <span>MATCHING TRIPS</span>
              <span className="pmd-badge">03</span>
            </div>
            {results.map((trip) => (
              <button
                key={trip.id}
                type="button"
                className={
                  selected?.id === trip.id ? 'pmd-trip active' : 'pmd-trip'
                }
                onClick={() => setSelected(trip)}
              >
                <div>
                  <strong>
                    {trip.origin} → {trip.destination}
                  </strong>
                  <small>{trip.operator}</small>
                  <div className="pmd-trip-meta">
                    <span>{trip.departure} Departure</span>
                    <span className="pmd-status">{trip.status}</span>
                  </div>
                </div>
              </button>
            ))}
            {selected && (
              <>
                <div className="pmd-fare-block">
                  <span>OFFICIAL FARE</span>
                  <strong>{selected.fare}</strong>
                </div>
                {!booked ? (
                  <button
                    type="button"
                    className="pmd-btn-primary full"
                    onClick={confirmBooking}
                  >
                    Confirm Booking →
                  </button>
                ) : (
                  <>
                    <p className="pmd-booked">Booking confirmed</p>
                    <button
                      type="button"
                      className="pmd-btn-danger full"
                      onClick={() => setPanicOpen(true)}
                    >
                      Panic / Emergency
                    </button>
                  </>
                )}
              </>
            )}
          </div>
        )}
      </main>

      {panicOpen && (
        <div className="pmd-modal-backdrop" onClick={() => setPanicOpen(false)}>
          <div className="pmd-modal" onClick={(e) => e.stopPropagation()}>
            <h3>Send panic alert?</h3>
            <p>
              Operator and administrator will be notified with your trip and
              location.
            </p>
            <button type="button" className="pmd-btn-danger full" onClick={confirmPanic}>
              Confirm emergency
            </button>
            <button
              type="button"
              className="pmd-btn-secondary full"
              onClick={() => setPanicOpen(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default PassengerMapDashboard;
