import { useEffect, useState } from 'react';
import GoogleTransportMap from './GoogleTransportMap';
import thembaApi from '../api/themba';
import { computeRoute } from '../services/routingApi';
import { hasGoogleMapsKey } from '../services/googleMapsLoader';

/**
 * "Pick a Route" screen. Shows TWO distinct things side by side, per
 * THEMBA_SPEC §12 ("clearly distinguish calculated Calculated route /
 * predetermined THEMBA route / live vehicle position"):
 *
 *  1. The Google-CALCULATED route straight from origin to destination
 *     (OpenRouteService via backend, drawn as a dashed amber line) - always
 *     available, with THEMBA's own ad-hoc fare from /api/routing/calculate/.
 *  2. Predetermined THEMBA routes that serve this destination (solid blue
 *     line, from Django) - the existing "Pick a Route" list, unchanged.
 */
function RouteSelectionScreen({ origin, destination, onBack, onConfirm, notify }) {
  const [routeOptions, setRouteOptions] = useState([]);
  const [selectedRouteId, setSelectedRouteId] = useState(null);
  const [geometry, setGeometry] = useState([]);
  const [geometrySource, setGeometrySource] = useState(null); // "cached" | "osrm" | "fallback"
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  const [calculated, setCalculated] = useState(null); // { geometry, distanceKm, durationMin, fare, fareNotice }
  const [calcLoading, setCalcLoading] = useState(false);
  const [calcError, setCalcError] = useState('');

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    thembaApi
      .searchRoutes({ origin, destination })
      .then((data) => {
        if (cancelled) return;
        setRouteOptions(data.route_options || []);
        if (data.route_options?.length) {
          setSelectedRouteId(data.route_options[0].route_id);
        }
        setLoadError('');
      })
      .catch((err) => setLoadError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [origin, destination]);

  useEffect(() => {
    if (!selectedRouteId) return;
    thembaApi
      .getRouteDirections(selectedRouteId)
      .then((data) => {
        const points = data.geometry || [];
        setGeometry(points);
        // The backend doesn't track original source once geometry is cached
        // (route_directions always reports "cached" after the first fetch) -
        // but its straight-line fallback always writes exactly 2 points
        // (origin, destination), while real OSRM geometry is a dense
        // polyline. That's a reliable enough signal to flag it here, so a
        // stuck straight-line fallback is visible in the app itself instead
        // of only discoverable by comparing screenshots.
        setGeometrySource(points.length <= 2 && points.length > 0 ? 'fallback' : data.source || null);
      })
      .catch(() => {
        setGeometry([]);
        setGeometrySource(null);
      });
  }, [selectedRouteId]);

  // The Google-calculated route is computed ONCE per origin/destination
  // pair (THEMBA_SPEC §30 - never recalculate on every GPS tick), not on
  // every render or every predetermined-route selection.
  useEffect(() => {
    if (!origin || !destination) {
      setCalcError(origin ? '' : 'Set your location (GPS or "Choose on map") to see a calculated Calculated route.');
      return;
    }
    if (!hasGoogleMapsKey()) {
      setCalcError('Google Maps is not configured, so a calculated route is unavailable. Predetermined routes below still work.');
      return;
    }

    let cancelled = false;
    setCalcLoading(true);
    setCalcError('');

    computeRoute(origin, destination)
      .then(async (route) => {
        if (cancelled) return;
        const fareResult = await thembaApi.calculateRoute({
          start: origin,
          destination,
          distanceKm: route.distanceKm,
          durationMin: route.durationMin,
        });
        if (cancelled) return;
        setCalculated({
          geometry: route.geometry,
          distanceKm: route.distanceKm,
          durationMin: route.durationMin,
          trafficAware: route.trafficAware,
          fare: fareResult.estimated_fare,
          fareNotice: fareResult.fare_notice,
        });
      })
      .catch((err) => !cancelled && setCalcError(err.message))
      .finally(() => !cancelled && setCalcLoading(false));

    return () => {
      cancelled = true;
    };
  }, [origin, destination]);

  const selectedRoute = routeOptions.find((r) => r.route_id === selectedRouteId);

  return (
    <div className="route-selection-screen">
      <div className="route-selection-map">
        <GoogleTransportMap
          origin={origin ? { ...origin, label: 'Your location' } : null}
          destination={{ ...destination, label: destination.name || 'Destination' }}
          routeGeometry={geometry?.length > 2 ? geometry : (calculated?.geometry?.length > 2 ? calculated.geometry : [])}
          secondaryRouteGeometry={geometry?.length > 2 && calculated?.geometry?.length > 2 ? calculated.geometry : []}
          height="260px"
        />
        <button className="back-pill" type="button" onClick={onBack}>
          ← Back
        </button>
      </div>

      <div className="route-points-card">
        <div className="route-points-header">
          <span>Route Points</span>
          <span className="badge">Transit</span>
        </div>
        <div className="route-points-row">
          <div className="route-point">
            <span className="dot dot-origin" />
            <strong>Your Location</strong>
          </div>
          <span className="route-points-divider" />
          <div className="route-point">
            <span className="dot dot-destination" />
            <strong>{destination.name || 'Destination'}</strong>
          </div>
        </div>
      </div>

      <div className="calculated-route-card">
        <div className="calculated-route-header">
          <span className="dash-swatch" aria-hidden />
          <span>Calculated Calculated route</span>
          {calculated?.trafficAware && <span className="badge">Traffic-aware estimate</span>}
        </div>
        {calcLoading && <p className="muted small">Calculating road route…</p>}
        {calcError && <p className="muted small">{calcError}</p>}
        {calculated && !calcLoading && (
          <>
            <div className="confirmed-stats">
              <div>
                <span className="route-label">Distance</span>
                <strong>{calculated.distanceKm} km</strong>
              </div>
              <div>
                <span className="route-label">Estimated time</span>
                <strong>{Math.round(calculated.durationMin)} min</strong>
              </div>
              <div>
                <span className="route-label">Estimated fare</span>
                <strong>R{calculated.fare.toFixed(2)}</strong>
              </div>
            </div>
            <p className="muted small">{calculated.fareNotice}</p>
          </>
        )}
      </div>

      <div className="pick-route-header">
        <span>Pick a predetermined THEMBA route</span>
        <span className="muted small">{routeOptions.length} options</span>
      </div>

      {loading && <p className="muted small">Finding predetermined routes…</p>}
      {loadError && <p className="muted small">{loadError}</p>}
      {!loading && !loadError && routeOptions.length === 0 && (
        <p className="muted small">
          No predetermined THEMBA route currently serves this destination directly. You can still
          use the calculated Calculated route above.
        </p>
      )}

      {geometrySource === 'fallback' && (
        <p className="muted small route-geometry-warning">
          This route's line is an approximate straight-line estimate, not real road geometry - the
          THEMBA routing service isn't reachable right now. Distance/time shown for this route may
          be off; the calculated Calculated route above is unaffected.
        </p>
      )}

      <div className="route-option-list">
        {routeOptions.map((option) => (
          <button
            key={option.route_id}
            type="button"
            className={
              option.route_id === selectedRouteId ? 'route-option selected' : 'route-option'
            }
            onClick={() => setSelectedRouteId(option.route_id)}
          >
            <span className="route-option-icon" aria-hidden>
              🚐
            </span>
            <span className="route-option-body">
              <strong>{option.route_name}</strong>
              <small>
                R{option.fare.toFixed(2)} · {Math.round(option.duration_min)} min
              </small>
            </span>
            {option.route_id === selectedRouteId ? (
              <span className="check-badge">✓</span>
            ) : (
              <span className="radio-dot" />
            )}
          </button>
        ))}
      </div>

      {selectedRoute && (
        <div className="selected-route-summary">
          <div>
            <span className="eyebrow">Selected route</span>
            <strong>{selectedRoute.route_name}</strong>
          </div>
          <span className="eta-chip large">{Math.round(selectedRoute.duration_min)} min</span>
        </div>
      )}

      {selectedRoute && (
        <div className="fare-popup">
          <div className="fare-popup-row">
            <span>Vehicle</span>
            <strong>{selectedRoute.vehicle_class}</strong>
          </div>
          <div className="fare-popup-row">
            <span>Distance</span>
            <strong>{selectedRoute.distance_km} km</strong>
          </div>
          <div className="fare-popup-row">
            <span>Average speed</span>
            <strong>{selectedRoute.average_speed_kmh} km/h</strong>
          </div>
          <div className="fare-popup-row fare-popup-total">
            <span>Estimated fare</span>
            <strong>R{selectedRoute.fare.toFixed(2)}</strong>
          </div>

          <button
            className="primary-button full"
            type="button"
            onClick={() => {
              notify?.(`${selectedRoute.route_name} confirmed - R${selectedRoute.fare.toFixed(2)}`);
              onConfirm?.({ route: selectedRoute, geometry });
            }}
          >
            Confirm route <span>→</span>
          </button>
        </div>
      )}
    </div>
  );
}

export default RouteSelectionScreen;
