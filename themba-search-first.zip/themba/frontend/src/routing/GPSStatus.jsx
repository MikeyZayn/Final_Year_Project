const POOR_ACCURACY_THRESHOLD_M = 30;

/**
 * "Current speed: 62 km/h" / "Current speed: Unavailable"
 * "Accuracy: ±8 m" with a visual warning above POOR_ACCURACY_THRESHOLD_M.
 *
 * Never invents a speed value - if `speedKmh` is null/undefined, that is
 * shown explicitly as unavailable rather than defaulting to 0.
 */
function GPSStatus({ speedKmh, accuracyM, source = 'gps' }) {
  const hasSpeed = speedKmh !== null && speedKmh !== undefined && !Number.isNaN(speedKmh);
  const hasAccuracy = accuracyM !== null && accuracyM !== undefined && !Number.isNaN(accuracyM);
  const poorAccuracy = hasAccuracy && accuracyM > POOR_ACCURACY_THRESHOLD_M;

  return (
    <div className="gps-status">
      <div className="gps-status-row">
        <span className="route-label">Current speed</span>
        <strong>{hasSpeed ? `${Math.round(speedKmh)} km/h` : 'Unavailable'}</strong>
      </div>
      <div className="gps-status-row">
        <span className="route-label">Accuracy</span>
        <strong className={poorAccuracy ? 'gps-accuracy-poor' : 'gps-accuracy-good'}>
          {hasAccuracy ? `±${Math.round(accuracyM)} m` : 'Unavailable'}
        </strong>
      </div>
      {poorAccuracy && (
        <p className="muted small gps-status-warning">
          GPS accuracy is poor right now - position may be off by {Math.round(accuracyM)} m.
        </p>
      )}
      {source === 'simulated' && <TestDataTag />}
      {source === 'gps' && <LiveGpsTag />}
    </div>
  );
}

/** Explicit "TEST DATA" flag for any simulated/non-GPS value shown in the UI. */
export function TestDataTag({ label = 'TEST DATA' }) {
  return <span className="test-data-tag">{label}</span>;
}

/** Explicit "LIVE GPS" flag, the honest counterpart to TestDataTag (THEMBA_SPEC §31). */
export function LiveGpsTag({ label = 'LIVE GPS' }) {
  return <span className="live-gps-tag">{label}</span>;
}

export default GPSStatus;
