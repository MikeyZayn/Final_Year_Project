import { useEffect, useMemo, useState } from 'react';
import GoogleTransportMap from './GoogleTransportMap';
import thembaApi from '../api/themba';
import { computeRoute } from '../services/routingApi';
import { nearestRank, lookupLocalFare, PREDETERMINED_PLACES } from '../data/localFares';
import { useGeolocation } from '../hooks/useGeolocation';

/**
 * Passenger navigation panel — main passenger dashboard UI.
 * Left rail: profile, origin/destination (manual + GPS), frequent rides,
 * verify trip, panic. Main: map (Google tiles) + ORS routing + booking card.
 */
// Predetermined ranks (Search Trip / Search Route)
const DESTINATIONS = [
  { id: 'ongoye', name: 'Ongoye', area: 'uMhlathuze', lat: -28.854, lng: 31.846, fareHint: 'R24' },
  { id: 'empangeni', name: 'Empangeni', area: 'King Cetshwayo', lat: -28.7808, lng: 31.8925, fareHint: 'R21' },
  { id: 'esikhawini', name: 'Esikhawini', area: 'King Cetshwayo', lat: -28.883, lng: 31.9, fareHint: 'R20' },
  { id: 'richards-bay', name: 'Richards Bay', area: 'King Cetshwayo', lat: -28.781, lng: 32.0377, fareHint: 'R34' },
];

// Frequent rides shown in the sidebar (same set as predetermined destinations)
const FREQUENT_RIDES = DESTINATIONS.map((d) => ({
  id: d.id,
  label: d.name,
  fareHint: d.fareHint,
  destName: d.name,
  area: d.area,
  lat: d.lat,
  lng: d.lng,
}));

const KNOWN_PLACES = [
  ...DESTINATIONS.map((d) => ({ name: d.name, lat: d.lat, lng: d.lng })),
  { name: 'Empangeni Rank', lat: -28.7808, lng: 31.8925 },
  { name: 'UniZulu', lat: -28.854, lng: 31.846 },
  { name: 'Kwa-Dlangezwa', lat: -28.854, lng: 31.846 },
  { name: 'eSikhawini', lat: -28.883, lng: 31.9 },
  { name: 'eSikhaleni', lat: -28.883, lng: 31.9 },
  { name: 'Richards Bay Central', lat: -28.781, lng: 32.0377 },
];

const DEMO_TRIPS = [
  {
    id: 'TH-EMP-002',
    route: 'Empangeni to Richards Bay',
    departure: '09:00',
    fare: 'R35',
    status: 'Boarding',
    duration: '45 min',
    origin: 'Empangeni',
    destination: 'Richards Bay',
    eta: '09:45',
    driver: 'Bongani Mthembu',
    vehicle: 'Toyota Quantum ND 123-456',
  },
  {
    id: 'TH-EMP-003',
    route: 'Empangeni to Kwa-Dlangezwa',
    departure: '08:15',
    fare: 'R24',
    status: 'Scheduled',
    duration: '35 min',
    origin: 'Empangeni',
    destination: 'Kwa-Dlangezwa',
    eta: '08:50',
    driver: 'Nomvula Khumalo',
    vehicle: 'Toyota Quantum ND 345-678',
  },
  {
    id: 'TH-EMP-004',
    route: 'Empangeni to eSikhawini',
    departure: '10:00',
    fare: 'R28',
    status: 'Scheduled',
    duration: '40 min',
    origin: 'Empangeni',
    destination: 'eSikhawini',
    eta: '10:40',
    driver: 'Thabo Nkosi',
    vehicle: 'Toyota Quantum ND 654-321',
  },
];

function resolvePlace(query) {
  if (!query || typeof query !== 'string') return null;
  const q = query.trim().toLowerCase();
  if (!q) return null;
  return (
    KNOWN_PLACES.find(
      (p) => p.name.toLowerCase() === q || p.name.toLowerCase().includes(q)
    ) || null
  );
}

function PassengerNavigationPanel({
  notify,
  onClose,
  passengerName = 'Sibusiso Dlamini',
  activeTrip: externalActiveTrip,
  setActiveTrip: externalSetActiveTrip,
}) {
  const geo = useGeolocation({ watch: false });
  const [departureLabel, setDepartureLabel] = useState('Empangeni');
  const [destination, setDestination] = useState(null);
  const [origin, setOrigin] = useState(null);
  const [routeOptions, setRouteOptions] = useState([]);
  const [selectedRouteId, setSelectedRouteId] = useState(null);
  const [geometry, setGeometry] = useState([]);
  const [geometrySource, setGeometrySource] = useState(null);
  const [legToRank, setLegToRank] = useState([]); // GPS → departure rank (ORS)
  const [rankLabel, setRankLabel] = useState('');
  const [calculated, setCalculated] = useState(null);
  const [loading, setLoading] = useState(false);
  const [calcLoading, setCalcLoading] = useState(false);
  const [error, setError] = useState('');
  const [step, setStep] = useState('idle'); // idle | results | booking | confirmed | verified
  const [destInput, setDestInput] = useState('');
  const [originInput, setOriginInput] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [localActiveTrip, setLocalActiveTrip] = useState(null);
  const [panicArmed, setPanicArmed] = useState(false);

  const activeTrip = externalActiveTrip ?? localActiveTrip;
  const setActiveTrip = externalSetActiveTrip ?? setLocalActiveTrip;

  const selectedRoute = useMemo(
    () => routeOptions.find((r) => r.route_id === selectedRouteId) || null,
    [routeOptions, selectedRouteId]
  );

  const initials = useMemo(() => {
    return passengerName
      .split(/\s+/)
      .map((p) => p[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();
  }, [passengerName]);

  // Seed default origin (Empangeni rank) so UI is usable before GPS
  useEffect(() => {
    if (!origin) {
      setOrigin({ lat: -28.7808, lng: 31.8925, name: 'Empangeni' });
      setDepartureLabel('Empangeni');
      setOriginInput('Empangeni');
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // When GPS becomes available and user hasn't typed a custom origin, adopt it
  useEffect(() => {
    if (geo.position && departureLabel === 'Empangeni' && !originInput.trim()) {
      setOrigin({
        lat: geo.position.lat,
        lng: geo.position.lng,
        name: 'Your location',
      });
      setDepartureLabel('Current GPS');
      setOriginInput('Current GPS');
    }
  }, [geo.position]); // eslint-disable-line react-hooks/exhaustive-deps

  async function runSearch(dest) {
    if (!dest?.lat || !dest?.lng) {
      setError('Choose a destination (frequent ride or search).');
      return;
    }

    setError('');
    setLoading(true);
    setStep('results');
    setDestination(dest);
    setCalculated(null);
    setGeometry([]);
    setLegToRank([]);
    setRankLabel('');
    setSelectedRouteId(null);

    // 1) Resolve departure rank: selected origin place, or nearest rank from GPS
    let rank = null;
    const gps = geo.position
      ? { lat: geo.position.lat, lng: geo.position.lng }
      : origin?.name === 'Your location' || departureLabel === 'Current GPS'
        ? origin
        : null;

    if (origin && origin.name && origin.name !== 'Your location' && departureLabel !== 'Current GPS') {
      rank = { lat: origin.lat, lng: origin.lng, name: origin.name || departureLabel };
    } else if (gps?.lat != null) {
      const nearest = nearestRank(gps.lat, gps.lng);
      if (nearest) {
        rank = { lat: nearest.lat, lng: nearest.lng, name: nearest.name };
        setRankLabel(nearest.name);
        setDepartureLabel(nearest.name);
        setOrigin({ lat: nearest.lat, lng: nearest.lng, name: nearest.name });
        setOriginInput(nearest.name);
        notify?.(`Nearest departure rank: ${nearest.name} (${nearest.distanceKm} km)`);
      }
    } else if (origin?.lat != null) {
      rank = { lat: origin.lat, lng: origin.lng, name: origin.name || departureLabel };
    }

    if (!rank?.lat) {
      setError('Allow GPS or choose a departure rank first.');
      setLoading(false);
      return;
    }

    // Predetermined trip options (backend)
    try {
      const data = await thembaApi.searchRoutes({ origin: rank, destination: dest });
      const options = data.route_options || [];
      setRouteOptions(options);
      if (options.length) setSelectedRouteId(options[0].route_id);
    } catch (err) {
      setRouteOptions([]);
    } finally {
      setLoading(false);
    }

    // 2) ORS only: GPS → rank (if GPS away from rank), then rank → destination
    setCalcLoading(true);
    try {
      let toRankGeom = [];
      if (gps?.lat != null) {
        const distToRank = Math.hypot(gps.lat - rank.lat, gps.lng - rank.lng);
        // ~0.001 deg ≈ 100m — skip leg if already at rank
        if (distToRank > 0.0015) {
          const leg1 = await computeRoute(gps, rank);
          toRankGeom = leg1.geometry || [];
          setLegToRank(toRankGeom);
        }
      }

      const leg2 = await computeRoute(rank, dest);
      const localFare = lookupLocalFare(rank.name, dest.name || dest.destName);
      let fare = localFare;
      let fareNotice = localFare != null ? 'Local taxi fare' : null;
      if (fare == null) {
        try {
          const fareResult = await thembaApi.calculateRoute({
            start: rank,
            destination: dest,
            distanceKm: leg2.distanceKm,
            durationMin: leg2.durationMin,
          });
          fare = fareResult.estimated_fare;
          fareNotice = fareResult.fare_notice;
        } catch {
          fare = null;
        }
      }

      // Only ORS geometry on the map (rank → destination as main path)
      setGeometry([]); // never show predetermined blue/cache line
      setGeometrySource(null);
      setCalculated({
        geometry: leg2.geometry || [],
        distanceKm: leg2.distanceKm,
        durationMin: leg2.durationMin,
        trafficAware: false,
        source: leg2.source || 'ors',
        fare,
        fareNotice,
        viaRank: rank.name,
        legToRank: toRankGeom,
      });
    } catch (err) {
      setCalculated(null);
      setError(err.message || 'Route calculation unavailable.');
    } finally {
      setCalcLoading(false);
    }
  }

  // Predetermined geometry is not drawn — map shows ORS paths only (GPS→rank, rank→dest).
  useEffect(() => {
    setGeometry([]);
    setGeometrySource(null);
  }, [selectedRouteId]);


  function applyOriginFromText(text) {
    const q = (text || '').trim();
    if (!q) {
      setError('Enter a departure place name (e.g. Empangeni, Richards Bay).');
      return false;
    }
    if (q.toLowerCase() === 'current gps' || q.toLowerCase() === 'my location') {
      if (geo.position) {
        setOrigin({
          lat: geo.position.lat,
          lng: geo.position.lng,
          name: 'Your location',
        });
        setDepartureLabel('Current GPS');
        setOriginInput('Current GPS');
        setError('');
        return true;
      }
      setError('GPS not available yet. Allow location or try again.');
      return false;
    }
    const place = resolvePlace(q);
    if (place) {
      setOrigin({ lat: place.lat, lng: place.lng, name: place.name });
      setDepartureLabel(place.name);
      setOriginInput(place.name);
      setError('');
      return true;
    }
    // Allow lat,lng paste for power users
    const coordMatch = q.match(/^(-?\d+\.?\d*)\s*[, ]\s*(-?\d+\.?\d*)$/);
    if (coordMatch) {
      const lat = Number(coordMatch[1]);
      const lng = Number(coordMatch[2]);
      if (Number.isFinite(lat) && Number.isFinite(lng)) {
        setOrigin({ lat, lng, name: `${lat.toFixed(4)}, ${lng.toFixed(4)}` });
        setDepartureLabel('Custom coordinates');
        setOriginInput(q);
        setError('');
        return true;
      }
    }
    setError(
      'Unknown place. Try Empangeni, Richards Bay, Eshowe, Ongoye, or paste lat,lng.'
    );
    return false;
  }

  function handleUseGps() {
    geo.requestOnce?.();
    // Position will land via the effect; also try immediately if already known
    if (geo.position) {
      setOrigin({
        lat: geo.position.lat,
        lng: geo.position.lng,
        name: 'Your location',
      });
      setDepartureLabel('Current GPS');
      setOriginInput('Current GPS');
      setError('');
      notify?.('Using your current GPS location as departure.');
    } else {
      notify?.('Requesting GPS… allow location if prompted.');
    }
  }

  function handleOriginSubmit(e) {
    e.preventDefault();
    applyOriginFromText(originInput);
  }

  function handleFrequent(ride) {
    setDestInput(ride.label);
    runSearch({ name: ride.destName || ride.label, lat: ride.lat, lng: ride.lng });
  }

  function handleManualSearch(e) {
    e.preventDefault();
    const q = destInput.trim().toLowerCase();
    const known = FREQUENT_RIDES.find(
      (r) =>
        r.label.toLowerCase().includes(q) || r.destName.toLowerCase().includes(q)
    );
    if (known) {
      handleFrequent(known);
      return;
    }
    if (q.includes('dlangezwa') || q.includes('unizulu') || q.includes('ongoye')) {
      handleFrequent(FREQUENT_RIDES.find((r) => r.id === 'kwa-dlangezwa'));
      return;
    }
    if (q.includes('richards') || q.includes('rbay')) {
      handleFrequent(FREQUENT_RIDES.find((r) => r.id === 'richards-bay'));
      return;
    }
    if (q.includes('sikhawini') || q.includes('sikhaleni')) {
      handleFrequent(FREQUENT_RIDES.find((r) => r.id === 'esikhawini'));
      return;
    }
    if (q.includes('empangeni')) {
      handleFrequent(FREQUENT_RIDES.find((r) => r.id === 'empangeni'));
      return;
    }
    const place = resolvePlace(destInput);
    if (place) {
      runSearch({ name: place.name, lat: place.lat, lng: place.lng });
      return;
    }
    setError(
      'Type a known place (Empangeni, Richards Bay, Kwa-Dlangezwa, eSikhawini) or pick a frequent ride.'
    );
  }

  function openBooking() {
    if (!selectedRoute && !calculated) {
      setError('Select a route or wait for the calculated estimate.');
      return;
    }
    setStep('booking');
  }

  function confirmBooking() {
    const payload = selectedRoute
      ? {
          kind: 'predetermined',
          route: selectedRoute,
          geometry,
          origin,
          destination,
        }
      : {
          kind: 'calculated',
          route: {
            route_name: 'Calculated route',
            route_code: 'ADHOC',
            fare: calculated.fare,
            duration_min: calculated.durationMin,
            distance_km: calculated.distanceKm,
            from_stop: origin?.name || departureLabel,
            to_stop: destination?.name || 'Destination',
          },
          geometry: calculated.geometry,
          origin,
          destination,
        };
    setStep('confirmed');
    notify?.(
      selectedRoute
        ? `Booked ${selectedRoute.route_name} · R${Number(selectedRoute.fare).toFixed(2)}`
        : `Booked calculated route · R${Number(calculated.fare).toFixed(2)}`
    );
    return payload;
  }

  function verifyTripCode() {
    const cleaned = verificationCode.trim();
    if (!cleaned) {
      notify?.('Enter a verification code first (e.g. TH-EMP-002).');
      return;
    }
    const matched = DEMO_TRIPS.find(
      (t) => t.id.toLowerCase() === cleaned.toLowerCase()
    );
    if (!matched) {
      notify?.('Verification code not found. Try TH-EMP-002, TH-EMP-003 or TH-EMP-004.');
      return;
    }
    setActiveTrip(matched);
    setVerificationCode(matched.id);
    setStep('verified');
    notify?.(`Route ${matched.route} unlocked · ${matched.status}.`);
  }

  function triggerPanic() {
    if (!activeTrip && !selectedRoute && !calculated) {
      notify?.('No active or selected trip. Select a route first.');
      return;
    }
    const tripLabel =
      activeTrip?.route ||
      selectedRoute?.route_name ||
      (calculated ? 'Calculated route' : 'current journey');
    const ok = window.confirm(
      `Send emergency alert for ${tripLabel}?\n\nOperator and administrator will be notified with your location.`
    );
    if (!ok) return;
    setPanicArmed(true);
    notify?.(`🚨 Emergency alert sent for ${tripLabel}.`);
    try {
      const API = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000/api';
      const body = {
        type: 'PANIC_ALERT',
        tripId: activeTrip?.id || selectedRoute?.route_id,
        departurePoint: origin?.name || departureLabel,
        destination: destination?.name,
        timestamp: new Date().toISOString(),
      };
      navigator.geolocation?.getCurrentPosition(
        (pos) => {
          fetch(`${API}/panic-alerts/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              ...body,
              latitude: pos.coords.latitude,
              longitude: pos.coords.longitude,
              accuracy: pos.coords.accuracy,
            }),
          }).catch(() => {});
        },
        () => {
          fetch(`${API}/panic-alerts/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
          }).catch(() => {});
        },
        { enableHighAccuracy: true, timeout: 8000 }
      );
    } catch {
      /* optional */
    }
    window.setTimeout(() => setPanicArmed(false), 4000);
  }

  const fareDisplay = selectedRoute
    ? `R${Number(selectedRoute.fare).toFixed(0)}`
    : calculated
      ? `R${Number(calculated.fare).toFixed(0)}`
      : '—';

  const routeTitle = destination
    ? `${departureLabel} → ${destination.name || 'Destination'}`
    : 'Choose a destination';

  return (
    <div className={`nav-panel ${panicArmed ? 'nav-panel-panic' : ''}`}>
      <aside className="nav-panel-sidebar">
        <div className="nav-brand">
          <span className="nav-brand-mark">T</span>
          <div>
            <strong>THEMBA</strong>
            <small>TRANSPORT HUB</small>
          </div>
        </div>

        <div className="nav-profile">
          <div className="nav-avatar">{initials}</div>
          <div>
            <strong>{passengerName}</strong>
            <div className="nav-stats">
              <span>
                <em>48</em> trips
              </span>
              <span>
                <em>3</em> complaints
              </span>
            </div>
          </div>
        </div>

        {/* ORIGIN / DEPARTURE */}
        <div className="nav-query">
          <div className="nav-query-label">ACTIVE QUERY</div>
          <div className="nav-query-row">
            <span className="dot-origin" />
            <div style={{ flex: 1 }}>
              <small>DEPARTURE</small>
              <strong>{departureLabel}</strong>
            </div>
          </div>
          <form className="nav-search-form" onSubmit={handleOriginSubmit}>
            <input
              value={originInput}
              onChange={(e) => setOriginInput(e.target.value)}
              placeholder="From? e.g. Empangeni"
              aria-label="Departure"
            />
            <button type="submit" className="nav-search-btn">
              Set
            </button>
          </form>
          <button type="button" className="nav-gps-btn" onClick={handleUseGps}>
            📍 Use my GPS location
          </button>
          {geo.status === 'locating' && (
            <p className="nav-error" style={{ color: '#8b9bb8' }}>
              Locating…
            </p>
          )}
          {geo.error && <p className="nav-error">{geo.error}</p>}

          <div className="nav-query-row" style={{ marginTop: 12 }}>
            <span className="dot-dest" />
            <div>
              <small>DESTINATION</small>
              <strong>{destination?.name || '—'}</strong>
            </div>
          </div>
          <form className="nav-search-form" onSubmit={handleManualSearch}>
            <input
              value={destInput}
              onChange={(e) => setDestInput(e.target.value)}
              placeholder="Where to? e.g. Ongoye"
              aria-label="Destination"
            />
            <button type="submit" className="nav-search-btn">
              Go
            </button>
          </form>
        </div>

        {/* FREQUENT RIDES */}
        <div className="nav-frequent">
          <div className="nav-query-label">FREQUENT RIDES</div>
          {FREQUENT_RIDES.map((ride) => (
            <button
              key={ride.id}
              type="button"
              className="nav-frequent-row"
              onClick={() => handleFrequent(ride)}
            >
              <span>★ {ride.label}</span>
              <span>{ride.fareHint}</span>
            </button>
          ))}
        </div>

        {/* VERIFY TRIP */}
        <div className="nav-query" style={{ marginTop: 8 }}>
          <div className="nav-query-label">VERIFY TRIP</div>
          <form
            className="nav-search-form"
            onSubmit={(e) => {
              e.preventDefault();
              verifyTripCode();
            }}
          >
            <input
              value={verificationCode}
              onChange={(e) => setVerificationCode(e.target.value)}
              placeholder="Code e.g. TH-EMP-002"
              aria-label="Verification code"
            />
            <button type="submit" className="nav-search-btn">
              Verify
            </button>
          </form>
          {activeTrip && (
            <div className="nav-verified-trip">
              <strong>{activeTrip.route}</strong>
              <small>
                {activeTrip.id} · {activeTrip.status} · {activeTrip.departure}
              </small>
              <small>
                {activeTrip.driver} · {activeTrip.vehicle}
              </small>
            </div>
          )}
        </div>

        {/* PANIC */}
        <div className="nav-sidebar-actions">
          <button
            type="button"
            className={`nav-panic-btn ${panicArmed ? 'armed' : ''}`}
            onClick={triggerPanic}
          >
            🚨 Panic alert
          </button>
        </div>

        <div className="nav-sidebar-foot">
          <button type="button" className="text-button" onClick={onClose}>
            Close panel
          </button>
          <small>THEMBA Transport © 2026</small>
        </div>
      </aside>

      <main className="nav-panel-main">
        <header className="nav-map-chrome">
          <button type="button" className="nav-back" onClick={onClose} aria-label="Back">
            ←
          </button>
          <div className="nav-route-title">
            <small>HI, {passengerName.split(' ')[0].toUpperCase()}</small>
            <strong>{routeTitle}</strong>
          </div>
          {(selectedRoute || calculated || activeTrip) && (
            <span className="nav-live-badge">● LIVE ROUTE</span>
          )}
        </header>

        <div className="nav-map-stage">
          <GoogleTransportMap
            origin={origin ? { ...origin, label: departureLabel } : null}
            destination={
              destination
                ? { ...destination, label: destination.name || 'Destination' }
                : null
            }
            routeGeometry={
              calculated?.geometry?.length > 2 ? calculated.geometry : []
            }
            secondaryRouteGeometry={
              (legToRank?.length > 2
                ? legToRank
                : calculated?.legToRank?.length > 2
                  ? calculated.legToRank
                  : [])
            }
            height="100%"
            initialCenter={[31.95, -28.8]}
            initialZoom={10}
          />
        </div>

        {error && <div className="nav-toast error">{error}</div>}
        {panicArmed && (
          <div className="nav-toast error" style={{ bottom: 200 }}>
            🚨 Emergency alert armed — help is being notified for this trip.
          </div>
        )}

        {step === 'results' && (
          <div className="nav-results-bar">
            {loading && <span>Searching routes…</span>}
            {!loading && (
              <>
                <span>
                  {routeOptions.length} predetermined ·{' '}
                  {calcLoading
                    ? 'routing via rank…'
                    : calculated
                      ? `ORS: ${calculated.viaRank || departureLabel} → ${destination?.name || 'dest'}`
                      : 'no route yet'}
                </span>
                <button
                  type="button"
                  className="nav-primary"
                  onClick={openBooking}
                  disabled={!selectedRoute && !calculated}
                >
                  Review booking
                </button>
              </>
            )}
            {routeOptions.length > 0 && (
              <div className="nav-option-chips">
                {routeOptions.map((opt) => (
                  <button
                    key={opt.route_id}
                    type="button"
                    className={opt.route_id === selectedRouteId ? 'chip active' : 'chip'}
                    onClick={() => setSelectedRouteId(opt.route_id)}
                  >
                    {opt.route_name} · R{Number(opt.fare).toFixed(0)}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {(step === 'booking' || step === 'confirmed') && (
          <div className="nav-booking-card">
            <div className="nav-booking-head">
              <div>
                <h3>
                  {step === 'confirmed' ? 'Booking confirmed' : 'Confirm Route Booking'}
                </h3>
                <p>THEMBA Smart Shuttle</p>
              </div>
              <div className="nav-fare">
                <strong>{fareDisplay}</strong>
                <small>Est. Cash Fare</small>
              </div>
            </div>

            <div className="nav-booking-meta">
              <div>
                <small>ROUTE ID</small>
                <strong>
                  {selectedRoute?.route_code || selectedRoute?.route_id || 'ADHOC'}
                </strong>
              </div>
              <div>
                <small>DURATION</small>
                <strong>
                  {selectedRoute
                    ? `${Math.round(selectedRoute.duration_min)} min`
                    : calculated
                      ? `${Math.round(calculated.durationMin)} min`
                      : '—'}
                </strong>
              </div>
              <div>
                <small>TRANSIT</small>
                <strong>Direct Transit</strong>
              </div>
            </div>

            <div className="nav-service">
              <div className="nav-service-row">
                <span>🚐</span>
                <div>
                  <strong>
                    {selectedRoute?.route_name || 'Calculated route'}
                  </strong>
                  <small>
                    {selectedRoute
                      ? `${selectedRoute.distance_km} km · ${selectedRoute.vehicle_class || 'Minibus'}`
                      : calculated
                        ? `${calculated.distanceKm} km · ${(calculated.source || 'ors').toUpperCase()} routing`
                        : ''}
                  </small>
                </div>
              </div>
            </div>

            {step === 'booking' && (
              <button type="button" className="nav-confirm" onClick={confirmBooking}>
                Confirm Booking (
                {selectedRoute?.route_code || selectedRoute?.route_id || 'ADHOC'}) →
              </button>
            )}
            {step === 'confirmed' && (
              <button
                type="button"
                className="nav-confirm secondary"
                onClick={() => setStep('idle')}
              >
                Plan another trip
              </button>
            )}
            {step === 'booking' && (
              <button
                type="button"
                className="text-button nav-cancel"
                onClick={() => setStep('results')}
              >
                Back to results
              </button>
            )}
          </div>
        )}

        {step === 'verified' && activeTrip && (
          <div className="nav-booking-card">
            <div className="nav-booking-head">
              <div>
                <h3>Verified trip</h3>
                <p>{activeTrip.status}</p>
              </div>
              <div className="nav-fare">
                <strong>{activeTrip.fare}</strong>
                <small>Fare</small>
              </div>
            </div>
            <div className="nav-booking-meta">
              <div>
                <small>ROUTE</small>
                <strong>{activeTrip.id}</strong>
              </div>
              <div>
                <small>DEPARTURE</small>
                <strong>{activeTrip.departure}</strong>
              </div>
              <div>
                <small>ETA</small>
                <strong>{activeTrip.eta}</strong>
              </div>
            </div>
            <div className="nav-service">
              <div className="nav-service-row">
                <span>🚐</span>
                <div>
                  <strong>{activeTrip.route}</strong>
                  <small>
                    {activeTrip.driver} · {activeTrip.vehicle}
                  </small>
                </div>
              </div>
            </div>
            <button type="button" className="nav-panic-btn full" onClick={triggerPanic}>
              🚨 Panic alert
            </button>
            <button
              type="button"
              className="nav-confirm secondary"
              onClick={() => {
                setStep('idle');
                notify?.('Feedback form opened for the completed trip.');
              }}
            >
              Give feedback
            </button>
          </div>
        )}
      </main>
    </div>
  );
}

export default PassengerNavigationPanel;
