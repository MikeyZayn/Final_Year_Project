import { useEffect, useRef, useState } from 'react';
import { loadGoogleMaps } from '../services/googleMapsLoader';

/**
 * Google Maps JavaScript API map. Same prop contract as the previous map
 * component, so RouteSearchScreen, RouteSelectionScreen, RoutingFlow and
 * LiveTrackingPanel only needed an import swap, not a rewrite
 * (THEMBA_SPEC §10/§34 - reuse, don't rewrite).
 *
 * Props:
 *  - origin / destination: { lat, lng, label? } -> pin markers
 *  - routeGeometry: [[lat, lng], ...] -> the PREDETERMINED THEMBA route line
 *  - secondaryRouteGeometry: [[lat, lng], ...] -> the Google-CALCULATED
 *      ad-hoc route line (drawn dashed, in a different colour, so the two
 *      are never visually confused - THEMBA_SPEC §12)
 *  - vehicles: [{ id, lat, lng, heading, label, color }] -> live tracking dots
 *  - onMapClick({ lat, lng }) -> used by "Choose on map"
 *  - height (css value)
 *
 * The map itself is created exactly once (THEMBA_SPEC §8: "Do not recreate
 * the Google Map every time GPS data changes"); every prop change after
 * that only updates markers/polylines already on the map.
 */
function GoogleTransportMap({
  origin,
  destination,
  routeGeometry,
  secondaryRouteGeometry,
  vehicles = [],
  onMapClick,
  height = '320px',
  initialCenter = [31.8925, -28.7808], // [lng, lat] - Richards Bay, KZN
  initialZoom = 12,
}) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const originMarkerRef = useRef(null);
  const destinationMarkerRef = useRef(null);
  const vehicleMarkersRef = useRef({});
  const routeLineRef = useRef(null);
  const secondaryLineRef = useRef(null);
  const clickListenerRef = useRef(null);

  const [status, setStatus] = useState('loading'); // 'loading' | 'ready' | 'error'
  const [loadError, setLoadError] = useState('');

  // Load the Google Maps script and create the map exactly once.
  useEffect(() => {
    let cancelled = false;

    loadGoogleMaps()
      .then((maps) => {
        if (cancelled || !containerRef.current || mapRef.current) return;

        const map = new maps.Map(containerRef.current, {
          center: { lat: initialCenter[1], lng: initialCenter[0] },
          zoom: initialZoom,
          mapTypeControl: false,
          streetViewControl: false,
          fullscreenControl: false,
        });

        mapRef.current = map;
        setStatus('ready');
      })
      .catch((err) => {
        if (cancelled) return;
        setLoadError(err.message);
        setStatus('error');
      });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Click-to-choose-destination support.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || status !== 'ready') return undefined;

    if (clickListenerRef.current) {
      clickListenerRef.current.remove();
      clickListenerRef.current = null;
    }
    if (onMapClick) {
      clickListenerRef.current = map.addListener('click', (event) => {
        onMapClick({ lat: event.latLng.lat(), lng: event.latLng.lng() });
      });
    }
    return () => clickListenerRef.current?.remove();
  }, [onMapClick, status]);

  // Origin marker.
  useEffect(() => {
    if (status !== 'ready') return;
    const maps = window.google.maps;
    const map = mapRef.current;

    originMarkerRef.current?.setMap(null);
    originMarkerRef.current = null;

    if (origin) {
      originMarkerRef.current = new maps.Marker({
        map,
        position: { lat: origin.lat, lng: origin.lng },
        title: origin.label || 'Your location',
        icon: {
          path: maps.SymbolPath.CIRCLE,
          scale: 8,
          fillColor: '#3169e6',
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 2,
        },
      });
    }
  }, [origin, status]);

  // Destination marker.
  useEffect(() => {
    if (status !== 'ready') return;
    const maps = window.google.maps;
    const map = mapRef.current;

    destinationMarkerRef.current?.setMap(null);
    destinationMarkerRef.current = null;

    if (destination) {
      destinationMarkerRef.current = new maps.Marker({
        map,
        position: { lat: destination.lat, lng: destination.lng },
        title: destination.label || 'Destination',
        icon: {
          path: maps.SymbolPath.CIRCLE,
          scale: 8,
          fillColor: '#d16148',
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 2,
        },
      });
    }
  }, [destination, status]);

  // Predetermined route line + calculated route line + auto-fit bounds.
  useEffect(() => {
    if (status !== 'ready') return;
    const maps = window.google.maps;
    const map = mapRef.current;

    routeLineRef.current?.setMap(null);
    secondaryLineRef.current?.setMap(null);
    routeLineRef.current = null;
    secondaryLineRef.current = null;

    const toLatLng = ([lat, lng]) => ({ lat, lng });
    const bounds = new maps.LatLngBounds();
    let hasPoints = false;

    // ONLY OpenRouteService paths (length > 2). Never draw blue predetermined / straight lines.
    // primary = rank → destination (solid cyan); secondary = GPS → rank (dashed cyan).
    const usablePrimary =
      Array.isArray(routeGeometry) && routeGeometry.length > 2 ? routeGeometry : null;
    const usableSecondary =
      Array.isArray(secondaryRouteGeometry) && secondaryRouteGeometry.length > 2
        ? secondaryRouteGeometry
        : null;

    if (usablePrimary) {
      routeLineRef.current = new maps.Polyline({
        map,
        path: usablePrimary.map(toLatLng),
        strokeColor: '#2dd4bf',
        strokeOpacity: 0.95,
        strokeWeight: 5,
      });
      usablePrimary.forEach((point) => {
        bounds.extend(toLatLng(point));
        hasPoints = true;
      });
    }

    if (usableSecondary) {
      secondaryLineRef.current = new maps.Polyline({
        map,
        path: usableSecondary.map(toLatLng),
        strokeOpacity: 0,
        strokeWeight: 4,
        icons: [
          {
            icon: { path: 'M 0,-1 0,1', strokeOpacity: 1, strokeColor: '#5eead4', scale: 3 },
            offset: '0',
            repeat: '12px',
          },
        ],
      });
      usableSecondary.forEach((point) => {
        bounds.extend(toLatLng(point));
        hasPoints = true;
      });
    }

    if (origin) {
      bounds.extend({ lat: origin.lat, lng: origin.lng });
      hasPoints = true;
    }
    if (destination) {
      bounds.extend({ lat: destination.lat, lng: destination.lng });
      hasPoints = true;
    }

    if (hasPoints) {
      const isPoint = bounds.getNorthEast().equals(bounds.getSouthWest());
      if (isPoint) {
        map.setCenter(bounds.getCenter());
        map.setZoom(14);
      } else {
        map.fitBounds(bounds, 60);
      }
    }
  }, [routeGeometry, secondaryRouteGeometry, origin, destination, status]);

  // Live vehicle markers (taxi dots) - updated in place, never recreated.
  useEffect(() => {
    if (status !== 'ready') return;
    const maps = window.google.maps;
    const map = mapRef.current;
    const seenIds = new Set();

    vehicles.forEach((vehicle) => {
      seenIds.add(String(vehicle.id));
      const position = { lat: vehicle.lat, lng: vehicle.lng };

      if (vehicleMarkersRef.current[vehicle.id]) {
        const marker = vehicleMarkersRef.current[vehicle.id];
        marker.setPosition(position);
        marker.setIcon({
          ...marker.getIcon(),
          rotation: vehicle.heading || 0,
          fillColor: vehicle.color || '#e6a841',
        });
        marker.setTitle(vehicle.label || 'Taxi');
      } else {
        const marker = new maps.Marker({
          map,
          position,
          title: vehicle.label || 'Taxi',
          icon: {
            path: maps.SymbolPath.FORWARD_CLOSED_ARROW,
            scale: 5,
            rotation: vehicle.heading || 0,
            fillColor: vehicle.color || '#e6a841',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 1.5,
          },
        });
        vehicleMarkersRef.current[vehicle.id] = marker;
      }
    });

    Object.keys(vehicleMarkersRef.current).forEach((id) => {
      if (!seenIds.has(id)) {
        vehicleMarkersRef.current[id].setMap(null);
        delete vehicleMarkersRef.current[id];
      }
    });
  }, [vehicles, status]);

  if (status === 'error') {
    return (
      <div className="themba-map themba-map-error" style={{ height }}>
        <p>
          <strong>Google Maps is unavailable.</strong>
        </p>
        <p className="muted small">{loadError}</p>
      </div>
    );
  }

  return (
    <div className="themba-map-wrapper" style={{ height, position: 'relative' }}>
      {status === 'loading' && <div className="themba-map-loading">Loading map…</div>}
      <div ref={containerRef} className="themba-map" style={{ height }} />
    </div>
  );
}

export default GoogleTransportMap;
