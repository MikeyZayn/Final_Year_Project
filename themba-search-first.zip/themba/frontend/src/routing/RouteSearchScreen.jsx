import { useEffect, useRef, useState } from 'react';
import GoogleTransportMap from './GoogleTransportMap';
import useGeolocation from '../hooks/useGeolocation';
import { loadGoogleMaps, hasGoogleMapsKey } from '../services/googleMapsLoader';

const RECENT_PLACEHOLDERS = [
  { name: 'Harbor Science Museum', hint: 'Recently viewed · 18 Harbor Walk', minutesAway: 12 },
  { name: 'Juniper Market Hall', hint: "Saved place · 44 Juniper Street", minutesAway: 8 },
  { name: 'Riverside Reading Room', hint: 'Open until 9 PM · River Lane', minutesAway: 16 },
];

/**
 * "Where are you going?" screen. Destination search is Google Places
 * Autocomplete (THEMBA_SPEC §15) attached directly to the text input -
 * Google renders its own predictions dropdown, so this component just
 * reads back whichever place the passenger picks. "Choose on map" and the
 * live-location start point (THEMBA_SPEC §16A) are unchanged.
 */
function RouteSearchScreen({ onDestinationChosen }) {
  const [query, setQuery] = useState('');
  const [pickOnMap, setPickOnMap] = useState(false);
  const [mapCenterHint, setMapCenterHint] = useState(null);
  const [placesReady, setPlacesReady] = useState(false);
  const [placesError, setPlacesError] = useState('');
  const inputRef = useRef(null);
  const autocompleteRef = useRef(null);

  const { position, error, status: gpsStatus, requestOnce } = useGeolocation();
  const loading = gpsStatus === 'locating';

  useEffect(() => {
    requestOnce();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Attach Google Places Autocomplete to the search input once the Maps
  // script has loaded (and once, not on every render - a stray effect
  // re-running this would silently create duplicate listeners).
  useEffect(() => {
    if (!hasGoogleMapsKey()) {
      setPlacesError('Google Maps is not configured, so destination search is unavailable. Use "Choose on map" instead.');
      return;
    }

    let cancelled = false;
    loadGoogleMaps()
      .then((maps) => {
        if (cancelled || !inputRef.current || autocompleteRef.current) return;

        const autocomplete = new maps.places.Autocomplete(inputRef.current, {
          fields: ['geometry', 'name', 'place_id', 'formatted_address'],
        });

        if (position) {
          const circle = new maps.Circle({
            center: { lat: position.lat, lng: position.lng },
            radius: 20000,
          });
          autocomplete.setBounds(circle.getBounds());
        }

        autocomplete.addListener('place_changed', () => {
          const place = autocomplete.getPlace();
          const location = place.geometry?.location;
          if (!location) {
            // Passenger pressed Enter without picking a suggestion from the
            // dropdown - Google has nothing to resolve to coordinates yet.
            return;
          }
          chooseDestination({
            lat: location.lat(),
            lng: location.lng(),
            name: place.name || place.formatted_address || query,
            placeId: place.place_id,
          });
        });

        autocompleteRef.current = autocomplete;
        setPlacesReady(true);
      })
      .catch((err) => setPlacesError(err.message));

    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [position]);

  function chooseDestination(destination) {
    onDestinationChosen({ origin: position, destination });
  }

  return (
    <div className="route-search-screen">
      <div className="route-search-map">
        <GoogleTransportMap
          origin={position ? { ...position, label: 'Your location' } : null}
          destination={mapCenterHint}
          onMapClick={pickOnMap ? (point) => setMapCenterHint(point) : undefined}
          height="260px"
        />
        {pickOnMap && (
          <div className="map-pick-banner">
            <span>Tap the map to drop a pin at your destination</span>
            <button
              type="button"
              className="primary-button"
              disabled={!mapCenterHint}
              onClick={() =>
                chooseDestination({ ...mapCenterHint, name: 'Chosen location' })
              }
            >
              Use this location
            </button>
          </div>
        )}
      </div>

      <div className="search-panel">
        <label className="search-box">
          <span aria-hidden>🧭</span>
          <input
            ref={inputRef}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Where are you going?"
          />
        </label>

        {loading && <p className="muted small">Finding your location…</p>}
        {error && <p className="muted small">{error} You can still search or choose on the map.</p>}
        {placesError && <p className="muted small">{placesError}</p>}
        {hasGoogleMapsKey() && !placesReady && !placesError && (
          <p className="muted small">Loading destination search…</p>
        )}

        <div className="pick-destination-header">
          <span>Pick a destination</span>
          <button className="text-button" type="button" onClick={() => setPickOnMap((v) => !v)}>
            {pickOnMap ? 'Cancel' : 'Choose on map'}
          </button>
        </div>

        <div className="destination-list">
          <p className="muted small">
            Start typing above and choose an address from Google's suggestions, or use "Choose on
            map".
          </p>

          {query.trim().length < 3 &&
            RECENT_PLACEHOLDERS.map((place) => (
              <button
                key={place.name}
                className="destination-row"
                type="button"
                onClick={() =>
                  chooseDestination({
                    name: place.name,
                    lat: position ? position.lat + (Math.random() - 0.5) * 0.01 : -28.77,
                    lng: position ? position.lng + (Math.random() - 0.5) * 0.01 : 32.048,
                  })
                }
              >
                <span aria-hidden>🕐</span>
                <span>
                  <strong>{place.name}</strong>
                  <small>{place.hint}</small>
                </span>
                <b className="eta-chip">{place.minutesAway} min</b>
              </button>
            ))}
        </div>
      </div>
    </div>
  );
}

export default RouteSearchScreen;
