/**
 * Ad-hoc road routing for THEMBA — OpenRouteService (HeiGIT) only.
 *
 * Geometry, distance and duration come from Django:
 *   POST /api/routing/directions/
 * which tries ORS → OSRM → straight-line fallback.
 *
 * Google Maps is NOT used for routing. The Google Maps JavaScript API is still
 * used elsewhere for the interactive map (tiles, markers) only.
 *
 * Do NOT call this on every GPS update — only when origin/destination change.
 */
import thembaApi from '../api/themba';

/**
 * origin/destination: { lat, lng }
 *
 * Returns:
 *   {
 *     geometry: [[lat, lng], ...],
 *     distanceKm: 14.2,
 *     durationMin: 28,
 *     trafficAware: false,
 *     source: 'ors' | 'osrm' | 'fallback',
 *     alternatives: [],
 *   }
 */
export async function computeRoute(origin, destination) {
  const lat0 = Number(origin?.lat);
  const lng0 = Number(origin?.lng);
  const lat1 = Number(destination?.lat);
  const lng1 = Number(destination?.lng);

  if (![lat0, lng0, lat1, lng1].every((n) => Number.isFinite(n))) {
    throw new Error(
      'Origin and destination must both have valid latitude and longitude numbers.'
    );
  }

  try {
    const data = await thembaApi.getAdHocDirections({
      origin: { lat: lat0, lng: lng0 },
      destination: { lat: lat1, lng: lng1 },
    });

    const geometry = Array.isArray(data.geometry) ? data.geometry : [];
    if (geometry.length < 2) {
      throw new Error(
        'Routing service returned no usable path between these two points.'
      );
    }

    return {
      geometry,
      distanceKm: Number(data.distance_km) || 0,
      durationMin: Number(data.duration_min) || 0,
      trafficAware: false,
      source: data.source || 'ors',
      alternatives: [],
    };
  } catch (err) {
    throw new Error(routingErrorMessage(err));
  }
}

/** @deprecated Use computeRoute — Google Routes is disabled. */
export async function computeGoogleRoute(origin, destination) {
  return computeRoute(origin, destination);
}

/** @deprecated Use computeRoute — single HeiGIT/ORS path only. */
export async function computeOrsRoute(origin, destination) {
  return computeRoute(origin, destination);
}

/** @deprecated Use computeRoute. */
export async function computeRouteWithFallback(origin, destination) {
  return computeRoute(origin, destination);
}

function routingErrorMessage(err) {
  const raw = err?.message || String(err);
  if (/ORS_API_KEY|API key|401|403|rejected/i.test(raw)) {
    return (
      'OpenRouteService rejected the request. Set ORS_API_KEY in backend/.env ' +
      '(https://openrouteservice.org/dev/#/signup) and restart Django.'
    );
  }
  if (/429|quota|rate/i.test(raw)) {
    return 'Routing quota reached. Try again shortly.';
  }
  if (/Cannot reach the THEMBA backend/i.test(raw)) {
    return raw;
  }
  return `Routing unavailable right now (${raw}).`;
}

export default computeRoute;
