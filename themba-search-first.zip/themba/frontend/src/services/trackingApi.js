// Live-tracking helpers that don't need a network call. The authoritative
// ON ROUTE / OFF ROUTE decision is always made server-side (Django,
// core/services/deviation.py) and delivered over the WebSocket/REST
// payload - this file only estimates an ETA for display, which the backend
// does not currently compute.

const EARTH_RADIUS_KM = 6371;

function haversineKm(lat1, lng1, lat2, lng2) {
  const toRad = (deg) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return EARTH_RADIUS_KM * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/**
 * Straight-line ETA estimate from a vehicle's current position to its
 * route's destination, used by the Operator/Administrator tracking screens
 * (THEMBA_SPEC §25/§26). Deliberately approximate and labelled as such in
 * the UI - it is NOT Google's traffic-aware duration (that only exists for
 * the passenger's own planned trip, computed once via routingApi.js), and
 * it is a straight line, not the remaining distance along the road.
 *
 * Returns null when there isn't enough information to estimate anything,
 * so the UI can show "ETA unavailable" instead of a fabricated number.
 */
export function estimateEtaMinutes(vehicleLocation, route) {
  if (!vehicleLocation || !route) return null;
  const { lat, lng, speed_kmh: speedKmh } = vehicleLocation;
  if (lat == null || lng == null) return null;

  const destLat = route.destination_lat ?? route.destinationLat;
  const destLng = route.destination_lng ?? route.destinationLng;
  if (destLat == null || destLng == null) return null;

  const remainingKm = haversineKm(lat, lng, destLat, destLng);
  const speed = speedKmh && speedKmh > 3 ? speedKmh : route.average_speed_kmh || route.averageSpeedKmh;
  if (!speed || speed <= 0) return null;

  return Math.round((remainingKm / speed) * 60);
}

export { haversineKm };

export default estimateEtaMinutes;
