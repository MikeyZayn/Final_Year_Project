// Re-exports the existing THEMBA REST client (src/api/themba.js) under
// src/services/, matching the services/ layout other routing/tracking code
// expects to find api.js alongside. The client itself lives in one place
// (src/api/themba.js) rather than being duplicated here - see that file
// for the actual request logic, auth token handling, etc.
export { default, getAuth, setAuth, clearAuth, getStoredAuth, setStoredAuth, trackingSocketUrl } from '../api/themba';
