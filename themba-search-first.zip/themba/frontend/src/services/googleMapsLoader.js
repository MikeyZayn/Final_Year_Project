// Loads the Google Maps JavaScript API exactly once, however many
// components ask for it. No npm package is used for this (Google's own
// quick-start docs load it as a plain <script> tag) - it keeps the
// dependency list small and matches THEMBA_SPEC §34 (avoid unnecessary
// dependencies).
//
// Libraries requested:
//   places  - destination search (THEMBA_SPEC §15)
//   (Routes library not used for THEMBA ad-hoc routing — that uses OpenRouteService)
//             (THEMBA_SPEC §9/§10), loaded via google.maps.importLibrary
//   geometry - decodes the encoded polyline Routes returns, and is used
//             for the driver route-deviation check on the client side.

const API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

// How long to wait for either the success callback or gm_authFailure before
// giving up and showing an error instead of leaving the map stuck on
// "Loading map..." forever. Google doesn't always call either one (e.g. some
// network-blocking browser extensions swallow the request silently).
const LOAD_TIMEOUT_MS = 12000;

let loadPromise = null;

/**
 * Resolves with the `google.maps` namespace once the script has loaded.
 * Rejects (with a readable, actionable message) if no API key is
 * configured, the script fails to load, it times out, or - critically -
 * Google's own authentication check fails (bad key, referrer not allowed,
 * billing not enabled, required API not enabled). That last case is the
 * "This page can't load Google Maps correctly" dialog Google shows on top
 * of the page: the <script> tag itself loads fine (script.onerror never
 * fires), so without handling this separately the app would just hang on
 * "Loading map..." forever with no explanation. Google calls the global
 * `window.gm_authFailure` callback specifically for this case if it's
 * defined, so that's what we hook into here.
 *
 * Callers should catch this and show GoogleMapsUnavailable-style UI rather
 * than letting the map silently stay blank (THEMBA_SPEC §32).
 */
export function loadGoogleMaps() {
  if (loadPromise) return loadPromise;

  loadPromise = new Promise((resolve, reject) => {
    if (!API_KEY) {
      reject(
        new Error(
          'Google Maps is not configured. Set VITE_GOOGLE_MAPS_API_KEY in frontend/.env, then restart `npm run dev`.'
        )
      );
      return;
    }

    if (window.google?.maps) {
      resolve(window.google.maps);
      return;
    }

    let settled = false;
    const settleResolve = (value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeoutId);
      resolve(value);
    };
    const settleReject = (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeoutId);
      reject(err);
    };

    // Google calls this specifically when the script loaded but
    // authentication failed - the exact cause of the "This page can't load
    // Google Maps correctly" / "Do you own this website?" dialog. It never
    // fires for a plain network failure (that's script.onerror below).
    window.gm_authFailure = () => {
      settleReject(
        new Error(
          'Google rejected this page\u2019s API key. Open the browser console for the exact reason ' +
            '(RefererNotAllowedMapError, BillingNotEnabledMapError, ApiNotActivatedMapError, or ' +
            'InvalidKeyMapError), then fix it in Google Cloud Console: add this page\u2019s exact origin ' +
            'under the key\u2019s Website restrictions, confirm billing is enabled on the same project ' +
            'the key belongs to, and confirm Maps JavaScript API, Places API and Routes API are all enabled.'
        )
      );
    };

    const timeoutId = setTimeout(() => {
      settleReject(
        new Error(
          'Google Maps did not respond in time. This can mean a network/firewall issue, an ad blocker ' +
            'blocking maps.googleapis.com, or - if this keeps happening - an API key problem that ' +
            'Google failed to report back (check the browser console for errors).'
        )
      );
    }, LOAD_TIMEOUT_MS);

    const existing = document.getElementById('themba-google-maps-script');
    if (existing) {
      existing.addEventListener('load', () => settleResolve(window.google.maps));
      existing.addEventListener('error', () =>
        settleReject(new Error('Google Maps failed to load. Check your network connection and API key.'))
      );
      return;
    }

    window.__thembaGoogleMapsReady = () => settleResolve(window.google.maps);

    const script = document.createElement('script');
    script.id = 'themba-google-maps-script';
    script.async = true;
    script.src =
      `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(API_KEY)}` +
      '&libraries=places,geometry&v=weekly&loading=async' +
      '&callback=__thembaGoogleMapsReady';
    script.onerror = () =>
      settleReject(
        new Error(
          'Google Maps failed to load. Check your internet connection, VITE_GOOGLE_MAPS_API_KEY, and that the key allows this domain in Google Cloud Console.'
        )
      );
    document.head.appendChild(script);
  });

  return loadPromise;
}

/** True once VITE_GOOGLE_MAPS_API_KEY has *something* set (not a validity check). */
export function hasGoogleMapsKey() {
  return Boolean(API_KEY);
}

export default loadGoogleMaps;
