import { useEffect, useRef, useState } from 'react';
import GoogleTransportMap from '../routing/GoogleTransportMap';
import GPSStatus from '../routing/GPSStatus';
import LoginGate from '../routing/LoginGate';
import useAuth from '../hooks/useAuth';
import useGeolocation from '../hooks/useGeolocation';
import thembaApi from '../api/themba';

// How often the driver device pushes a GPS ping to Django while a trip is
// active. Frequent enough for operators/administrators to see near-live
// movement, far from "every GPS callback" - watchPosition can fire much
// more often than this, but only the latest reading is sent on each tick
// (THEMBA_SPEC §30/§22).
const PUSH_INTERVAL_MS = 7000;

/**
 * Driver "Start trip" screen (THEMBA_SPEC Driver requirements + Objective).
 * Covers: start trip, use live GPS, view assigned predetermined route,
 * destination, distance/ETA, speed, GPS accuracy, send live location to
 * Django, and the resulting ON ROUTE / OFF ROUTE status.
 *
 * NOTE on "select predetermined route": THEMBA's backend ties a Vehicle to
 * one Route via Vehicle.route (assigned by an operator/administrator), and
 * that is the route the server's ON ROUTE/OFF ROUTE deviation check
 * compares GPS pings against (core/services/deviation.py). This screen
 * shows that assigned route and lets the driver preview any other active
 * predetermined route's distance/time, but changing which route counts as
 * "assigned" is an operator/administrator action, not a driver one - see
 * the implementation report for why this is PARTIALLY, not FULLY,
 * implemented against §Driver/"Select predetermined route".
 */
function DriverTripPanel({ notify }) {
  const { auth, login, logout, loading: loggingIn, error: loginError } = useAuth();
  const isDriver = auth?.role === 'driver';

  const [vehicle, setVehicle] = useState(null);
  const [vehicleError, setVehicleError] = useState('');
  const [loadingVehicle, setLoadingVehicle] = useState(false);
  const [assignedRouteDetail, setAssignedRouteDetail] = useState(null); // full Route (lat/lng/geometry) - vehicle.route is a lightweight summary only

  const [previewRoutes, setPreviewRoutes] = useState([]);
  const [previewRouteId, setPreviewRouteId] = useState('');

  const [tripActive, setTripActive] = useState(false);
  const [lastPing, setLastPing] = useState(null); // last successful push response (incl. route_status)
  const [pushError, setPushError] = useState('');

  const { position, error: gpsError, status: gpsStatus, startWatching, stopWatching } = useGeolocation({
    watch: tripActive,
  });
  const positionRef = useRef(null);
  const pushTimerRef = useRef(null);

  useEffect(() => {
    positionRef.current = position;
  }, [position]);

  // Load the driver's assigned vehicle once signed in.
  useEffect(() => {
    if (!isDriver) return;
    setLoadingVehicle(true);
    thembaApi
      .getMyVehicle()
      .then((data) => {
        setVehicle(data);
        setVehicleError('');
      })
      .catch((err) => setVehicleError(err.message))
      .finally(() => setLoadingVehicle(false));
  }, [isDriver]);

  // vehicle.route is a lightweight summary (no coordinates/geometry) - fetch
  // the full Route separately so the map can actually place the
  // destination marker and draw the assigned route's line.
  useEffect(() => {
    if (!vehicle?.route?.id) {
      setAssignedRouteDetail(null);
      return;
    }
    thembaApi
      .getRoute(vehicle.route.id)
      .then(setAssignedRouteDetail)
      .catch(() => setAssignedRouteDetail(null));
  }, [vehicle]);

  // Route preview list (any active predetermined route, for reference only).
  useEffect(() => {
    if (!isDriver) return;
    thembaApi
      .listRoutes()
      .then((data) => setPreviewRoutes(data.results || data || []))
      .catch(() => setPreviewRoutes([]));
  }, [isDriver]);

  // Push the latest GPS reading to Django every PUSH_INTERVAL_MS while the
  // trip is active. Uses a plain interval reading a ref (not the position
  // state directly) so push frequency is decoupled from how often the
  // browser's watchPosition callback fires.
  useEffect(() => {
    if (!tripActive || !vehicle) return undefined;

    async function pushOnce() {
      const current = positionRef.current;
      if (!current) return; // no GPS fix yet this tick
      try {
        const response = await thembaApi.pushVehicleLocation(vehicle.id, {
          lat: current.lat,
          lng: current.lng,
          speed_kmh: current.speedKmh,
          heading_deg: current.headingDeg || 0,
          accuracy_m: current.accuracyM,
        });
        setLastPing(response);
        setPushError('');
      } catch (err) {
        setPushError(err.message);
      }
    }

    pushOnce();
    pushTimerRef.current = setInterval(pushOnce, PUSH_INTERVAL_MS);
    return () => clearInterval(pushTimerRef.current);
  }, [tripActive, vehicle]);

  function startTrip() {
    if (!vehicle) return;
    setTripActive(true);
    startWatching();
    notify?.('Trip started. Sending live location to THEMBA.');
  }

  function stopTrip() {
    setTripActive(false);
    stopWatching();
    if (pushTimerRef.current) clearInterval(pushTimerRef.current);
    notify?.('Trip stopped.');
  }

  if (!isDriver) {
    return (
      <LoginGate
        title="Driver sign-in"
        hint='Starting a trip and sending live GPS requires a driver account. Demo account: driver_demo, password "themba123".'
        onLogin={login}
        loading={loggingIn}
        error={loginError}
      />
    );
  }

  const previewRoute = previewRoutes.find((r) => String(r.id) === String(previewRouteId));
  const assignedRoute = vehicle?.route;
  const routeStatus = lastPing?.route_status;

  return (
    <div className="driver-trip-panel">
      <div className="tracking-connection-row">
        <span className="muted small">Signed in as {auth.username} (driver)</span>
        <button className="text-button" type="button" onClick={logout}>
          Sign out
        </button>
      </div>

      {loadingVehicle && <p className="muted small">Loading your assigned vehicle…</p>}
      {vehicleError && <p className="muted small">{vehicleError}</p>}

      {vehicle && (
        <div className="driver-vehicle-card">
          <strong>
            {vehicle.registration} · {vehicle.make} {vehicle.model}
          </strong>
          <p className="muted small">
            Assigned route: {assignedRoute ? `${assignedRoute.name} → ${assignedRoute.destination_name}` : 'None assigned'}
          </p>

          {!assignedRoute && (
            <p className="muted small">
              No route is assigned to your vehicle yet - ask an operator/administrator to assign
              one before starting a trip, so ON ROUTE/OFF ROUTE tracking has something to compare
              against.
            </p>
          )}

          <div className="driver-trip-setup">
            <label>
              Preview a predetermined route (reference only - does not change your assignment)
              <select
                className="driver-route-select"
                value={previewRouteId}
                onChange={(event) => setPreviewRouteId(event.target.value)}
              >
                <option value="">Select a route to preview…</option>
                {previewRoutes.map((route) => (
                  <option key={route.id} value={route.id}>
                    {route.name} ({route.origin_name} → {route.destination_name})
                  </option>
                ))}
              </select>
            </label>
          </div>

          {!tripActive ? (
            <button
              className="primary-button full"
              type="button"
              disabled={!assignedRoute}
              onClick={startTrip}
            >
              Start trip <span>→</span>
            </button>
          ) : (
            <button className="danger-button full" type="button" onClick={stopTrip}>
              Stop trip
            </button>
          )}
        </div>
      )}

      <div className="driver-trip-map">
        <GoogleTransportMap
          origin={position ? { ...position, label: 'You' } : null}
          destination={
            assignedRouteDetail
              ? { lat: assignedRouteDetail.destination_lat, lng: assignedRouteDetail.destination_lng, label: assignedRouteDetail.destination_name }
              : previewRoute
              ? { lat: previewRoute.destination_lat, lng: previewRoute.destination_lng, label: previewRoute.destination_name }
              : null
          }
          routeGeometry={assignedRouteDetail?.geometry || previewRoute?.geometry}
          height="240px"
        />
      </div>

      {tripActive && (
        <div className="driver-trip-active-card">
          <div className="driver-trip-status-row">
            <span>Trip status</span>
            {routeStatus && (
              <span className={`route-status-badge route-status-${routeStatus}`}>
                {routeStatus === 'off_route' ? 'OFF ROUTE' : routeStatus === 'on_route' ? 'ON ROUTE' : 'Route status unknown'}
              </span>
            )}
          </div>

          {lastPing?.distance_from_route_m != null && routeStatus === 'off_route' && (
            <p className="muted small">
              Approximately {Math.round(lastPing.distance_from_route_m)} m from the planned route.
            </p>
          )}

          {gpsStatus === 'error' && gpsError && <p className="muted small">{gpsError}</p>}
          {pushError && <p className="muted small">Could not reach THEMBA: {pushError}</p>}

          <GPSStatus speedKmh={position?.speedKmh} accuracyM={position?.accuracyM} source="gps" />
        </div>
      )}
    </div>
  );
}

export default DriverTripPanel;
