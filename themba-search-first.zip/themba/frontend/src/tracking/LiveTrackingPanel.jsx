import { useCallback, useEffect, useRef, useState } from 'react';
import GoogleTransportMap from '../routing/GoogleTransportMap';
import GPSStatus, { TestDataTag, LiveGpsTag } from '../routing/GPSStatus';
import LoginGate from '../routing/LoginGate';
import useAuth from '../hooks/useAuth';
import { useFleetSocket } from '../hooks/useTrackingSocket';
import { estimateEtaMinutes } from '../services/trackingApi';
import thembaApi from '../api/themba';

const POLL_INTERVAL_MS = 4000;

/**
 * Clickable live-tracking view for operators/administrators (THEMBA_SPEC
 * §25/§26): a list of vehicles on the left, a map on the right, with the
 * selected vehicle's route line, destination, speed, GPS accuracy, ETA and
 * ON ROUTE/OFF ROUTE status all shown together. Updates arrive over the
 * ws/tracking/ WebSocket feed in real time; if the socket can't connect it
 * transparently falls back to REST polling every few seconds so the screen
 * still works.
 *
 * The SAME component serves both the Operator and Administrator role
 * screens (both get identical read access to the fleet per THEMBA_SPEC
 * §25/§26 - there is no operator-only or admin-only field here). Requires
 * an operator/administrator account (backend enforces this too - this
 * login is not just cosmetic, see core/permissions.py).
 */
function LiveTrackingPanel({ notify }) {
  const { auth, login, logout, loading: loggingIn, error: loginError } = useAuth();
  const [vehicles, setVehicles] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [loadError, setLoadError] = useState('');
  const [usingFallback, setUsingFallback] = useState(false);
  const [selectedRouteDetail, setSelectedRouteDetail] = useState(null);
  const pollRef = useRef(null);

  const canViewFleet = auth?.role === 'operator' || auth?.role === 'administrator';

  const fetchOnce = useCallback(async () => {
    try {
      const data = await thembaApi.listVehicles();
      setVehicles(data.results || data || []);
      setLoadError('');
    } catch (err) {
      setLoadError(err.message);
    }
  }, []);

  // Initial load once authenticated.
  useEffect(() => {
    if (canViewFleet) fetchOnce();
  }, [canViewFleet, fetchOnce]);

  // Live updates over WebSocket; REST polling as a fallback.
  const { connected } = useFleetSocket(canViewFleet ? auth.token : null, {
    onMessage: (payload) => {
      setUsingFallback(false);
      setVehicles((current) =>
        current.map((vehicle) =>
          vehicle.id === payload.vehicle_id
            ? {
                ...vehicle,
                status: 'active',
                latest_location: {
                  lat: payload.lat,
                  lng: payload.lng,
                  speed_kmh: payload.speed_kmh,
                  heading_deg: payload.heading_deg,
                  accuracy_m: payload.accuracy_m,
                  source: payload.source,
                  recorded_at: payload.recorded_at,
                },
                route_status: payload.route_status,
                distance_from_route_m: payload.distance_from_route_m,
              }
            : vehicle
        )
      );
    },
    onFallback: () => setUsingFallback(true),
  });

  useEffect(() => {
    if (!canViewFleet) return undefined;
    if (usingFallback) {
      pollRef.current = setInterval(fetchOnce, POLL_INTERVAL_MS);
      return () => clearInterval(pollRef.current);
    }
    return undefined;
  }, [usingFallback, canViewFleet, fetchOnce]);

  const mappable = vehicles.filter((v) => v.latest_location);
  const selectedVehicle = mappable.find((v) => v.id === selectedId) || mappable[0];

  // The vehicle-list's nested `route` is a lightweight summary (no
  // coordinates/geometry - see RouteSummarySerializer) - fetch the full
  // Route for whichever vehicle is selected so the map can draw its line
  // and destination marker, and so ETA has a destination to aim at.
  useEffect(() => {
    if (!selectedVehicle?.route?.id) {
      setSelectedRouteDetail(null);
      return;
    }
    let cancelled = false;
    thembaApi
      .getRoute(selectedVehicle.route.id)
      .then((data) => !cancelled && setSelectedRouteDetail(data))
      .catch(() => !cancelled && setSelectedRouteDetail(null));
    return () => {
      cancelled = true;
    };
  }, [selectedVehicle?.route?.id]);

  if (!canViewFleet) {
    return (
      <LoginGate
        title="Operator / administrator sign-in"
        hint={`Live vehicle tracking requires an operator or administrator account. Demo accounts: operator_demo / admin_demo, password "themba123".`}
        onLogin={login}
        loading={loggingIn}
        error={loginError}
      />
    );
  }

  const vehicleMarkers = mappable.map((vehicle) => ({
    id: vehicle.id,
    lat: vehicle.latest_location.lat,
    lng: vehicle.latest_location.lng,
    heading: vehicle.latest_location.heading_deg,
    label: `${vehicle.registration} · ${vehicle.route?.name || 'Unassigned route'}`,
    color: vehicle.id === selectedVehicle?.id ? '#3169e6' : '#e6a841',
  }));

  const etaMinutes = selectedVehicle
    ? estimateEtaMinutes(selectedVehicle.latest_location, selectedRouteDetail)
    : null;

  return (
    <div className="live-tracking-panel">
      <div className="vehicle-list">
        <div className="tracking-connection-row">
          <span className={connected ? 'connection-dot connection-live' : 'connection-dot connection-poll'} />
          <span className="muted small">{connected ? 'Live (WebSocket)' : 'Polling every 4s'}</span>
          <button className="text-button" type="button" onClick={logout}>
            Sign out
          </button>
        </div>

        {loadError && <p className="muted small">{loadError}</p>}
        {!loadError && vehicles.length === 0 && <p className="muted small">No vehicles registered yet.</p>}

        {vehicles.map((vehicle) => (
          <button
            key={vehicle.id}
            type="button"
            className={vehicle.id === selectedVehicle?.id ? 'vehicle-row selected' : 'vehicle-row'}
            onClick={() => {
              setSelectedId(vehicle.id);
              notify?.(`Tracking ${vehicle.registration}`);
            }}
          >
            <span className={`status-dot status-${vehicle.status}`} />
            <span>
              <strong>
                {vehicle.registration}{' '}
                {vehicle.latest_location?.source === 'simulated' && <TestDataTag />}
                {vehicle.latest_location?.source === 'gps' && <LiveGpsTag />}
              </strong>
              <small>
                {vehicle.model} · {vehicle.route?.name || 'No route assigned'}
              </small>
            </span>
            <b>
              {vehicle.latest_location
                ? vehicle.latest_location.speed_kmh != null
                  ? `${Math.round(vehicle.latest_location.speed_kmh)} km/h`
                  : 'Speed unavailable'
                : 'No GPS yet'}
            </b>
          </button>
        ))}
      </div>

      <div className="tracking-map-column">
        <GoogleTransportMap
          vehicles={vehicleMarkers}
          destination={
            selectedRouteDetail
              ? { lat: selectedRouteDetail.destination_lat, lng: selectedRouteDetail.destination_lng, label: selectedRouteDetail.destination_name }
              : null
          }
          routeGeometry={selectedRouteDetail?.geometry}
          height="300px"
        />

        {selectedVehicle && (
          <div className="vehicle-detail-card">
            <div className="vehicle-detail-header">
              <strong>{selectedVehicle.registration}</strong>
              <span className={`route-status-badge route-status-${selectedVehicle.route_status || 'unknown'}`}>
                {selectedVehicle.route_status === 'off_route'
                  ? 'OFF ROUTE'
                  : selectedVehicle.route_status === 'on_route'
                  ? 'ON ROUTE'
                  : 'Route status unknown'}
              </span>
            </div>
            <p className="muted small">
              Route: {selectedVehicle.route?.name || 'Unassigned'} · Destination:{' '}
              {selectedRouteDetail?.destination_name || selectedVehicle.route?.destination_name || 'Unassigned'}
            </p>
            <p className="muted small">Driver: {selectedVehicle.driver_name || 'Unassigned'}</p>

            <p className="muted small">
              ETA: {etaMinutes != null ? `~${etaMinutes} min (straight-line estimate)` : 'ETA unavailable'}
            </p>

            {selectedVehicle.distance_from_route_m != null && selectedVehicle.route_status === 'off_route' && (
              <p className="muted small">
                Approximately {Math.round(selectedVehicle.distance_from_route_m)} m from the planned route.
              </p>
            )}
            <GPSStatus
              speedKmh={selectedVehicle.latest_location?.speed_kmh}
              accuracyM={selectedVehicle.latest_location?.accuracy_m}
              source={selectedVehicle.latest_location?.source}
            />
          </div>
        )}
      </div>
    </div>
  );
}

export default LiveTrackingPanel;
