import { useEffect, useState } from 'react';
import RoutingFlow from './src/routing/RoutingFlow.jsx';
import LiveTrackingPanel from './src/tracking/LiveTrackingPanel.jsx';
import DriverTripPanel from './src/driver/DriverTripPanel.jsx';
import PassengerMapDashboard from './src/routing/PassengerMapDashboard.jsx';
import './src/routing/routing.css';

const roles = ['passenger', 'driver', 'operator', 'administrator'];

const demoUsers = {
  passenger: 'Sibusiso Dlamini',
  driver: 'Bongani Mthembu',
  operator: 'Nqobile Zondi',
  administrator: 'THEMBA Administrator',
};

const trips = [
  {
    id: 'TH-ONG-001',
    route: 'Ongoye to Empangeni',
    departure: '08:30',
    fare: 'R24',
    status: 'Boarding',
    duration: '35 min',
    origin: 'Ongoye',
    destination: 'Empangeni',
    eta: '09:05',
    operator: 'Ongoye Taxi Association',
    driver: 'Bongani Mthembu',
    vehicle: 'Toyota Quantum',
    registration: 'ND 123-456',
  },
  {
    id: 'TH-ONG-002',
    route: 'Ongoye to Esikhawini',
    departure: '09:00',
    fare: 'R20',
    status: 'Scheduled',
    duration: '30 min',
    origin: 'Ongoye',
    destination: 'Esikhawini',
    eta: '09:30',
    operator: 'Ongoye Taxi Association',
    driver: 'Nomvula Khumalo',
    vehicle: 'Toyota Quantum',
    registration: 'ND 345-678',
  },
  {
    id: 'TH-ONG-003',
    route: 'Ongoye to Richards Bay',
    departure: '07:45',
    fare: 'R34',
    status: 'Scheduled',
    duration: '50 min',
    origin: 'Ongoye',
    destination: 'Richards Bay',
    eta: '08:35',
    operator: 'Richards Bay Taxi Association',
    driver: 'Thabo Nkosi',
    vehicle: 'Toyota Quantum',
    registration: 'ND 654-321',
  },
  {
    id: 'TH-ESI-001',
    route: 'Esikhawini to Empangeni',
    departure: '10:00',
    fare: 'R23',
    status: 'Scheduled',
    duration: '40 min',
    origin: 'Esikhawini',
    destination: 'Empangeni',
    eta: '10:40',
    operator: 'Esikhawini Taxi Association',
    driver: 'Sipho Zulu',
    vehicle: 'Toyota Quantum',
    registration: 'ND 789-012',
  },
  {
    id: 'TH-ESI-002',
    route: 'Esikhawini to Richards Bay',
    departure: '11:15',
    fare: 'R18',
    status: 'Scheduled',
    duration: '25 min',
    origin: 'Esikhawini',
    destination: 'Richards Bay',
    eta: '11:40',
    operator: 'Esikhawini Taxi Association',
    driver: 'Lindiwe Dlamini',
    vehicle: 'Toyota Quantum',
    registration: 'ND 456-789',
  },
  {
    id: 'TH-RB-001',
    route: 'Richards Bay to Empangeni',
    departure: '12:00',
    fare: 'R21',
    status: 'Scheduled',
    duration: '35 min',
    origin: 'Richards Bay',
    destination: 'Empangeni',
    eta: '12:35',
    operator: 'Empangeni Taxi Association',
    driver: 'Sizwe Mkhize',
    vehicle: 'Toyota Quantum',
    registration: 'ND 567-890',
  },
];

function getProfileDefaults(role) {
  return {
    passenger: {
      name: 'Sibusiso Dlamini',
      phone: '082 123 4567',
      email: 'sibusiso@temba.co.za',
      homeArea: 'Empangeni',
      emergencyContact: 'Nandi Dlamini',
      password: '',
      newPassword: '',
      confirmPassword: '',
      avatarInitials: 'SD',
      preferences: {
        emailAlerts: true,
        smsAlerts: true,
        pushAlerts: false,
      },
    },
    driver: {
      name: 'Bongani Mthembu',
      phone: '071 246 8132',
      email: 'bongani@temba.co.za',
      licenseNo: 'ND 123-456',
      vehicle: 'Toyota Quantum',
      password: '',
      newPassword: '',
      confirmPassword: '',
      avatarInitials: 'BM',
      preferences: {
        emailAlerts: true,
        smsAlerts: true,
        pushAlerts: true,
      },
    },
    operator: {
      name: 'Nqobile Zondi',
      phone: '082 659 1122',
      email: 'nqobile@temba.co.za',
      operatorCode: 'TH-OPS-018',
      region: 'King Cetshwayo',
      password: '',
      newPassword: '',
      confirmPassword: '',
      avatarInitials: 'NZ',
      preferences: {
        emailAlerts: true,
        smsAlerts: false,
        pushAlerts: true,
      },
    },
    administrator: {
      name: 'THEMBA Administrator',
      phone: '060 443 9801',
      email: 'admin@temba.co.za',
      department: 'Operations & Safety',
      accessLevel: 'Full access',
      password: '',
      newPassword: '',
      confirmPassword: '',
      avatarInitials: 'TA',
      preferences: {
        emailAlerts: true,
        smsAlerts: true,
        pushAlerts: true,
      },
    },
  }[role] || {
    name: demoUsers[role] || 'User',
    phone: '',
    email: '',
    password: '',
    newPassword: '',
    confirmPassword: '',
    avatarInitials: 'U',
    preferences: {
      emailAlerts: true,
      smsAlerts: true,
      pushAlerts: false,
    },
  };
}

function App() {
  const [screen, setScreen] = useState('welcome');
  const [role, setRole] = useState('passenger');
  const [activeTrip, setActiveTrip] = useState(trips[0]);
  const [darkMode, setDarkMode] = useState(true);
  const [notice, setNotice] = useState('');
  const [profile, setProfile] = useState(getProfileDefaults('passenger'));
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [routingOpen, setRoutingOpen] = useState(false);
  const [trackingOpen, setTrackingOpen] = useState(false);
  const [driverTripOpen, setDriverTripOpen] = useState(false);

  function notify(message) {
    setNotice(message);
    window.setTimeout(() => setNotice(''), 2800);
  }

  useEffect(() => {
    setProfile(getProfileDefaults(role));
  }, [role]);

  function enterDashboard(selectedRole = role) {
    setRole(selectedRole);
    setScreen('dashboard');
    setRoutingOpen(false);
  }

  return (
    <div className={darkMode ? 'app dark' : 'app light'}>
      <header className="topbar">
        <button className="brand" onClick={() => setScreen('welcome')} type="button">
          <span className="brand-mark">T</span>
          <span>
            <strong>THEMBA</strong>
            <small>Transport Hub with Evaluated Mobility, Boarding & Accountability</small>
          </span>
        </button>

        <div className="top-actions">
          <button className="text-button" onClick={() => setDarkMode((value) => !value)} type="button">
            {darkMode ? 'Light mode' : 'Dark mode'}
          </button>
          {screen !== 'welcome' && (
            <button className="settings-button" onClick={() => setSettingsOpen(true)} type="button">
              Settings
            </button>
          )}
          {screen !== 'welcome' && (
            <button className="outline-button" onClick={() => setScreen('welcome')} type="button">
              Exit
            </button>
          )}
        </div>
      </header>

      <main className="page-shell">
        {screen === 'welcome' && (
          <Welcome
            onLogin={() => setScreen('login')}
            onGuest={() => enterDashboard('passenger')}
            onRegister={() => setScreen('register')}
          />
        )}

        {screen === 'login' && (
          <Login
            role={role}
            setRole={setRole}
            onBack={() => setScreen('welcome')}
            onSubmit={() => enterDashboard()}
            onDemo={() => notify(`Demo credentials loaded for ${role}.`)}
          />
        )}

        {screen === 'register' && (
          <Register
            role={role}
            setRole={setRole}
            onBack={() => setScreen('welcome')}
            onSubmit={() => notify('Registration recorded. Driver and operator accounts require administrator approval.')}
          />
        )}

        {screen === 'dashboard' && (
          <Dashboard
            role={role}
            activeTrip={activeTrip}
            setActiveTrip={setActiveTrip}
            notify={notify}
            onOpenRouting={() => setRoutingOpen(true)}
            onOpenTracking={() => setTrackingOpen(true)}
            onOpenDriverTrip={() => setDriverTripOpen(true)}
          />
        )}
      </main>

      {routingOpen && (
        <div className="settings-overlay" onClick={() => setRoutingOpen(false)}>
          <div
            className="settings-modal routing-modal nav-panel-modal"
            onClick={(event) => event.stopPropagation()}
          >
            <RoutingFlow
              notify={notify}
              onClose={() => setRoutingOpen(false)}
              passengerName={demoUsers.passenger || 'Sibusiso Dlamini'}
              activeTrip={activeTrip}
              setActiveTrip={setActiveTrip}
            />
          </div>
        </div>
      )}

      {trackingOpen && (
        <div className="settings-overlay" onClick={() => setTrackingOpen(false)}>
          <div
            className="settings-modal tracking-modal"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="settings-header">
              <div>
                <div className="eyebrow">Live vehicle tracking</div>
                <h3>Fleet map</h3>
              </div>
              <button className="text-button" onClick={() => setTrackingOpen(false)} type="button">
                Close
              </button>
            </div>
            <LiveTrackingPanel notify={notify} />
          </div>
        </div>
      )}

      {driverTripOpen && (
        <div className="settings-overlay" onClick={() => setDriverTripOpen(false)}>
          <div
            className="settings-modal tracking-modal"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="settings-header">
              <div>
                <div className="eyebrow">Driver</div>
                <h3>Start trip</h3>
              </div>
              <button className="text-button" onClick={() => setDriverTripOpen(false)} type="button">
                Close
              </button>
            </div>
            <DriverTripPanel notify={notify} />
          </div>
        </div>
      )}

      {settingsOpen && (
        <ProfileSettings
          role={role}
          profile={profile}
          setProfile={setProfile}
          onClose={() => setSettingsOpen(false)}
          notify={notify}
        />
      )}

      {notice && <div className="toast" role="status">{notice}</div>}
    </div>
  );
}

function ProfileSettings({ role, profile, setProfile, onClose, notify }) {
  function handleFieldChange(event) {
    const { name, value } = event.target;
    setProfile((current) => ({ ...current, [name]: value }));
  }

  function handlePreferenceChange(key) {
    setProfile((current) => ({
      ...current,
      preferences: {
        ...current.preferences,
        [key]: !current.preferences?.[key],
      },
    }));
  }

  return (
    <div className="settings-overlay" onClick={onClose}>
      <div className="settings-modal" onClick={(event) => event.stopPropagation()}>
        <div className="settings-header">
          <div>
            <div className="eyebrow">Profile settings</div>
            <h3>{demoUsers[role]}</h3>
          </div>
          <button className="text-button" onClick={onClose} type="button">Close</button>
        </div>

        <div className="avatar-card">
          <div className="avatar-badge">{profile.avatarInitials || 'U'}</div>
          <div>
            <strong>{profile.name || demoUsers[role]}</strong>
            <small>{profile.email || 'No email on file'}</small>
          </div>
          <button className="secondary-button" type="button">Change photo</button>
        </div>

        <div className="settings-section">
          <div className="section-title">Personal details</div>
          <div className="settings-grid">
            <label>
              Full name
              <input name="name" value={profile.name || ''} onChange={handleFieldChange} />
            </label>
            <label>
              Phone number
              <input name="phone" value={profile.phone || ''} onChange={handleFieldChange} />
            </label>
            <label>
              Email address
              <input name="email" value={profile.email || ''} onChange={handleFieldChange} />
            </label>
            <label>
              Preferred language
              <input value="English" readOnly />
            </label>

            {role === 'passenger' && (
              <>
                <label>
                  Home area
                  <input name="homeArea" value={profile.homeArea || ''} onChange={handleFieldChange} />
                </label>
                <label>
                  Emergency contact
                  <input name="emergencyContact" value={profile.emergencyContact || ''} onChange={handleFieldChange} />
                </label>
              </>
            )}

            {role === 'driver' && (
              <>
                <label>
                  License number
                  <input name="licenseNo" value={profile.licenseNo || ''} onChange={handleFieldChange} />
                </label>
                <label>
                  Vehicle
                  <input name="vehicle" value={profile.vehicle || ''} onChange={handleFieldChange} />
                </label>
              </>
            )}

            {role === 'operator' && (
              <>
                <label>
                  Operator code
                  <input name="operatorCode" value={profile.operatorCode || ''} onChange={handleFieldChange} />
                </label>
                <label>
                  Region
                  <input name="region" value={profile.region || ''} onChange={handleFieldChange} />
                </label>
              </>
            )}

            {role === 'administrator' && (
              <>
                <label>
                  Department
                  <input name="department" value={profile.department || ''} onChange={handleFieldChange} />
                </label>
                <label>
                  Access level
                  <input name="accessLevel" value={profile.accessLevel || ''} onChange={handleFieldChange} />
                </label>
              </>
            )}
          </div>
        </div>

        <div className="settings-section">
          <div className="section-title">Security</div>
          <div className="settings-grid single-column">
            <label>
              Current password
              <input name="password" type="password" value={profile.password || ''} onChange={handleFieldChange} />
            </label>
            <label>
              New password
              <input name="newPassword" type="password" value={profile.newPassword || ''} onChange={handleFieldChange} />
            </label>
            <label>
              Confirm password
              <input name="confirmPassword" type="password" value={profile.confirmPassword || ''} onChange={handleFieldChange} />
            </label>
          </div>
        </div>

        <div className="settings-section">
          <div className="section-title">Notifications</div>
          <div className="checkbox-stack">
            <label className="checkbox-row">
              <input
                checked={Boolean(profile.preferences?.emailAlerts)}
                onChange={() => handlePreferenceChange('emailAlerts')}
                type="checkbox"
              />
              Email alerts
            </label>
            <label className="checkbox-row">
              <input
                checked={Boolean(profile.preferences?.smsAlerts)}
                onChange={() => handlePreferenceChange('smsAlerts')}
                type="checkbox"
              />
              SMS alerts
            </label>
            <label className="checkbox-row">
              <input
                checked={Boolean(profile.preferences?.pushAlerts)}
                onChange={() => handlePreferenceChange('pushAlerts')}
                type="checkbox"
              />
              Push notifications
            </label>
          </div>
        </div>

        <div className="settings-actions">
          <button className="secondary-button" onClick={onClose} type="button">Cancel</button>
          <button
            className="primary-button"
            onClick={() => {
              notify('Profile updated successfully.');
              onClose();
            }}
            type="button"
          >
            Save changes
          </button>
        </div>
      </div>
    </div>
  );
}

function Welcome({ onLogin, onGuest, onRegister }) {
  return (
    <section className="welcome-panel">
      <div className="eyebrow">South African transport information platform</div>
      <h1>
        Travel information.<br />
        <em>Verified trips.</em><br />
        Safer journeys.
      </h1>
      <p className="lead">
        Find the right route, understand the fare, and connect every completed trip to accountable passenger feedback.
      </p>

      <div className="welcome-actions">
        <button className="primary-button" onClick={onLogin} type="button">
          Sign in <span>→</span>
        </button>
        <button className="secondary-button" onClick={onRegister} type="button">
          Create an account
        </button>
        <button className="text-button" onClick={onGuest} type="button">
          Continue as guest →
        </button>
      </div>

      <div className="feature-strip">
        <span>01 / Route clarity</span>
        <span>02 / Trip verification</span>
        <span>03 / Accountable feedback</span>
      </div>
    </section>
  );
}

function Login({ role, setRole, onBack, onSubmit, onDemo }) {
  return (
    <section className="auth-panel">
      <button className="back-link" onClick={onBack} type="button">← Back</button>
      <div className="eyebrow">Secure access</div>
      <h2>Welcome back.</h2>
      <p className="muted">Choose your role to open the relevant dashboard.</p>

      <RolePicker role={role} setRole={setRole} />

      <label>
        Phone number or email
        <input placeholder="name@domain.co.za" />
      </label>

      <label>
        Password
        <input type="password" placeholder="Your password" />
      </label>

      <button className="primary-button full" onClick={onSubmit} type="button">
        Sign in <span>→</span>
      </button>
      <button className="secondary-button full" onClick={onDemo} type="button">
        Load demo credentials
      </button>
    </section>
  );
}

function Register({ role, setRole, onBack, onSubmit }) {
  return (
    <section className="auth-panel">
      <button className="back-link" onClick={onBack} type="button">← Back</button>
      <div className="eyebrow">Account registration</div>
      <h2>Join THEMBA.</h2>
      <p className="muted">Passenger access is immediate. Driver and operator accounts require review.</p>

      <RolePicker role={role} setRole={setRole} />

      <div className="form-grid">
        <label>
          First name
          <input placeholder="First name" />
        </label>
        <label>
          Surname
          <input placeholder="Surname" />
        </label>
      </div>

      <label>
        Cellphone number
        <input placeholder="082 123 4567" />
      </label>

      {role === 'driver' && (
        <>
          <label>
            Driver license number
            <input placeholder="License number" />
          </label>
          <label>
            Association/rank code
            <input placeholder="Rank code" />
          </label>
        </>
      )}

      {role === 'operator' && (
        <label>
          Operator code
          <input placeholder="Operator code" />
        </label>
      )}

      {role === 'administrator' && (
        <label>
          Administrator code
          <input placeholder="Administrator code" />
        </label>
      )}

      <label>
        Password
        <input type="password" placeholder="8+ characters, uppercase and digit" />
      </label>

      <button className="primary-button full" onClick={onSubmit} type="button">
        Submit registration <span>→</span>
      </button>
    </section>
  );
}

function RolePicker({ role, setRole }) {
  return (
    <div className="role-picker">
      {roles.map((item) => (
        <button
          key={item}
          className={role === item ? 'selected' : ''}
          onClick={() => setRole(item)}
          type="button"
        >
          {item}
        </button>
      ))}
    </div>
  );
}

function Dashboard({ role, activeTrip, setActiveTrip, notify, onOpenRouting, onOpenTracking, onOpenDriverTrip }) {
  // Passenger: full map UI (search trip panel first) — no extra dashboard chrome
  if (role === 'passenger') {
    return (
      <PassengerMapDashboard
        notify={notify}
        passengerName={demoUsers.passenger || 'Sibusiso Dlamini'}
      />
    );
  }

  return (
    <section className="dashboard">
      <div className="dashboard-heading">
        <div>
          <div className="eyebrow">{role} dashboard</div>
          <h2>{demoUsers[role]}</h2>
        </div>
        <span className="status-pill">Verified workspace</span>
      </div>

      {role === 'driver' && <Driver notify={notify} onOpenTracking={onOpenTracking} onOpenDriverTrip={onOpenDriverTrip} />}
      {role === 'operator' && <Operator notify={notify} onOpenTracking={onOpenTracking} />}
      {role === 'administrator' && <Administrator notify={notify} onOpenTracking={onOpenTracking} />}
    </section>
  );
}

function Passenger({ activeTrip, setActiveTrip, notify, onOpenRouting }) {
  const places = ['Ongoye', 'Empangeni', 'Esikhawini', 'Richards Bay'];
  const [departure, setDeparture] = useState('Ongoye');
  const [destination, setDestination] = useState('Empangeni');
  const [results, setResults] = useState([]);
  const [searched, setSearched] = useState(false);
  const [reviewTrip, setReviewTrip] = useState(null);
  const [panicOpen, setPanicOpen] = useState(false);

  const fareTable = {
    'Ongoye|Empangeni': 24,
    'Ongoye|Esikhawini': 20,
    'Ongoye|Richards Bay': 34,
    'Esikhawini|Empangeni': 23,
    'Esikhawini|Richards Bay': 18,
    'Richards Bay|Empangeni': 21,
  };

  function fareBetween(a, b) {
    if (!a || !b || a === b) return null;
    return fareTable[`${a}|${b}`] ?? fareTable[`${b}|${a}`] ?? null;
  }

  function searchTrip() {
    if (departure === destination) {
      notify('Departure and destination must be different.');
      setResults([]);
      setSearched(true);
      return;
    }
    const fare = fareBetween(departure, destination);
    if (fare == null) {
      notify('No predetermined local taxi route for that pair.');
      setResults([]);
      setSearched(true);
      return;
    }
    const matched = trips.filter((t) => {
      const pair =
        (t.origin === departure && t.destination === destination) ||
        (t.origin === destination && t.destination === departure);
      return pair;
    });
    // Always surface at least one synthetic trip for the fare table pair
    if (!matched.length) {
      matched.push({
        id: `TH-${departure.slice(0, 3).toUpperCase()}-X`,
        route: `${departure} to ${destination}`,
        departure: '08:30',
        fare: `R${fare}`,
        status: 'Scheduled',
        duration: '40 min',
        origin: departure,
        destination,
        eta: '—',
        operator: 'Local Taxi Association',
        driver: 'To be assigned',
        vehicle: 'Toyota Quantum',
        registration: '—',
      });
    } else {
      matched.forEach((t) => {
        t.fare = `R${fare}`;
      });
    }
    setResults(matched);
    setSearched(true);
    notify(`${matched.length} trip(s) found · fare R${fare}.`);
  }

  function selectTrip(trip) {
    setReviewTrip(trip);
    setActiveTrip(trip);
  }

  function confirmPanic() {
    setPanicOpen(false);
    const trip = activeTrip || reviewTrip;
    notify(
      trip
        ? `Emergency alert sent for ${trip.route}. Operator and administrator notified.`
        : 'Emergency alert sent. Operator and administrator notified.'
    );
    // Integration point: POST /api/panic-alerts/ (backend)
    try {
      const API = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000/api';
      navigator.geolocation?.getCurrentPosition(
        (pos) => {
          fetch(`${API}/panic-alerts/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              type: 'PANIC_ALERT',
              tripId: trip?.id,
              departurePoint: trip?.origin,
              destination: trip?.destination,
              latitude: pos.coords.latitude,
              longitude: pos.coords.longitude,
              accuracy: pos.coords.accuracy,
              timestamp: new Date().toISOString(),
            }),
          }).catch(() => {});
        },
        () => {
          fetch(`${API}/panic-alerts/`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              type: 'PANIC_ALERT',
              tripId: trip?.id,
              departurePoint: trip?.origin,
              destination: trip?.destination,
              timestamp: new Date().toISOString(),
            }),
          }).catch(() => {});
        },
        { enableHighAccuracy: true, timeout: 8000 }
      );
    } catch {
      /* backend optional at demo time */
    }
  }

  return (
    <>
      <div className="dashboard-grid">
        <article className="module module-wide">
          <div className="module-heading">
            <span>Search trip</span>
            <span className="module-number">01</span>
          </div>
          <p className="muted" style={{ marginBottom: 12 }}>
            Choose a predetermined departure and destination. Fares are local taxi rates for supported routes only.
          </p>
          <div className="form-grid">
            <label>
              Departure point
              <select value={departure} onChange={(e) => setDeparture(e.target.value)}>
                {places.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Destination
              <select value={destination} onChange={(e) => setDestination(e.target.value)}>
                {places.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <button className="primary-button" type="button" onClick={searchTrip}>
            Search trip <span>→</span>
          </button>
          <button className="secondary-button" type="button" onClick={onOpenRouting}>
            Search route on map <span>→</span>
          </button>
        </article>

        <article className="module">
          <div className="module-heading">
            <span>Local fares</span>
            <span className="module-number">02</span>
          </div>
          <ul className="muted" style={{ margin: 0, paddingLeft: 18, fontSize: '0.85rem', lineHeight: 1.6 }}>
            <li>Ongoye ↔ Empangeni — R24</li>
            <li>Ongoye ↔ Esikhawini — R20</li>
            <li>Ongoye ↔ Richards Bay — R34</li>
            <li>Esikhawini ↔ Empangeni — R23</li>
            <li>Esikhawini ↔ Richards Bay — R18</li>
            <li>Richards Bay ↔ Empangeni — R21</li>
          </ul>
        </article>
      </div>

      {searched && (
        <div className="module">
          <div className="module-heading">
            <span>Matching trips</span>
            <span className="module-number">03</span>
          </div>
          {!results.length && <p className="muted">No trips for that pair.</p>}
          {results.map((trip) => (
            <button
              className={activeTrip?.id === trip.id ? 'trip-row active' : 'trip-row'}
              key={trip.id}
              type="button"
              onClick={() => selectTrip(trip)}
            >
              <span>
                <strong>
                  {trip.origin} → {trip.destination}
                </strong>
                <small>
                  {trip.operator || 'Operator'} · {trip.departure} · {trip.status}
                </small>
              </span>
              <b>{trip.fare}</b>
            </button>
          ))}
        </div>
      )}

      {reviewTrip && (
        <div className="module verified-trip">
          <div>
            <div className="eyebrow">Review trip</div>
            <h3>
              {reviewTrip.origin} → {reviewTrip.destination}
            </h3>
            <p className="muted">
              Operator: {reviewTrip.operator || '—'} · Departs {reviewTrip.departure} · ETA{' '}
              {reviewTrip.eta}
            </p>
            <p className="muted">
              Driver: {reviewTrip.driver || 'To be assigned'} · {reviewTrip.vehicle || 'Toyota Quantum'}{' '}
              {reviewTrip.registration || ''}
            </p>
            <p>
              <strong>Fare: {reviewTrip.fare}</strong>
            </p>
          </div>
          <button className="primary-button" type="button" onClick={onOpenRouting}>
            Open map route
          </button>
          <button className="danger-button" type="button" onClick={() => setPanicOpen(true)}>
            Panic / Emergency
          </button>
        </div>
      )}

      {panicOpen && (
        <div className="settings-overlay" onClick={() => setPanicOpen(false)}>
          <div className="settings-modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 400 }}>
            <div className="settings-header">
              <div>
                <div className="eyebrow">Emergency</div>
                <h3>Send panic alert?</h3>
              </div>
              <button className="text-button" type="button" onClick={() => setPanicOpen(false)}>
                Close
              </button>
            </div>
            <p className="muted">
              This notifies the operator and administrator with your trip details and latest
              location. A single tap is not enough — confirm below.
            </p>
            <button className="danger-button full" type="button" onClick={confirmPanic}>
              Confirm emergency
            </button>
            <button className="secondary-button full" type="button" onClick={() => setPanicOpen(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </>
  );
}

function Driver({ notify, onOpenTracking, onOpenDriverTrip }) {
  return (
    <div className="dashboard-grid">
      <article className="module module-wide">
        <div className="module-heading">
          <span>Trip manifest</span>
          <span className="module-number">03 trips</span>
        </div>

        {trips.map((trip) => (
          <div className="trip-row" key={trip.id}>
            <span>
              <strong>{trip.route}</strong>
              <small>
                {trip.id} · {trip.departure}
              </small>
            </span>
            <b>{trip.status}</b>
          </div>
        ))}
      </article>

      <article className="module">
        <div className="module-heading">
          <span>Start a trip</span>
          <span className="module-number">Live GPS</span>
        </div>
        <p className="muted">
          Begin sending your live location to THEMBA for your assigned route, and see whether
          you're ON ROUTE or OFF ROUTE in real time.
        </p>
        <button className="primary-button" onClick={onOpenDriverTrip} type="button">
          Start trip
        </button>
      </article>

      <article className="module">
        <div className="module-heading">
          <span>Passenger rating</span>
          <span className="module-number">4.7 / 5</span>
        </div>
        <p className="rating">
          ★★★★<span>★</span>
        </p>
        <p className="muted">Based on verified passenger feedback.</p>
        <button className="secondary-button" onClick={() => notify('Trip status marked ready for verification.')} type="button">
          Update status
        </button>
      </article>

      <article className="module">
        <div className="module-heading">
          <span>Your live position</span>
          <span className="module-number">GPS</span>
        </div>
        <p className="muted">
          View how your vehicle currently appears to operators and administrators on the fleet map.
        </p>
        <button className="secondary-button" onClick={onOpenTracking} type="button">
          Open fleet map
        </button>
      </article>
    </div>
  );
}

function Operator({ notify, onOpenTracking }) {
  return (
    <div className="dashboard-grid">
      <article className="module module-wide">
        <div className="module-heading">
          <span>Active trip engagement</span>
          <span className="module-number">One at a time</span>
        </div>
        <p className="muted">
          Search active trips, claim one engagement, verify its driver and vehicle, then register passengers.
        </p>
        <button className="primary-button" onClick={() => notify('Trip TH-EMP-002 is now assigned to your active operator session.')} type="button">
          Engage trip TH-EMP-002 <span>→</span>
        </button>
      </article>

      <article className="module">
        <div className="module-heading">
          <span>Live vehicle tracking</span>
          <span className="module-number">Fleet</span>
        </div>
        <p className="muted">See every vehicle's current position, speed and assigned route in real time.</p>
        <button className="secondary-button" onClick={onOpenTracking} type="button">
          Open fleet map
        </button>
      </article>

      <article className="module">
        <div className="module-heading">
          <span>Complaints</span>
          <span className="module-number">04 open</span>
        </div>
        <p className="muted">Review complaints first and escalate unresolved safety concerns to the administrator.</p>
        <button className="secondary-button" onClick={() => notify('Complaint review opened.')} type="button">
          Review complaints
        </button>
      </article>

      <article className="module">
        <div className="module-heading">
          <span>Verification</span>
          <span className="module-number">Ready</span>
        </div>
        <p className="muted">
          Assigned driver: Bongani Mthembu
          <br />
          Vehicle: Toyota Quantum ND 123-456
        </p>
        <button className="secondary-button" onClick={() => notify('Passenger registration and code generation opened.')} type="button">
          Register passenger
        </button>
      </article>
    </div>
  );
}

function Administrator({ notify, onOpenTracking }) {
  return (
    <div className="dashboard-grid">
      <article className="module module-wide">
        <div className="module-heading">
          <span>Trip management</span>
          <span className="module-number">01</span>
        </div>
        <p className="muted">
          Create, edit, cancel and assign structured trips while preserving the audit history.
        </p>
        <button className="primary-button" onClick={() => notify('Trip management opened.')} type="button">
          Manage trips <span>→</span>
        </button>
      </article>

      <article className="module">
        <div className="module-heading">
          <span>Live vehicle tracking</span>
          <span className="module-number">Fleet</span>
        </div>
        <p className="muted">Monitor every registered Toyota Quantum's live position across all routes.</p>
        <button className="secondary-button" onClick={onOpenTracking} type="button">
          Open fleet map
        </button>
      </article>

      <article className="module">
        <div className="module-heading">
          <span>Approvals</span>
          <span className="module-number">02 pending</span>
        </div>
        <p className="muted">Driver and operator applications awaiting review.</p>
        <button className="secondary-button" onClick={() => notify('Approval queue opened.')} type="button">
          Review approvals
        </button>
      </article>

      <article className="module">
        <div className="module-heading">
          <span>Escalations</span>
          <span className="module-number">03 open</span>
        </div>
        <p className="muted">
          Review escalated complaints and formally confirm safety incidents only after investigation.
        </p>
        <button className="secondary-button" onClick={() => notify('Safety incident review opened.')} type="button">
          Review incidents
        </button>
      </article>

      <article className="module">
        <div className="module-heading">
          <span>Queue and vehicles</span>
          <span className="module-number">04</span>
        </div>
        <p className="muted">Manage queue order, roadworthiness status and driver/vehicle assignments.</p>
        <button className="secondary-button" onClick={() => notify('Queue management opened.')} type="button">
          Manage queue
        </button>
      </article>
    </div>
  );
}

export default App;
