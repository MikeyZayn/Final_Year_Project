from django.contrib import admin

from .models import Boarding, Profile, Route, RouteStop, TaxiFareRule, Trip, Vehicle, VehicleLocation


admin.site.register(Profile)


class RouteStopInline(admin.TabularInline):
    model = RouteStop
    extra = 1


@admin.register(Route)
class RouteAdmin(admin.ModelAdmin):
    list_display = [
        "code", "name", "origin_name", "destination_name",
        "distance_km", "average_duration_min", "base_fare", "vehicle_class", "is_active",
    ]
    list_filter = ["vehicle_class", "is_active"]
    search_fields = ["name", "code", "origin_name", "destination_name"]
    inlines = [RouteStopInline]


@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = ["registration", "model", "route", "driver_name", "status"]
    list_filter = ["status", "model"]
    search_fields = ["registration", "driver_name"]


@admin.register(VehicleLocation)
class VehicleLocationAdmin(admin.ModelAdmin):
    list_display = ["vehicle", "lat", "lng", "speed_kmh", "recorded_at"]
    list_filter = ["vehicle"]


@admin.register(Trip)
class TripAdmin(admin.ModelAdmin):
    list_display = ["id", "route", "vehicle", "status", "departure_time", "fare_charged"]
    list_filter = ["status"]


@admin.register(Boarding)
class BoardingAdmin(admin.ModelAdmin):
    list_display = ["id", "trip", "passenger_name", "fare_paid", "boarded_at"]


@admin.register(TaxiFareRule)
class TaxiFareRuleAdmin(admin.ModelAdmin):
    """
    Configures the fare formula for AD-HOC (Google-calculated) routes - see
    TaxiFareRule.DEMONSTRATION_NOTICE. Predetermined Route fares are
    configured on the Route itself (RouteAdmin above), not here.
    """

    list_display = ["name", "base_fare", "price_per_km", "minimum_fare", "maximum_fare", "active", "route_specific_override"]
    list_filter = ["active"]
