"""
Clears cached predetermined-route geometry so it gets recomputed the next
time /api/routes/{id}/directions/ is requested.

Why this exists: core/views.py:route_directions caches whatever geometry it
computes onto Route.geometry the first time a route is viewed, and then
serves that cached copy forever - it never re-checks ROUTING_SERVICE_URL.
So if a route's geometry was cached while ROUTING_SERVICE_URL was blank (the
built-in straight-line fallback, see core/services/routing_service.py), that
straight line stays cached even after you later set ROUTING_SERVICE_URL to a
real OSRM-compatible service. Run this command once after changing
ROUTING_SERVICE_URL so existing routes pick up real road geometry instead of
continuing to serve the old straight-line fallback.

Usage:
    python manage.py reset_route_geometry            # clear every route
    python manage.py reset_route_geometry --route-id 3
    python manage.py reset_route_geometry --only-fallback   # only clear
        routes whose cached geometry is a 2-point straight line, leaving
        already-correct cached geometry untouched
"""
from django.core.management.base import BaseCommand

from core.models import Route


class Command(BaseCommand):
    help = "Clear cached Route geometry so it is recomputed via the current ROUTING_SERVICE_URL."

    def add_arguments(self, parser):
        parser.add_argument(
            "--route-id",
            type=int,
            default=None,
            help="Only clear this one route's cached geometry, instead of every route.",
        )
        parser.add_argument(
            "--only-fallback",
            action="store_true",
            help="Only clear routes whose cached geometry is a 2-point straight line "
            "(i.e. was produced by the fallback, not by a real routing service). "
            "Leaves already-correct cached geometry alone.",
        )

    def handle(self, *args, **options):
        queryset = Route.objects.all()

        if options["route_id"] is not None:
            queryset = queryset.filter(pk=options["route_id"])
            if not queryset.exists():
                self.stderr.write(self.style.ERROR(f"No route with id {options['route_id']}."))
                return

        if options["only_fallback"]:
            # The fallback always writes exactly 2 points (origin, destination);
            # real OSRM geometry is a dense polyline with many more points.
            fallback_ids = [r.pk for r in queryset if r.geometry and len(r.geometry) <= 2]
            queryset = Route.objects.filter(pk__in=fallback_ids)

        count = queryset.count()
        if count == 0:
            self.stdout.write("No matching routes with cached geometry to clear.")
            return

        queryset.update(geometry=[])
        self.stdout.write(
            self.style.SUCCESS(
                f"Cleared cached geometry on {count} route(s). It will be recomputed "
                "(via ROUTING_SERVICE_URL, or the straight-line fallback if that's still "
                "blank/unreachable) next time each route's directions are requested."
            )
        )
