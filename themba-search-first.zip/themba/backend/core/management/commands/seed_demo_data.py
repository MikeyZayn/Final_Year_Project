from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from django.core.management.base import BaseCommand

from core.models import Profile, Route, RouteStop, TaxiFareRule, Vehicle

DEMO_PASSWORD = "themba123"


class Command(BaseCommand):
    help = "Seed predetermined routes, stops and demo Toyota Quantum vehicles."

    def handle(self, *args, **options):
        self.stdout.write("Seeding THEMBA demo data...")

        # --- Demo routes matching the passenger-app mockups (Cedar Park /
        # Old Quarter / Downtown Station), placed around Richards Bay so the
        # map has real streets to render against. ------------------------
        express, _ = Route.objects.update_or_create(
            code="TH-R045",
            defaults=dict(
                name="Route 45 - Express",
                origin_name="Cedar Park",
                origin_lat=-28.7550,
                origin_lng=32.0450,
                destination_name="Downtown Station (Old Quarter)",
                destination_lat=-28.7690,
                destination_lng=32.0480,
                geometry=[
                    [-28.7550, 32.0450],
                    [-28.7590, 32.0460],
                    [-28.7630, 32.0470],
                    [-28.7690, 32.0480],
                ],
                distance_km=5.8,
                average_duration_min=25,
                average_speed_kmh=14,
                vehicle_class=Route.VehicleClass.QUANTUM_15,
                base_fare=1.00,
                fare_per_km=0.26,
                operator_association="Richards Bay Taxi Association",
                is_active=True,
            ),
        )

        rapid, _ = Route.objects.update_or_create(
            code="TH-R078",
            defaults=dict(
                name="Route 78 - Rapid",
                origin_name="Cedar Park",
                origin_lat=-28.7550,
                origin_lng=32.0450,
                destination_name="Downtown Station (Old Quarter)",
                destination_lat=-28.7690,
                destination_lng=32.0480,
                geometry=[
                    [-28.7550, 32.0450],
                    [-28.7600, 32.0440],
                    [-28.7650, 32.0460],
                    [-28.7690, 32.0480],
                ],
                distance_km=6.4,
                average_duration_min=18,
                average_speed_kmh=21,
                vehicle_class=Route.VehicleClass.QUANTUM_15,
                base_fare=1.00,
                fare_per_km=0.31,
                operator_association="Richards Bay Taxi Association",
                is_active=True,
            ),
        )

        # --- Real long-distance THEMBA routes (matching the existing React
        # demo data: Empangeni <-> Durban / Richards Bay). -----------------
        emp_durban, _ = Route.objects.update_or_create(
            code="TH-EMP-001",
            defaults=dict(
                name="Empangeni to Durban",
                origin_name="Empangeni",
                origin_lat=-28.7808,
                origin_lng=31.8925,
                destination_name="Durban",
                destination_lat=-29.8587,
                destination_lng=31.0218,
                geometry=[
                    [-28.7808, 31.8925],
                    [-29.1500, 31.4200],
                    [-29.6000, 31.1500],
                    [-29.8587, 31.0218],
                ],
                distance_km=168,
                average_duration_min=200,
                average_speed_kmh=68,
                vehicle_class=Route.VehicleClass.QUANTUM_22,
                base_fare=15.00,
                fare_per_km=0.42,
                operator_association="Empangeni Long Distance Taxi Association",
                is_active=True,
            ),
        )

        emp_rbay, _ = Route.objects.update_or_create(
            code="TH-EMP-002",
            defaults=dict(
                name="Empangeni to Richards Bay",
                origin_name="Empangeni",
                origin_lat=-28.7808,
                origin_lng=31.8925,
                destination_name="Richards Bay",
                destination_lat=-28.7810,
                destination_lng=32.0377,
                geometry=[
                    [-28.7808, 31.8925],
                    [-28.7809, 31.9600],
                    [-28.7810, 32.0377],
                ],
                distance_km=24,
                average_duration_min=35,
                average_speed_kmh=45,
                vehicle_class=Route.VehicleClass.QUANTUM_15,
                base_fare=8.00,
                fare_per_km=1.10,
                operator_association="Empangeni Taxi Association",
                is_active=True,
            ),
        )

        # Predetermined destinations: Empangeni, Kwa-Dlangezwa, Richards Bay, eSikhawini
        emp_dlangezwa, _ = Route.objects.update_or_create(
            code="TH-EMP-003",
            defaults=dict(
                name="Empangeni to Kwa-Dlangezwa",
                origin_name="Empangeni",
                origin_lat=-28.7808,
                origin_lng=31.8925,
                destination_name="Kwa-Dlangezwa",
                destination_lat=-28.8540,
                destination_lng=31.8460,
                geometry=[
                    [-28.7808, 31.8925],
                    [-28.8200, 31.8700],
                    [-28.8540, 31.8460],
                ],
                distance_km=14,
                average_duration_min=35,
                average_speed_kmh=40,
                vehicle_class=Route.VehicleClass.QUANTUM_15,
                base_fare=8.00,
                fare_per_km=1.15,
                operator_association="Empangeni Taxi Association",
                is_active=True,
            ),
        )

        emp_esikhawini, _ = Route.objects.update_or_create(
            code="TH-EMP-004",
            defaults=dict(
                name="Empangeni to eSikhawini",
                origin_name="Empangeni",
                origin_lat=-28.7808,
                origin_lng=31.8925,
                destination_name="eSikhawini",
                destination_lat=-28.8830,
                destination_lng=31.9000,
                geometry=[
                    [-28.7808, 31.8925],
                    [-28.8300, 31.8950],
                    [-28.8830, 31.9000],
                ],
                distance_km=16,
                average_duration_min=40,
                average_speed_kmh=40,
                vehicle_class=Route.VehicleClass.QUANTUM_15,
                base_fare=8.00,
                fare_per_km=1.25,
                operator_association="Empangeni Taxi Association",
                is_active=True,
            ),
        )

        RouteStop.objects.filter(
            route__in=[express, rapid, emp_durban, emp_rbay, emp_dlangezwa, emp_esikhawini]
        ).delete()
        RouteStop.objects.bulk_create(
            [
                RouteStop(route=express, name="Cedar Park Rank", lat=-28.7550, lng=32.0450, order=0, fare_from_origin=0),
                RouteStop(route=express, name="Riverside Reading Room", lat=-28.7620, lng=32.0465, order=1, fare_from_origin=1.50),
                RouteStop(route=express, name="Downtown Station", lat=-28.7690, lng=32.0480, order=2, fare_from_origin=2.50),

                RouteStop(route=emp_durban, name="Empangeni Rank", lat=-28.7808, lng=31.8925, order=0, fare_from_origin=0),
                RouteStop(route=emp_durban, name="Gingindlovu", lat=-29.0167, lng=31.6167, order=1, fare_from_origin=45),
                RouteStop(route=emp_durban, name="Durban Rank", lat=-29.8587, lng=31.0218, order=2, fare_from_origin=85),

                RouteStop(route=emp_rbay, name="Empangeni Rank", lat=-28.7808, lng=31.8925, order=0, fare_from_origin=0),
                RouteStop(route=emp_rbay, name="Richards Bay Rank", lat=-28.7810, lng=32.0377, order=1, fare_from_origin=35),

                RouteStop(route=emp_dlangezwa, name="Empangeni Rank", lat=-28.7808, lng=31.8925, order=0, fare_from_origin=0),
                RouteStop(route=emp_dlangezwa, name="Kwa-Dlangezwa", lat=-28.8540, lng=31.8460, order=1, fare_from_origin=24),

                RouteStop(route=emp_esikhawini, name="Empangeni Rank", lat=-28.7808, lng=31.8925, order=0, fare_from_origin=0),
                RouteStop(route=emp_esikhawini, name="eSikhawini Rank", lat=-28.8830, lng=31.9000, order=1, fare_from_origin=28),
            ]
        )


        # --- Local taxi predetermined pairs (bidirectional same fare) -----
        local_pairs = [
            ("TH-LOC-001", "Ongoye", -28.8540, 31.8460, "Empangeni", -28.7808, 31.8925, 24, 14, 35),
            ("TH-LOC-002", "Ongoye", -28.8540, 31.8460, "Esikhawini", -28.8830, 31.9000, 20, 12, 30),
            ("TH-LOC-003", "Ongoye", -28.8540, 31.8460, "Richards Bay", -28.7810, 32.0377, 34, 22, 50),
            ("TH-LOC-004", "Esikhawini", -28.8830, 31.9000, "Empangeni", -28.7808, 31.8925, 23, 16, 40),
            ("TH-LOC-005", "Esikhawini", -28.8830, 31.9000, "Richards Bay", -28.7810, 32.0377, 18, 12, 25),
            ("TH-LOC-006", "Richards Bay", -28.7810, 32.0377, "Empangeni", -28.7808, 31.8925, 21, 18, 35),
        ]
        local_routes = []
        for code, o_name, o_lat, o_lng, d_name, d_lat, d_lng, fare, dist, mins in local_pairs:
            route, _ = Route.objects.update_or_create(
                code=code,
                defaults=dict(
                    name=f"{o_name} to {d_name}",
                    origin_name=o_name,
                    origin_lat=o_lat,
                    origin_lng=o_lng,
                    destination_name=d_name,
                    destination_lat=d_lat,
                    destination_lng=d_lng,
                    geometry=[[o_lat, o_lng], [d_lat, d_lng]],
                    distance_km=dist,
                    average_duration_min=mins,
                    average_speed_kmh=40,
                    vehicle_class=Route.VehicleClass.QUANTUM_15,
                    base_fare=fare,
                    fare_per_km=0,
                    operator_association=f"{o_name} Taxi Association",
                    is_active=True,
                ),
            )
            local_routes.append(route)
            RouteStop.objects.filter(route=route).delete()
            RouteStop.objects.bulk_create(
                [
                    RouteStop(route=route, name=f"{o_name} Rank", lat=o_lat, lng=o_lng, order=0, fare_from_origin=0),
                    RouteStop(route=route, name=f"{d_name} Rank", lat=d_lat, lng=d_lng, order=1, fare_from_origin=fare),
                ]
            )
        self.stdout.write(f"  Local pairs: {len(local_routes)} routes seeded with fixed fares.")

        # --- Vehicles: mostly Toyota Quantums. ----------------------------
        vehicles = [
            dict(registration="ND 123-456", route=express, driver_name="Bongani Mthembu", seating_capacity=15),
            dict(registration="ND 654-321", route=rapid, driver_name="Thabo Nkosi", seating_capacity=15),
            dict(registration="ND 789-012", route=emp_durban, driver_name="Sipho Zulu", seating_capacity=22),
            dict(registration="ND 345-678", route=emp_rbay, driver_name="Nomvula Khumalo", seating_capacity=15),
            dict(registration="ND 456-789", route=emp_dlangezwa, driver_name="Lindiwe Dlamini", seating_capacity=15),
            dict(registration="ND 567-890", route=emp_esikhawini, driver_name="Sizwe Mkhize", seating_capacity=15),
        ]
        created_vehicles = []
        for data in vehicles:
            vehicle, _ = Vehicle.objects.update_or_create(
                registration=data["registration"],
                defaults=dict(
                    make="Toyota",
                    model="Quantum",
                    seating_capacity=data["seating_capacity"],
                    driver_name=data["driver_name"],
                    route=data["route"],
                    status=Vehicle.Status.QUEUED,
                ),
            )
            created_vehicles.append(vehicle)

        # --- Ad-hoc fare rule (THEMBA_SPEC §20) - prices Google-calculated
        # routes that don't match a predetermined Route. Demonstration
        # numbers only; see TaxiFareRule.DEMONSTRATION_NOTICE. ---------------
        TaxiFareRule.objects.update_or_create(
            name="Default ad-hoc fare",
            defaults=dict(
                base_fare=5.00,
                price_per_km=2.00,
                minimum_fare=10.00,
                maximum_fare=None,
                active=True,
                route_specific_override=None,
            ),
        )

        # --- Demo login accounts, one per THEMBA role. ---------------------
        # Password for all of them: DEMO_PASSWORD ("themba123"). The driver
        # account is linked to the first seeded vehicle so it can POST GPS
        # updates to /api/vehicles/{id}/location/.
        User = get_user_model()
        demo_users = [
            ("passenger_demo", Profile.Role.PASSENGER),
            ("driver_demo", Profile.Role.DRIVER),
            ("operator_demo", Profile.Role.OPERATOR),
            ("admin_demo", Profile.Role.ADMINISTRATOR),
        ]
        for username, role in demo_users:
            user, _ = User.objects.update_or_create(
                username=username,
                defaults=dict(password=make_password(DEMO_PASSWORD)),
            )
            Profile.objects.update_or_create(user=user, defaults={"role": role})
            if role == Profile.Role.DRIVER and created_vehicles:
                created_vehicles[0].driver_user = user
                created_vehicles[0].save(update_fields=["driver_user"])

        self.stdout.write(self.style.SUCCESS(
            f"Seeded {Route.objects.count()} routes, {Vehicle.objects.count()} vehicles, "
            f"and demo users (passenger_demo / driver_demo / operator_demo / admin_demo, "
            f"password '{DEMO_PASSWORD}')."
        ))
