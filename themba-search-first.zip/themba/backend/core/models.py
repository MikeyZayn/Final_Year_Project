"""
THEMBA core models.

Covers the "predetermined route" taxi model used by South African minibus
taxis (mostly Toyota Quantums): a route is a fixed rank-to-rank corridor with
a fixed/negotiated fare, not a dynamic point-to-point Uber-style price. The
routing engine finds which predetermined route(s) serve a passenger's
destination and estimates time/fare/speed for that route + vehicle.
"""
from django.conf import settings
from django.db import models
from django.utils import timezone


class Profile(models.Model):
    """Extends Django's built-in User with a THEMBA role for permissions."""

    class Role(models.TextChoices):
        PASSENGER = "passenger", "Passenger"
        DRIVER = "driver", "Driver"
        OPERATOR = "operator", "Operator"
        ADMINISTRATOR = "administrator", "Administrator"

    user = models.OneToOneField(settings.AUTH_USER_MODEL, related_name="profile", on_delete=models.CASCADE)
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.PASSENGER)

    def __str__(self):
        return f"{self.user.username} ({self.role})"


class Route(models.Model):
    """A predetermined taxi route (e.g. 'Empangeni to Durban')."""

    class VehicleClass(models.TextChoices):
        QUANTUM_15 = "quantum_15", "Toyota Quantum (15-seater)"
        QUANTUM_22 = "quantum_22", "Toyota Quantum (22-seater, Ses'fikile)"
        SEDAN = "sedan", "Metered taxi / sedan"

    name = models.CharField(max_length=120, unique=True)
    code = models.CharField(max_length=20, unique=True, help_text="e.g. TH-R045")
    origin_name = models.CharField(max_length=120)
    origin_lat = models.FloatField()
    origin_lng = models.FloatField()
    destination_name = models.CharField(max_length=120)
    destination_lat = models.FloatField()
    destination_lng = models.FloatField()

    # Route geometry as an ordered list of [lat, lng] pairs. Populated either
    # by hand (predetermined shape) or by a one-off call to the routing
    # service (OSRM/GraphHopper) when the route is created.
    geometry = models.JSONField(default=list, blank=True)
    distance_km = models.FloatField(help_text="Total route distance in km")
    average_duration_min = models.FloatField(help_text="Typical trip duration in minutes")
    average_speed_kmh = models.FloatField(default=45.0)

    vehicle_class = models.CharField(
        max_length=20, choices=VehicleClass.choices, default=VehicleClass.QUANTUM_15
    )
    base_fare = models.DecimalField(max_digits=6, decimal_places=2)
    fare_per_km = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    operator_association = models.CharField(max_length=120, blank=True)
    is_active = models.BooleanField(default=True)
    deviation_threshold_m = models.FloatField(
        null=True, blank=True,
        help_text="Override the default off-route distance threshold (metres) for this route.",
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return f"{self.code} - {self.name}"

    def estimated_fare(self, distance_km=None):
        distance = distance_km if distance_km is not None else self.distance_km
        return round(float(self.base_fare) + float(self.fare_per_km) * distance, 2)


class RouteStop(models.Model):
    """Ordered stop/rank along a route (used for boarding + ETA per stop)."""

    route = models.ForeignKey(Route, related_name="stops", on_delete=models.CASCADE)
    name = models.CharField(max_length=120)
    lat = models.FloatField()
    lng = models.FloatField()
    order = models.PositiveIntegerField(default=0)
    fare_from_origin = models.DecimalField(max_digits=6, decimal_places=2, default=0)

    class Meta:
        ordering = ["route", "order"]

    def __str__(self):
        return f"{self.route.code} stop {self.order}: {self.name}"


class Vehicle(models.Model):
    """A Toyota Quantum (or similar) minibus taxi."""

    class Status(models.TextChoices):
        ACTIVE = "active", "Active"
        QUEUED = "queued", "In rank queue"
        OFFLINE = "offline", "Offline"
        MAINTENANCE = "maintenance", "Maintenance"

    registration = models.CharField(max_length=30, unique=True, help_text="e.g. ND 123-456")
    make = models.CharField(max_length=60, default="Toyota")
    model = models.CharField(max_length=60, default="Quantum")
    seating_capacity = models.PositiveSmallIntegerField(default=15)
    roadworthy_expiry = models.DateField(null=True, blank=True)
    operator_code = models.CharField(max_length=40, blank=True)
    route = models.ForeignKey(
        Route, related_name="vehicles", on_delete=models.SET_NULL, null=True, blank=True
    )
    driver_name = models.CharField(max_length=120, blank=True)
    driver_license_no = models.CharField(max_length=40, blank=True)
    driver_user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        related_name="vehicles_driven",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="The driver account allowed to POST GPS pings for this vehicle.",
    )
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.OFFLINE)

    def __str__(self):
        return f"{self.registration} ({self.model})"


class VehicleLocation(models.Model):
    """
    Latest + historical GPS pings for a vehicle. One row per ping; the most
    recent row per vehicle is what live-tracking screens read.
    """

    class Source(models.TextChoices):
        GPS = "gps", "Real GPS"
        SIMULATED = "simulated", "Simulated / test data"

    vehicle = models.ForeignKey(Vehicle, related_name="locations", on_delete=models.CASCADE)
    lat = models.FloatField()
    lng = models.FloatField()
    speed_kmh = models.FloatField(null=True, blank=True, help_text="Null means GPS speed was unavailable.")
    heading_deg = models.FloatField(default=0, help_text="Compass bearing 0-360")
    accuracy_m = models.FloatField(default=0, help_text="GPS accuracy radius in metres")
    source = models.CharField(max_length=20, choices=Source.choices, default=Source.GPS)
    recorded_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-recorded_at"]
        indexes = [models.Index(fields=["vehicle", "-recorded_at"])]

    def __str__(self):
        return f"{self.vehicle.registration} @ {self.recorded_at:%H:%M:%S}"


class Trip(models.Model):
    """An instance of a vehicle running a route, used for boarding + tracking."""

    class Status(models.TextChoices):
        SCHEDULED = "scheduled", "Scheduled"
        BOARDING = "boarding", "Boarding"
        IN_PROGRESS = "in_progress", "In progress"
        COMPLETED = "completed", "Completed"
        CANCELLED = "cancelled", "Cancelled"

    route = models.ForeignKey(Route, related_name="trips", on_delete=models.CASCADE)
    vehicle = models.ForeignKey(
        Vehicle, related_name="trips", on_delete=models.SET_NULL, null=True, blank=True
    )
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.SCHEDULED)
    departure_time = models.DateTimeField(default=timezone.now)
    estimated_arrival = models.DateTimeField(null=True, blank=True)
    fare_charged = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    verification_code = models.CharField(max_length=20, blank=True)

    def __str__(self):
        return f"Trip {self.id}: {self.route.name} ({self.status})"


class TaxiFareRule(models.Model):
    """
    Fare formula for an AD-HOC route (a Google-calculated route between a
    passenger's live/manual location and any destination they typed or
    tapped on the map) — as opposed to a predetermined Route, which prices
    itself via Route.base_fare / Route.fare_per_km above.

    Google Maps supplies distance/time only. THEMBA decides the fare, using
    whichever row here has `active=True` (or a route-specific override).
    These starting numbers are for demonstration only — see
    DEMONSTRATION_NOTICE, which the API always returns alongside a fare so
    the frontend can label it honestly.
    """

    DEMONSTRATION_NOTICE = "Demonstration configuration — not official South African taxi fares."

    name = models.CharField(max_length=80, default="Default ad-hoc fare")
    base_fare = models.DecimalField(max_digits=6, decimal_places=2, default=5.00)
    price_per_km = models.DecimalField(max_digits=6, decimal_places=2, default=2.00)
    minimum_fare = models.DecimalField(max_digits=6, decimal_places=2, default=10.00)
    maximum_fare = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    active = models.BooleanField(default=True)
    # Optional: price a specific predetermined Route's ad-hoc/off-route
    # segments differently to its own fixed fare (left blank = applies
    # generally to any ad-hoc calculated route).
    route_specific_override = models.ForeignKey(
        Route, null=True, blank=True, on_delete=models.SET_NULL, related_name="fare_overrides"
    )

    class Meta:
        ordering = ["-active", "name"]

    def __str__(self):
        return f"{self.name} ({'active' if self.active else 'inactive'})"

    def estimate(self, distance_km):
        fare = float(self.base_fare) + float(self.price_per_km) * distance_km
        fare = max(fare, float(self.minimum_fare))
        if self.maximum_fare is not None:
            fare = min(fare, float(self.maximum_fare))
        return round(fare, 2)


class Boarding(models.Model):
    """A passenger boarding record against a trip (accountability trail)."""

    trip = models.ForeignKey(Trip, related_name="boardings", on_delete=models.CASCADE)
    passenger_name = models.CharField(max_length=120, blank=True)
    passenger_phone = models.CharField(max_length=30, blank=True)
    boarding_stop = models.ForeignKey(
        RouteStop, on_delete=models.SET_NULL, null=True, blank=True
    )
    fare_paid = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    boarded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Boarding {self.id} on trip {self.trip_id}"
