from rest_framework.routers import DefaultRouter

from django.urls import path

from . import views

router = DefaultRouter()
router.register("routes", views.RouteViewSet, basename="route")
router.register("vehicles", views.VehicleViewSet, basename="vehicle")
router.register("trips", views.TripViewSet, basename="trip")
router.register("boardings", views.BoardingViewSet, basename="boarding")

urlpatterns = [
    path("auth/login/", views.login_view, name="auth-login"),
    path("routes/search/", views.search_routes, name="route-search"),
    path("routes/<int:route_id>/estimate/", views.route_estimate, name="route-estimate"),
    path("routes/<int:route_id>/directions/", views.route_directions, name="route-directions"),
    path("routing/calculate/", views.calculate_route, name="routing-calculate"),
    path("routing/directions/", views.ad_hoc_directions, name="routing-directions"),
    path("panic-alerts/", views.panic_alert, name="panic-alert"),
    path("vehicles/mine/", views.my_vehicle, name="vehicle-mine"),
    path("vehicles/<int:vehicle_id>/location/", views.vehicle_location, name="vehicle-location"),
    path(
        "vehicles/<int:vehicle_id>/simulate/",
        views.simulate_vehicle_movement,
        name="vehicle-simulate",
    ),
] + router.urls
