from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.conf import settings
from django.contrib.auth import authenticate
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import status, viewsets
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from .consumers import FLEET_GROUP, vehicle_group_name
from .models import Boarding, Route, Trip, Vehicle, VehicleLocation
from .permissions import IsAssignedDriverForLocationPost, IsOperatorOrAdmin
from .serializers import (
    BoardingSerializer,
    ProfileSerializer,
    RouteSerializer,
    TripSerializer,
    VehicleLocationSerializer,
    VehicleSerializer,
)
from .services import deviation, fare_service, geo
from .services.routing_service import RoutingServiceError, get_driving_route, get_ad_hoc_route


def _point_from_request(data, prefix):
    lat = data.get(f"{prefix}_lat")
    lng = data.get(f"{prefix}_lng")
    if lat is None or lng is None:
        return None
    return (float(lat), float(lng))


def _broadcast_vehicle_location(vehicle, location, deviation_result):
    """Push a location update to both the fleet feed and this vehicle's own feed."""
    channel_layer = get_channel_layer()
    if channel_layer is None:
        return

    payload = {
        "type": "vehicle.location",
        "vehicle_id": vehicle.id,
        "registration": vehicle.registration,
        "route_id": vehicle.route_id,
        **VehicleLocationSerializer(location).data,
        **deviation_result.as_dict(),
    }
    # VehicleLocationSerializer's `recorded_at` isn't JSON-serialisable as-is
    # inside a dict headed for the channel layer; stringify it explicitly.
    payload["recorded_at"] = location.recorded_at.isoformat()

    for group in (FLEET_GROUP, vehicle_group_name(vehicle.id)):
        async_to_sync(channel_layer.group_send)(group, {"type": "vehicle.location", "payload": payload})


@api_view(["POST"])
@permission_classes([AllowAny])
def login_view(request):
    """
    POST /api/auth/login/  { "username": "...", "password": "..." }

    Returns a DRF token plus the account's THEMBA role, so the frontend can
    attach `Authorization: Token <token>` to protected requests (fleet
    tracking, GPS pings) and route the user to the right dashboard.
    """
    username = request.data.get("username", "")
    password = request.data.get("password", "")
    user = authenticate(request, username=username, password=password)
    if user is None:
        return Response({"error": "Invalid username or password."}, status=status.HTTP_401_UNAUTHORIZED)

    token, _ = Token.objects.get_or_create(user=user)
    return Response(
        {
            "token": token.key,
            "username": user.username,
            "role": ProfileSerializer(user.profile).data["role"],
        }
    )


class RouteViewSet(viewsets.ReadOnlyModelViewSet):
    """
    GET /api/routes/            -> list all predetermined routes
    GET /api/routes/{id}/       -> route detail incl. geometry + stops
    """

    queryset = Route.objects.filter(is_active=True).prefetch_related("stops")
    serializer_class = RouteSerializer


@api_view(["GET", "POST"])
def search_routes(request):
    """
    Search predetermined routes by destination, with an optional origin
    (manual point or the passenger's live GPS location).

    Body / query params:
        destination_lat, destination_lng   (required)
        origin_lat, origin_lng              (optional - manual start point)
        use_live_location                   (bool, informational only -
                                              the actual coordinates still
                                              come from origin_lat/lng,
                                              which the frontend fills in
                                              from navigator.geolocation)

    Returns each matching route with distance/duration/fare/speed for the
    requested segment, ready to render as the "Pick a Route" list.
    """
    data = request.data if request.method == "POST" else request.query_params

    destination = _point_from_request(data, "destination")
    if destination is None:
        return Response(
            {"error": "destination_lat and destination_lng are required."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    origin = _point_from_request(data, "origin")
    max_distance_km = float(data.get("max_distance_km", 5.0))

    matching_routes = fare_service.find_matching_routes(
        destination, origin=origin, max_distance_km=max_distance_km
    )

    results = [
        fare_service.estimate_for_route(route, origin=origin, destination=destination).as_dict()
        for route in matching_routes
    ]

    return Response(
        {
            "origin": {"lat": origin[0], "lng": origin[1]} if origin else None,
            "destination": {"lat": destination[0], "lng": destination[1]},
            "route_options": results,
            "count": len(results),
        }
    )


@api_view(["GET"])
def route_estimate(request, route_id):
    """
    GET /api/routes/{id}/estimate/?origin_lat=...&origin_lng=...&destination_lat=...&destination_lng=...

    Fare/time/distance/speed for one specific predetermined route - this
    backs the fare popup shown after a route is picked.
    """
    route = get_object_or_404(Route, pk=route_id, is_active=True)
    origin = _point_from_request(request.query_params, "origin")
    destination = _point_from_request(request.query_params, "destination")

    estimate = fare_service.estimate_for_route(route, origin=origin, destination=destination)
    payload = estimate.as_dict()
    payload["geometry"] = route.geometry or None
    return Response(payload)


@api_view(["GET"])
def route_directions(request, route_id):
    """
    GET /api/routes/{id}/directions/

    Returns the routing-line geometry for a route. Geometry is fetched from
    OpenRouteService / OSRM (see routing_service) and cached on the Route.

    Cached geometry that is only a 2-point straight line (old fallback) is
    discarded and recomputed so HeiGIT/ORS can replace it.
    """
    route = get_object_or_404(Route, pk=route_id, is_active=True)

    geom = route.geometry or []
    is_stale_fallback = isinstance(geom, list) and 0 < len(geom) <= 2

    if geom and not is_stale_fallback:
        return Response(
            {
                "geometry": geom,
                "distance_km": route.distance_km,
                "duration_min": route.average_duration_min,
                "source": "cached",
            }
        )

    origin = (route.origin_lat, route.origin_lng)
    destination = (route.destination_lat, route.destination_lng)
    directions = get_driving_route(origin, destination)

    # Do not permanently cache pure straight-line fallback when a real
    # router may become available later (ORS_API_KEY / ROUTING_SERVICE_URL).
    if directions.get("source") != "fallback":
        route.geometry = directions["geometry"]
        route.distance_km = directions["distance_km"]
        route.average_duration_min = directions["duration_min"]
        route.save(update_fields=["geometry", "distance_km", "average_duration_min"])
    elif is_stale_fallback:
        # Clear bad cache so next request can try again after ORS is configured
        route.geometry = []
        route.save(update_fields=["geometry"])

    return Response(directions)


@api_view(["POST"])
@permission_classes([AllowAny])
def ad_hoc_directions(request):
    """
    POST /api/routing/directions/

    Server-side road routing for ad-hoc passenger trips when Google Routes
    is unavailable (PERMISSION_DENIED, no key, quota, etc.).

    Tries OpenRouteService (ORS_API_KEY) → OSRM (ROUTING_SERVICE_URL) →
    straight-line fallback.

    Body:
        {
          "origin": {"lat": -28.78, "lng": 31.89},
          "destination": {"lat": -28.78, "lng": 32.04}
        }
        (also accepts latitude/longitude keys)

    Returns:
        {
          "geometry": [[lat, lng], ...],
          "distance_km": 14.2,
          "duration_min": 28.0,
          "source": "ors" | "osrm" | "fallback"
        }
    """
    data = request.data or {}
    origin_raw = data.get("origin") or data.get("start") or {}
    dest_raw = data.get("destination") or data.get("end") or {}

    def _lat_lng(obj):
        if not isinstance(obj, dict):
            return None
        lat = obj.get("lat", obj.get("latitude"))
        lng = obj.get("lng", obj.get("longitude"))
        try:
            return (float(lat), float(lng))
        except (TypeError, ValueError):
            return None

    origin = _lat_lng(origin_raw)
    destination = _lat_lng(dest_raw)
    if origin is None or destination is None:
        return Response(
            {"error": "origin and destination with lat/lng (or latitude/longitude) are required."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    try:
        result = get_ad_hoc_route(origin, destination)
    except RoutingServiceError as exc:
        return Response({"error": str(exc)}, status=status.HTTP_502_BAD_GATEWAY)
    except Exception as exc:  # noqa: BLE001
        return Response(
            {"error": f"Routing failed: {exc}"},
            status=status.HTTP_502_BAD_GATEWAY,
        )

    return Response(
        {
            "geometry": result["geometry"],
            "distance_km": result["distance_km"],
            "duration_min": result["duration_min"],
            "source": result["source"],
        }
    )


@api_view(["POST"])
@permission_classes([AllowAny])
def calculate_route(request):
    """
    POST /api/routing/calculate/

    THEMBA's business-rules layer for an AD-HOC route (THEMBA_SPEC §10/§20).

    Architecture note (documented per §10): the road route itself -
    geometry, distance, duration - is calculated *client-side* by the
    Google Maps JavaScript API's Routes Library (`Route.computeRoutes()`),
    NOT by this endpoint. That keeps the Google Maps API key a properly
    restricted *browser* key (§5) and avoids this endpoint making its own,
    duplicate, billable Google request for every route the frontend already
    computed (§30). This endpoint instead:
      1. validates the coordinates and the distance/duration the frontend
         already got from Google,
      2. applies THEMBA's own fare formula (never Google's) via
         TaxiFareRule,
      3. is the place future THEMBA-specific business rules would live -
         peak-period adjustments, dwell time, etc. (§19) - without any of
         that logic needing to touch Google Maps at all.

    Body:
        {
          "start": {"latitude": -28.75, "longitude": 31.89},
          "destination": {"latitude": -28.76, "longitude": 31.90},
          "distance_km": 14.2,      # from Google Routes Library, client-side
          "duration_min": 28        # from Google Routes Library, client-side
        }

    Returns the normalised THEMBA route response shape from THEMBA_SPEC §11.
    """
    data = request.data
    start = _point_from_request({"start_lat": data.get("start", {}).get("latitude"),
                                  "start_lng": data.get("start", {}).get("longitude")}, "start")
    destination = _point_from_request(
        {"destination_lat": data.get("destination", {}).get("latitude"),
         "destination_lng": data.get("destination", {}).get("longitude")},
        "destination",
    )

    if start is None or destination is None:
        return Response(
            {"error": "start and destination coordinates are required."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    try:
        distance_km = float(data.get("distance_km"))
        duration_min = float(data.get("duration_min"))
    except (TypeError, ValueError):
        return Response(
            {
                "error": "distance_km and duration_min are required and must be numbers "
                         "(THEMBA does not calculate its own road distance server-side; "
                         "the frontend supplies Google's calculated figures here for pricing)."
            },
            status=status.HTTP_400_BAD_REQUEST,
        )
    if distance_km < 0 or duration_min < 0:
        return Response({"error": "distance_km and duration_min must not be negative."}, status=400)

    fare, notice = fare_service.estimate_ad_hoc_fare(distance_km)

    return Response(
        {
            "start": {"latitude": start[0], "longitude": start[1]},
            "destination": {"latitude": destination[0], "longitude": destination[1]},
            "distance_km": round(distance_km, 2),
            "duration_min": round(duration_min, 1),
            "estimated_fare": fare,
            "fare_notice": notice,
            "source": "google_routes_client_side",
        }
    )


class VehicleViewSet(viewsets.ReadOnlyModelViewSet):
    """
    GET /api/vehicles/           -> all vehicles + latest known location
    GET /api/vehicles/?route=ID  -> vehicles currently on a given route
    GET /api/vehicles/{id}/      -> single vehicle detail

    This is what the operator/administrator "live tracking" screen reads
    (over REST for the initial load; the WebSocket feed keeps it updated
    after that). Restricted to operator/administrator accounts - a
    passenger only ever gets one vehicle's position, via the trip they
    booked, not the whole fleet.
    """

    serializer_class = VehicleSerializer
    permission_classes = [IsOperatorOrAdmin]

    def get_queryset(self):
        queryset = Vehicle.objects.select_related("route").prefetch_related("locations").order_by("id")
        route_id = self.request.query_params.get("route")
        if route_id:
            queryset = queryset.filter(route_id=route_id)
        status_filter = self.request.query_params.get("status")
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        return queryset


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def my_vehicle(request):
    """
    GET /api/vehicles/mine/

    The vehicle the signed-in driver is assigned to (Vehicle.driver_user),
    so the Driver "Start trip" screen knows which vehicle_id to POST GPS
    pings against without the driver having to look it up manually.
    """
    vehicle = Vehicle.objects.select_related("route").filter(driver_user=request.user).first()
    if vehicle is None:
        return Response(
            {"error": "No vehicle is currently assigned to your driver account."},
            status=status.HTTP_404_NOT_FOUND,
        )
    return Response(VehicleSerializer(vehicle).data)


@api_view(["GET", "POST"])
def vehicle_location(request, vehicle_id):
    """
    GET  /api/vehicles/{id}/location/  -> latest ping (for map polling/WS bootstrap)
    POST /api/vehicles/{id}/location/  -> driver app pushes a new GPS ping.
        Requires the requesting user to be that vehicle's assigned driver.
        body: { lat, lng, speed_kmh (omit/null if unavailable), heading_deg, accuracy_m }
    """
    vehicle = get_object_or_404(Vehicle, pk=vehicle_id)

    if request.method == "GET":
        location = vehicle.locations.first()
        if not location:
            return Response({"error": "No location recorded yet."}, status=404)
        payload = VehicleLocationSerializer(location).data
        payload.update(deviation.check_deviation(location.lat, location.lng, vehicle.route).as_dict())
        return Response(payload)

    if not request.user.is_authenticated:
        return Response({"error": "Authentication required to submit GPS updates."}, status=401)
    if vehicle.driver_user_id != request.user.id:
        return Response({"error": "You are not the assigned driver for this vehicle."}, status=403)

    serializer = VehicleLocationSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    location = VehicleLocation.objects.create(
        vehicle=vehicle, source=VehicleLocation.Source.GPS, **serializer.validated_data
    )
    vehicle.status = Vehicle.Status.ACTIVE
    vehicle.save(update_fields=["status"])

    deviation_result = deviation.check_deviation(location.lat, location.lng, vehicle.route)
    _broadcast_vehicle_location(vehicle, location, deviation_result)

    payload = VehicleLocationSerializer(location).data
    payload.update(deviation_result.as_dict())
    return Response(payload, status=status.HTTP_201_CREATED)


@api_view(["POST"])
@permission_classes([AllowAny])
def simulate_vehicle_movement(request, vehicle_id):
    """
    POST /api/vehicles/{id}/simulate/
        body: { "fraction": 0.0-1.0 }

    TEST-DATA-ONLY endpoint: moves a vehicle to a point `fraction` of the way
    along its assigned route's geometry and records a location ping with a
    derived speed/heading, without needing a real device with GPS. Every
    location it creates is tagged source="simulated" so it's clearly
    distinguishable from real driver GPS everywhere it's displayed. Only
    available while the backend runs with DEBUG=True.
    """
    if not settings.DEBUG:
        return Response(
            {"error": "Simulation is a development/test tool and is disabled outside DEBUG mode."},
            status=status.HTTP_403_FORBIDDEN,
        )

    vehicle = get_object_or_404(Vehicle, pk=vehicle_id)
    if not vehicle.route or not vehicle.route.geometry:
        return Response(
            {"error": "Vehicle has no assigned route or the route has no geometry yet. "
                      "Call /api/routes/{id}/directions/ first."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    fraction = float(request.data.get("fraction", 0.0))
    fraction = max(0.0, min(1.0, fraction))

    points = [tuple(p) for p in vehicle.route.geometry]
    point = geo.point_at_fraction(points, fraction)

    # Derive heading from the previous simulated position, if any.
    previous = vehicle.locations.first()
    heading = previous.heading_deg if previous else 0
    if previous and (previous.lat, previous.lng) != point:
        heading = geo.bearing_deg(previous.lat, previous.lng, point[0], point[1])

    speed = vehicle.route.average_speed_kmh

    location = VehicleLocation.objects.create(
        vehicle=vehicle,
        lat=point[0],
        lng=point[1],
        speed_kmh=speed,
        heading_deg=heading,
        accuracy_m=8,
        source=VehicleLocation.Source.SIMULATED,
        recorded_at=timezone.now(),
    )
    vehicle.status = Vehicle.Status.ACTIVE
    vehicle.save(update_fields=["status"])

    deviation_result = deviation.check_deviation(location.lat, location.lng, vehicle.route)
    _broadcast_vehicle_location(vehicle, location, deviation_result)

    return Response(
        {
            "vehicle": vehicle.registration,
            "route": vehicle.route.code,
            "fraction": fraction,
            "location": VehicleLocationSerializer(location).data,
            **deviation_result.as_dict(),
        }
    )



@api_view(["POST"])
@permission_classes([AllowAny])
def panic_alert(request):
    """
    POST /api/panic-alerts/

    Passenger emergency alert. Broadcasts to the fleet/ops channel group when
    Channels is available. Body may include trip + location fields.
    """
    data = request.data or {}
    payload = {
        "type": "PANIC_ALERT",
        "tripId": data.get("tripId") or data.get("trip_id"),
        "passengerId": data.get("passengerId") or getattr(request.user, "id", None),
        "passengerName": data.get("passengerName"),
        "departurePoint": data.get("departurePoint") or data.get("departure_point"),
        "destination": data.get("destination"),
        "latitude": data.get("latitude"),
        "longitude": data.get("longitude"),
        "accuracy": data.get("accuracy"),
        "timestamp": data.get("timestamp"),
        "operator": data.get("operator"),
        "driver": data.get("driver"),
        "vehicle": data.get("vehicle") or data.get("registration"),
    }
    logger = __import__("logging").getLogger(__name__)
    logger.warning("PANIC_ALERT received: %s", payload)

    channel_layer = get_channel_layer()
    if channel_layer is not None:
        try:
            async_to_sync(channel_layer.group_send)(
                FLEET_GROUP,
                {"type": "panic.alert", "payload": payload},
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not broadcast panic alert: %s", exc)

    return Response(
        {"status": "accepted", "message": "Operator and administrator notified.", "alert": payload},
        status=status.HTTP_201_CREATED,
    )


class TripViewSet(viewsets.ModelViewSet):
    """Trips (route + vehicle instance). Passengers verify by trip code."""

    queryset = Trip.objects.select_related("route", "vehicle")
    serializer_class = TripSerializer


class BoardingViewSet(viewsets.ModelViewSet):
    """Passenger boarding records against a trip."""

    queryset = Boarding.objects.select_related("trip", "boarding_stop")
    serializer_class = BoardingSerializer
