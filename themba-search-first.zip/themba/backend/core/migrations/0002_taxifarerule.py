import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='TaxiFareRule',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(default='Default ad-hoc fare', max_length=80)),
                ('base_fare', models.DecimalField(decimal_places=2, default=5.0, max_digits=6)),
                ('price_per_km', models.DecimalField(decimal_places=2, default=2.0, max_digits=6)),
                ('minimum_fare', models.DecimalField(decimal_places=2, default=10.0, max_digits=6)),
                ('maximum_fare', models.DecimalField(blank=True, decimal_places=2, max_digits=6, null=True)),
                ('active', models.BooleanField(default=True)),
                (
                    'route_specific_override',
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name='fare_overrides',
                        to='core.route',
                    ),
                ),
            ],
            options={
                'ordering': ['-active', 'name'],
            },
        ),
    ]
