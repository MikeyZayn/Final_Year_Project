"""
Fare, ETA and speed calculations for predetermined taxi routes.

South African minibus taxi fares are set per-route (often per-segment/stop)
by the taxi association rather than computed continuously like a metered
cab, so the model is: base_fare + fare_per_km * distance, rounded to the
nearest 50c/R1 the way rank fares usually are, with an optional stop-based
override when the passenger boards partway along the route.
"""
from dataclasses import dataclass

from ..models import Route, RouteStop, TaxiFareRule
from .geo import haversine_km


def round_to_taxi_fare(amount, increment=0.5):
    """Round to the nearest fare increment (default 50c) the way taxi fares are quoted."""
    return round(round(amount / increment) * increment, 2)


@dataclass
class RouteEstimate:
    route: Route
    distance_km: float
    duration_min: float
    average_speed_kmh: float
    fare: float
    from_stop: str
    to_stop: str

    def as_dict(self):
        return {
            "route_id": self.route.id,
            "route_code": self.route.code,
            "route_name": self.route.name,
            "vehicle_class": self.route.get_vehicle_class_display(),
            "distance_km": round(self.distance_km, 2),
            "duration_min": round(self.duration_min, 1),
            "average_speed_kmh": round(self.average_speed_kmh, 1),
            "fare": self.fare,
            "from_stop": self.from_stop,
            "to_stop": self.to_stop,
        }


def estimate_for_route(route: Route, origin=None, destination=None):
    """
    Build a RouteEstimate for a predetermined route. If origin/destination
    are supplied and fall near an intermediate stop, the fare/distance are
    computed for that sub-segment (boarding partway along the route),
    otherwise the full route figures are used.
    """
    distance_km = route.distance_km
    duration_min = route.average_duration_min
    from_stop = route.origin_name
    to_stop = route.destination_name

    stops = list(route.stops.all())
    if stops and (origin or destination):
        nearest_from = _nearest_stop(stops, origin) if origin else None
        nearest_to = _nearest_stop(stops, destination) if destination else None
        if nearest_from and nearest_to and nearest_from.order != nearest_to.order:
            low, high = sorted([nearest_from, nearest_to], key=lambda s: s.order)
            distance_km = haversine_km(low.lat, low.lng, high.lat, high.lng)
            duration_min = (distance_km / route.average_speed_kmh) * 60
            from_stop, to_stop = low.name, high.name

    fare = round_to_taxi_fare(route.estimated_fare(distance_km))

    return RouteEstimate(
        route=route,
        distance_km=distance_km,
        duration_min=duration_min,
        average_speed_kmh=route.average_speed_kmh,
        fare=fare,
        from_stop=from_stop,
        to_stop=to_stop,
    )


def _nearest_stop(stops, point):
    lat, lng = point
    return min(stops, key=lambda s: haversine_km(s.lat, s.lng, lat, lng))


def estimate_ad_hoc_fare(distance_km, route=None):
    """
    Fare for an AD-HOC route: a Google-calculated road route between a
    passenger's chosen origin and destination that does NOT match any
    predetermined THEMBA route. Google supplies distance/time only — the
    fare itself always comes from a THEMBA TaxiFareRule, never from Google.

    Picks (in order): a rule overridden for this specific predetermined
    Route (if the caller is pricing a route-adjacent ad-hoc segment), else
    the active general rule, else a hard-coded last-resort default so the
    endpoint never 500s just because no admin has configured a rule yet.

    Returns (fare, notice) — `notice` is always the "demonstration
    configuration" disclaimer so the frontend can label the figure honestly.
    """
    rule = None
    if route is not None:
        rule = TaxiFareRule.objects.filter(route_specific_override=route, active=True).first()
    if rule is None:
        rule = TaxiFareRule.objects.filter(active=True, route_specific_override__isnull=True).first()

    if rule is None:
        # No TaxiFareRule configured at all (e.g. fresh install before
        # seed_demo_data has run) - fall back to the same shape of formula
        # with clearly-labelled placeholder numbers, rather than failing.
        fare = round(max(5.0 + 2.0 * distance_km, 10.0), 2)
    else:
        fare = rule.estimate(distance_km)

    return fare, TaxiFareRule.DEMONSTRATION_NOTICE


def find_matching_routes(destination, origin=None, max_distance_km=5.0):
    """
    Find predetermined routes whose destination (or an intermediate stop)
    is within `max_distance_km` of the requested destination point. This is
    the "search a route by destination" behaviour from the passenger app.
    """
    dest_lat, dest_lng = destination
    matches = []

    for route in Route.objects.filter(is_active=True).prefetch_related("stops"):
        candidates = [(route.destination_lat, route.destination_lng, None)]
        candidates += [(s.lat, s.lng, s) for s in route.stops.all()]

        best = min(
            candidates,
            key=lambda c: haversine_km(c[0], c[1], dest_lat, dest_lng),
        )
        distance_to_dest = haversine_km(best[0], best[1], dest_lat, dest_lng)
        if distance_to_dest <= max_distance_km:
            matches.append((route, distance_to_dest))

    matches.sort(key=lambda pair: pair[1])
    return [route for route, _ in matches]
