# THEMBA — Google Maps Routing & Live Vehicle Tracking

## Changelog — this pass (debugging the "can't load Google Maps" / straight-line route reports)

Fixes made after diagnosing two issues reported against a running deployment:

1. **`backend/.env`** — `ROUTING_SERVICE_URL` set to the public OSRM demo server
   (`https://router.project-osrm.org`), so predetermined-route geometry is no longer
   forced onto the built-in straight-line fallback. **Note:** in the sandbox used to
   build this fix, that public demo server returned `403 Forbidden` — it's a shared,
   rate-limited service and does reject requests sometimes. If routes are still
   straight after everything below, that's the next thing to check; see §"Going to
   production" for self-hosting your own OSRM instance instead.
2. **`backend/core/management/commands/reset_route_geometry.py`** — new. Clears
   cached `Route.geometry` so it gets recomputed against the current
   `ROUTING_SERVICE_URL`. This step was missing before: `route_directions` caches
   whatever geometry it first computes *permanently* on the `Route` row and never
   re-checks the routing service after that, so changing `ROUTING_SERVICE_URL` alone
   does nothing for routes that were already viewed once. Run:
   ```bash
   python manage.py reset_route_geometry --only-fallback   # clear only straight-line routes
   # or
   python manage.py reset_route_geometry                   # clear every route
   ```
3. **`frontend/src/services/googleMapsLoader.js`** — now hooks Google's
   `window.gm_authFailure` global callback, which Google calls specifically when the
   Maps JavaScript API script loads but *authentication* fails (bad key, referrer not
   allowed, billing not enabled, required API not enabled). Previously this failure
   mode wasn't handled at all — the loader's promise just never resolved or rejected,
   so the app hung on "Loading map…" indefinitely while Google's own dialog ("This
   page can't load Google Maps correctly" / "Do you own this website?") sat on top of
   it with no in-app explanation. It now surfaces a specific, actionable error message
   instead. A 12-second timeout was also added as a general safety net.
4. **`frontend/src/routing/RouteSelectionScreen.jsx`** — the passenger route-selection
   screen now detects when a predetermined route's geometry is the 2-point
   straight-line fallback (real OSRM geometry is a dense polyline; a fallback is
   always exactly `[origin, destination]`) and shows a visible warning instead of
   silently drawing it as if it were a real road route. This is scoped to the
   passenger flow only, per the request that triggered this fix — the Driver/Operator/
   Administrator screens were not touched in this pass.

Everything else below is unchanged from the original Google Maps migration.

---

This is the same THEMBA project you uploaded (`themba-maplibre.zip`), migrated from
**MapLibre GL JS + MapTiler** to the **Google Maps Platform** (Maps JavaScript API +
Places + the Routes Library), with the previously-missing driver "Start trip" flow and
ad-hoc fare pricing added. Nothing was rewritten from scratch — the existing React/Vite
architecture, Django/DRF backend, role-based dashboards, theming, and PWA setup are all
unchanged except where the map/routing provider swap required it.

```
themba/
├── backend/     Django + DRF + Channels API: routes, fares, vehicles, live GPS, trips
└── frontend/    React app — your existing THEMBA UI + the routing/tracking screens
```

## Architecture (as implemented)

```
React Frontend
   │
   ├── Google Maps JavaScript API  (interactive map, rendered client-side)
   ├── Google Places Autocomplete  (destination search, client-side)
   └── Google Routes Library       (Route.computeRoutes(), client-side, ONCE per
                                     origin/destination change — not on every GPS tick)
   │
   │  REST (fetch) + WebSocket (Django Channels)
   ▼
Django REST Framework API
  ├── Routes            (predetermined routes, geometry, fixed fare)
  ├── TaxiFareRule       (ad-hoc fare formula for Google-calculated routes)
  ├── Vehicles / GPS     (live location pings, deviation detection)
  ├── Trips / Boarding    (accountability trail)
  └── Routing service client (OSRM-compatible; unchanged, used only for
        PREDETERMINED route geometry — see "Two routing paths" below)
        │
        ▼
   SQLite (swap for PostgreSQL in production — just change DATABASES)
```

### Two routing paths — and why (THEMBA_SPEC §10)

THEMBA now has two distinct kinds of "route", and they get their geometry from two
different places on purpose:

1. **Predetermined THEMBA routes** (`Route` model) — their road geometry is fetched
   once by *Django*, from an OSRM-compatible service (unchanged from before), and
   cached onto the `Route` row. This never touches Google, costs nothing per view, and
   is exactly how the original project already worked.
2. **Calculated ad-hoc routes** (a passenger's live/manual location → any destination
   they typed or tapped) — their road geometry, distance and duration come from
   **Google's Routes Library**, called **client-side, in the browser**, using the
   restricted browser API key. `POST /api/routing/calculate/` does **not** call Google
   itself — it takes the distance/duration the frontend already got from Google and
   turns them into a THEMBA fare via `TaxiFareRule`. This keeps:
   - Django completely free of Google credentials (Option B from THEMBA_SPEC §10),
   - Google billed exactly once per route the passenger actually looks at (§30 — no
     server-side "verification" call duplicating what the browser already computed),
   - the fare always a THEMBA decision, never Google's.

The map always draws these two kinds of line differently — predetermined routes solid
blue, calculated Google routes dashed amber — so a passenger/driver/operator never
confuses "what THEMBA planned" with "what Google calculated" (§12).

## 1. Google Cloud configuration (you'll do this manually — placeholders are wired in)

Per your instruction, I've left `VITE_GOOGLE_MAPS_API_KEY` **blank** in both
`frontend/.env` and `frontend/.env.example` — the app is fully wired to read it, it
just isn't set yet. Steps to fill it in:

1. **Create/select a Google Cloud project** at https://console.cloud.google.com/, with
   billing enabled (Google Maps Platform requires a billing account, though usage stays
   within the free monthly credit for a project this size).
2. **Enable these APIs** (APIs & Services → Library):
   - **Maps JavaScript API** — the interactive map itself
   - **Places API** — destination search/autocomplete
   - **Routes API** — powers the Routes Library's `Route.computeRoutes()` used by the
     Maps JavaScript API on the frontend
3. **Create an API key** (APIs & Services → Credentials → Create credentials → API key).
4. **Restrict the key** (click the key → edit):
   - *Application restrictions* → **Websites** → add your dev origin
     (`http://localhost:5173/*`) and your real production URL(s) when you deploy.
   - *API restrictions* → **Restrict key** → select only the three APIs above.
   - This key is meant to be visible in the browser — it's a *publishable* key. Its
     security comes entirely from these two restrictions, not from hiding it.
5. **Set quotas** (optional but recommended for a student project) under each API's
   Quotas page, so a bug can't run up an unexpectedly large bill.
6. **Paste the key** into `frontend/.env`:
   ```
   VITE_GOOGLE_MAPS_API_KEY=your-real-key-here
   ```
7. Restart `npm run dev` (Vite only reads `.env` at startup).

Until you do this, the app **does not silently break** — `GoogleTransportMap`,
`RouteSearchScreen` and `RouteSelectionScreen` all detect the missing key and show a
clear "Google Maps is not configured" message instead of a blank/broken map (§32).

No `GOOGLE_MAPS_API_KEY` is needed on the Django side at all — see "Two routing paths"
above for why.





### Ad-hoc routing uses OpenRouteService only (map stays Google)

- **Map UI** (tiles, markers, pan/zoom): still **Google Maps JavaScript API** → needs `VITE_GOOGLE_MAPS_API_KEY`.
- **Calculated road path** (distance, duration, polyline): **OpenRouteService (HeiGIT)** only via `POST /api/routing/directions/` → needs `ORS_API_KEY` on the backend.
- Google **Routes API is not called** by THEMBA for passenger routing.

## OpenRouteService alternative (when Google Routes is blocked)

If Google returns `PERMISSION_DENIED` or billing is not ready, THEMBA can still
draw a real road path using **OpenRouteService (ORS)** via the Django backend.

### Create an ORS API key (free)

1. Sign up: https://openrouteservice.org/dev/#/signup  
   (or log in at https://account.heigit.org/ )
2. Open the developer dashboard: https://openrouteservice.org/dev/#/account
3. Create a token / API key (free plan is enough for demos: ~2 000 directions/day).
4. Copy the key into `backend/.env`:

```bash
ORS_API_KEY=your_ors_key_here
```

5. Restart Django:

```bash
cd backend
# Ctrl+C if running
python manage.py runserver
```

No frontend env change is required — the browser calls  
`POST /api/routing/directions/` and Django holds the key.

### How routing chooses a provider

| Order | Provider | When |
|------|----------|------|
| 1 | Google Routes (browser) | `VITE_GOOGLE_MAPS_API_KEY` + Routes API allowed |
| 2 | OpenRouteService | `ORS_API_KEY` set on backend |
| 3 | OSRM | `ROUTING_SERVICE_URL` set |
| 4 | Straight line | Always last resort |

Predetermined THEMBA routes also use ORS → OSRM → fallback for geometry.

### Quick test

```bash
curl -X POST http://127.0.0.1:8000/api/routing/directions/ \
  -H "Content-Type: application/json" \
  -d '{"origin":{"lat":-28.7808,"lng":31.8925},"destination":{"lat":-28.781,"lng":32.0377}}'
```

You should see `"source": "ors"` and a multi-point `geometry` when the key is valid.

## 2. Backend setup

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
# Edit .env if you want (defaults work out of the box):
#   MAPTILER_API_KEY=...      (only used by the legacy /api/geocode/ endpoint and by
#                              predetermined-route geocoding tooling — NOT used by the
#                              new Google-Places-based passenger search)
#   ROUTING_SERVICE_URL=      (OSRM-compatible; leave blank for the built-in fallback —
#                              this is for PREDETERMINED route geometry, not Google)

python manage.py migrate               # includes the new TaxiFareRule migration
python manage.py seed_demo_data        # routes, Quantum vehicles, TaxiFareRule, demo users
python manage.py createsuperuser       # optional, for /admin/

python manage.py runserver             # http://127.0.0.1:8000 (Channels/WebSocket works here too)
```

Verified while building this: `python manage.py check`, `makemigrations --check`
(no drift between the model and the migration), and `python manage.py test core`
(all 24 pre-existing tests pass unmodified) all run clean. The two new endpoints were
also smoke-tested live against a seeded database (see §7 below for the exact
commands/results).

### Demo accounts (unchanged)

| Username | Role | Password |
|---|---|---|
| `passenger_demo` | passenger | `themba123` |
| `driver_demo` | driver (assigned to vehicle `ND 123-456`, Route 45) | `themba123` |
| `operator_demo` | operator | `themba123` |
| `admin_demo` | administrator | `themba123` |

### New/changed backend API endpoints

| Method | Path | Purpose | Status |
|---|---|---|---|
| POST | `/api/routing/calculate/` | **NEW.** THEMBA's fare for a Google-calculated ad-hoc route (§10/§20). Body: `start`, `destination`, `distance_km`, `duration_min` (the last two come from the frontend's Google Routes Library call). Returns fare + the "demonstration configuration" notice. | IMPLEMENTED |
| GET | `/api/vehicles/mine/` | **NEW.** The signed-in driver's own assigned vehicle (and its route). | IMPLEMENTED |
| GET/POST | `/api/vehicles/{id}/location/` | Unchanged — poll the latest GPS ping / push a new one. Now actually used by the new Driver "Start trip" screen. | IMPLEMENTED |
| GET/POST | `/api/geocode/` | Unchanged, but superseded on the passenger search screen by client-side Google Places. Left working for other uses (see docstring in `core/views.py`). | IMPLEMENTED (legacy path) |
| *(everything else)* | | Unchanged from the original project. | IMPLEMENTED |

## 3. Frontend setup

```bash
cd frontend
npm install
# maplibre-gl has been removed from package.json; a fresh package-lock.json
# will be generated on install (the old one referenced maplibre-gl).

cp .env.example .env
# Edit .env:
#   VITE_API_BASE_URL=http://127.0.0.1:8000/api
#   VITE_GOOGLE_MAPS_API_KEY=       <- fill this in yourself (see §1 above)

npm run dev      # http://localhost:5173
```

Verified while building this: `npm install` completes cleanly (63 packages, no
`maplibre-gl`), and `npm run build` compiles all 48 modules with zero errors.

### What changed in the frontend

**Map & routing (the core provider swap):**
- `src/services/googleMapsLoader.js` — **NEW.** Loads the Google Maps JS API script
  exactly once (no npm wrapper package — matches Google's own quick-start and keeps
  the dependency list small per §34). Rejects with a readable error if the key is
  missing/invalid, rather than leaving a blank map.
- `src/routing/GoogleTransportMap.jsx` — **NEW**, replaces `MapView.jsx` (deleted) with
  the **same prop contract**, so every existing caller needed only an import swap. The
  map is created once (§8); markers/polylines are updated in place on every prop
  change, never recreated. Distinguishes origin/destination pins, the predetermined
  route line (solid blue), the calculated Google route line (dashed amber), and live
  vehicle markers (arrow icons with heading).
- `src/services/routingApi.js` — **NEW.** Wraps `Route.computeRoutes()` from the Maps
  JavaScript API's Routes Library, normalizes the response into THEMBA's shape
  (`geometry`, `distanceKm`, `durationMin`, `trafficAware`, `alternatives`), and
  translates Google's error codes into readable messages.
- `src/services/trackingApi.js` — **NEW.** Client-side ETA estimate helper (straight-
  line distance from a vehicle's current position to its route's destination, divided
  by current/average speed) for the Operator/Administrator tracking screen — clearly
  labelled as an estimate, not Google's traffic-aware duration.
- `src/services/api.js` — **NEW.** Thin re-export of the existing `src/api/themba.js`
  client under the `services/` folder your spec's layout expected (no logic
  duplicated — one source of truth for the REST client).

**Passenger flow:**
- `src/routing/RouteSearchScreen.jsx` — **REWRITTEN.** Destination search is now Google
  Places Autocomplete attached directly to the input (§15), replacing the debounced
  call to the backend's MapTiler geocode proxy. "Choose on map" and live-GPS start
  point are unchanged. (Also fixed a pre-existing bug where the loading-location
  message never rendered because it destructured a field the geolocation hook doesn't
  return.)
- `src/routing/RouteSelectionScreen.jsx` — **REWRITTEN.** Now shows **both** a
  Google-calculated ad-hoc route card (distance/time/fare, computed once per
  origin/destination pair, THEMBA fare from the new backend endpoint) **and** the
  existing predetermined-route picker, with both drawn distinctly on the map.
- `src/routing/RoutingFlow.jsx` — import swapped to `GoogleTransportMap`; logic
  unchanged.

**Driver flow (previously missing entirely):**
- `src/driver/DriverTripPanel.jsx` — **NEW.** Driver sign-in → shows their assigned
  vehicle/route → "Start trip" begins `watchPosition` GPS tracking and pushes a ping to
  Django every ~7 seconds (decoupled from how often the browser's GPS callback fires,
  per §30) → shows live ON ROUTE/OFF ROUTE status, distance from route, speed, and GPS
  accuracy, all sourced from the real backend response. Wired into `App.jsx` as a new
  "Start trip" button/modal on the Driver dashboard.
  - **Known limitation, stated plainly:** THEMBA's backend ties a vehicle to one route
    via `Vehicle.route`, set by an operator/administrator — that's what the server's
    ON ROUTE/OFF ROUTE check compares against. This screen lets a driver *preview* any
    other active predetermined route's distance/time, but cannot reassign which route
    "counts" for their own vehicle; that remains an operator/administrator action. This
    is why "select predetermined route" is PARTIALLY, not fully, implemented for the
    Driver role — changing it would mean altering the Vehicle/Trip data model, which
    felt like a bigger change than this task should make unasked.

**Operator/Administrator flow (same component serves both roles, per the original
architecture):**
- `src/tracking/LiveTrackingPanel.jsx` — **REWRITTEN.** Now also fetches the selected
  vehicle's full route (the vehicle list only carries a lightweight route summary) so
  it can draw the route line + destination marker on the map, show the destination
  name in the detail card, and show a labelled ETA estimate. Added a `LIVE GPS` tag
  (the honest counterpart to the existing `TEST DATA` tag) so a real GPS-sourced
  reading is now visibly distinguished from a simulated one.

**Backend client:**
- `src/api/themba.js` — added `calculateRoute()`, `getMyVehicle()`, `getRoute(id)`.

**Small supporting changes:**
- `src/routing/GPSStatus.jsx` — added the `LiveGpsTag` component described above.
- `src/routing/DevRoutingTester.jsx` — added a "Test ad-hoc fare calculation" button
  exercising the new `/api/routing/calculate/` endpoint without needing a real Google
  key (you type in a fake distance/duration, same as `routingApi.js` would compute).
- `src/routing/routing.css` — added styles for the new UI (map loading/error states,
  the calculated-route card, GPS/live tags, route-status badges, driver trip panel).
  Several classes that existed in the JSX but had no CSS before (`gps-status`,
  `route-status-badge`, `login-gate`, `vehicle-detail-card`, etc.) also got styled
  while I was in this file, since they were previously rendering unstyled.
- `frontend/App.jsx` — added the "Start trip" modal/button for the Driver dashboard;
  everything else unchanged.
- `frontend/package.json` — removed `maplibre-gl`. No new npm dependency was added
  (Google Maps loads via a plain `<script>` tag, per Google's own recommended
  approach — see `googleMapsLoader.js`).
- `frontend/.env` / `.env.example` — `VITE_MAPTILER_KEY` replaced with
  `VITE_GOOGLE_MAPS_API_KEY` (blank; see §1).
- `frontend/package-lock.json` — deleted (referenced `maplibre-gl`); regenerated
  automatically by `npm install`.
- `src/routing/MapView.jsx` — **DELETED**, replaced by `GoogleTransportMap.jsx`.

## 4. Backend changes in detail

- `core/models.py` — added `TaxiFareRule` (base fare, price/km, min/max fare, active
  flag, optional per-route override). Every fare it produces is returned alongside
  `TaxiFareRule.DEMONSTRATION_NOTICE` — *"Demonstration configuration — not official
  South African taxi fares."* — exactly per §20.
- `core/migrations/0002_taxifarerule.py` — the matching migration (verified against
  the model with `makemigrations --check`).
- `core/services/fare_service.py` — added `estimate_ad_hoc_fare()`.
- `core/views.py` — added `calculate_route` (`POST /api/routing/calculate/`) and
  `my_vehicle` (`GET /api/vehicles/mine/`); added a clarifying docstring note to the
  existing `geocode_view` explaining it's superseded but kept working.
- `core/urls.py` — registered the two new routes.
- `core/admin.py` — registered `TaxiFareRuleAdmin`.
- `core/management/commands/seed_demo_data.py` — seeds one default `TaxiFareRule` row.

Nothing else in the backend changed — models, permissions, consumers, deviation logic,
and the existing routing/fare service for predetermined routes are untouched.

## 5. Trying it end-to-end

1. `cd backend && python manage.py migrate && python manage.py seed_demo_data && python manage.py runserver`
2. Add your Google Maps key to `frontend/.env` (§1), then `cd frontend && npm install && npm run dev`.
3. Open the app as **passenger** → **"Open map & find route"**.
4. Allow location access (or "Choose on map") → start typing a destination — Google
   Places suggestions should appear (once your key is in).
5. Pick a destination → you'll see the **calculated Google route** card (distance,
   time, THEMBA's ad-hoc fare) *and* any matching predetermined THEMBA routes below it,
   both drawn on the map in different line styles.
6. Confirm a predetermined route → booked-trip summary.
7. Switch role to **driver**, sign in as `driver_demo` / `themba123` → **"Start trip"**
   → allow GPS → watch your live position, speed, accuracy and ON ROUTE/OFF ROUTE
   status update.
8. Switch role to **operator** or **administrator**, sign in (`operator_demo` /
   `admin_demo`, `themba123`) → **"Open fleet map"** → select the driver's vehicle →
   see its live position, route, destination, speed, accuracy, ETA, and route-deviation
   status — the same data the driver's own screen is generating.
9. Without touching real GPS: the dev tools panel inside the routing flow ("Dev test
   tools") and `python manage.py test_routing --simulate "ND 123-456"` /
   `POST /api/vehicles/1/simulate/` both drive **TEST DATA**, clearly tagged as such
   everywhere it's displayed, and rejected by the backend outside `DEBUG=True`.

## 6. Dependencies

**Frontend** — removed `maplibre-gl`; no new package added.
Current `dependencies`: `@vitejs/plugin-react`, `vite`, `react`, `react-dom`.

**Backend** — unchanged; no new Python packages. (Google Maps is used entirely
client-side, so no Google SDK is needed in `requirements.txt`.)

## 7. What was actually verified (not just written)

- `python manage.py check` → 0 issues.
- `python manage.py makemigrations --check --dry-run` → no drift (the `TaxiFareRule`
  migration exactly matches the model).
- `python manage.py test core` → **24/24 existing tests pass**, unmodified.
- Live smoke test against a seeded SQLite database + running dev server:
  - `POST /api/routing/calculate/` with real coordinates → returned a fare (`R33.40`
    for a 14.2 km/28 min test route) plus the demonstration notice; missing fields
    correctly returned `400`.
  - `GET /api/vehicles/mine/` → `401` unauthenticated, correct vehicle for
    `driver_demo`, `404` for a passenger token.
  - Driver GPS push → `POST /api/vehicles/1/location/` as `driver_demo` returned
    `route_status: "on_route"` for a nearby point and `route_status: "off_route"` (with
    `distance_from_route_m`) for a point ~20 km away — confirming the exact response
    shape `DriverTripPanel.jsx` and `LiveTrackingPanel.jsx` both consume.
- `npm install` → 63 packages, no `maplibre-gl`.
- `npm run build` → 48 modules transformed, **zero errors**.
- Built app served via `vite preview` → responds `200`, correct HTML shell.

What was **not** verified (no browser environment available here): actual in-browser
rendering of the Google Map, Places Autocomplete dropdown, or `Route.computeRoutes()`
against a real Google Maps API key — because no key has been set yet (§1). The code
paths are written and reviewed against Google's documented API shapes, and every
component fails visibly and readably (not silently) if the key is missing or Google
rejects a request, but you should do a manual click-through once your key is in.

## 8. Implementation status (per THEMBA_SPEC §38 — nothing here is overclaimed)

| Feature | Status |
|---|---|
| Interactive Google map (pan/zoom/markers/polylines, created once, updated in place) | IMPLEMENTED |
| Google Places destination search | IMPLEMENTED (requires your API key — see §1) |
| Google-calculated road route (Routes Library, client-side) | IMPLEMENTED (requires your API key) |
| Predetermined THEMBA routes (Django-sourced, OSRM geometry) | IMPLEMENTED (unchanged from original project) |
| Distance / estimated time display, clearly labelled as an estimate | IMPLEMENTED |
| Traffic-aware routing flag | IMPLEMENTED (`routingPreference: TRAFFIC_AWARE`, labelled in UI) |
| THEMBA ad-hoc fare (`TaxiFareRule`), demonstration-labelled | IMPLEMENTED |
| Predetermined-route fixed fare | IMPLEMENTED (unchanged) |
| Live GPS (position, speed, accuracy), never fabricated | IMPLEMENTED |
| GPS permission/timeout/unavailable error handling | IMPLEMENTED (unchanged, pre-existing) |
| Manual start coordinates | NOT CONFIGURED (pre-existing gap; GPS + "choose on map" are implemented, raw lat/lng entry is not) |
| Driver: start trip, live GPS, send location to Django | IMPLEMENTED (new) |
| Driver: select predetermined route (as vehicle's tracked route) | PARTIALLY IMPLEMENTED — preview only, see §3 "Known limitation" |
| Driver: ON ROUTE/OFF ROUTE display | IMPLEMENTED (new) |
| Operator/Administrator: active vehicles, select, live position, route, destination, speed, accuracy, ETA, status, deviation | IMPLEMENTED (ETA is a labelled straight-line estimate, not Google traffic data) |
| WebSocket live tracking with polling fallback | IMPLEMENTED (unchanged, pre-existing) |
| Route deviation detection (server-side, configurable threshold) | IMPLEMENTED (unchanged, pre-existing) |
| Authorization on tracking/GPS endpoints | IMPLEMENTED (unchanged, pre-existing) |
| TEST DATA mode, clearly labelled, disabled outside DEBUG | IMPLEMENTED (unchanged, pre-existing) |
| LIVE GPS labelling (the honest counterpart to TEST DATA) | IMPLEMENTED (new) |
| Google Cloud project / API keys | NOT CONFIGURED — placeholders wired in, steps above, you're doing this manually |

## 9. Going to production (unchanged advice from the original project)

- Point `ROUTING_SERVICE_URL` at a real OSRM/GraphHopper instance with South African
  road data for predetermined-route geometry.
- Swap SQLite for PostgreSQL (PostGIS if you want real geospatial queries instead of
  the current haversine-based proximity search).
- Set `REDIS_URL` so the Channels layer is shared across processes.
- Serve over HTTPS — the Geolocation API is blocked on insecure origins, so live GPS
  won't work at all without it.
- Run under Daphne/Uvicorn (ASGI), not WSGI, or WebSockets won't be served.
- Set a real Google Cloud budget alert once you're past development, since billing is
  usage-based (§1).
